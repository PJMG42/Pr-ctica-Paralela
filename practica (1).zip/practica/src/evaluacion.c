/* =====================================================================================
 *  evaluacion.c — PASO 3: evaluación del gradiente / Jacobiano en un punto
 *
 *  (Cocina: las formas de organizar la cocina para el PASO 3 (ver evaluacion.h).)
 * ===================================================================================== */
#include "evaluacion.h"
#include "polinomio.h"
#include "derivadas.h"

int hilos_nivel_externo = 1, hilos_nivel_interno = 1;
entero64 umbral_anidado = 1000;

static double  *valor_de_cada_derivado = NULL;            /* [DM]  valor de cada monomio derivado        */
static double **copias_privadas_lote = NULL;      /* [hilos][NZJ*PUNTOS_POR_LOTE] copias privadas del lote   */
static int      num_copias_privadas_lote = 0;
static double **copias_privadas = NULL;       /* [hilos][NZJ] copias privadas (directo_privado) */
static int      num_copias_privadas = 0;

/* -------------------------------------------------------------------------------------
 *  valor_monomio_derivado()
 *
 *  Valor de un monomio derivado en el punto: coeficiente · Π valor^exponente de cada
 *  factor.
 *
 *  (Cocina: cocinar UNA línea de una ficha con las cantidades de hoy.)
 * ------------------------------------------------------------------------------------- */
static inline double valor_monomio_derivado(entero64 derivado, const double *punto) {
    double valor = coeficiente_del_derivado[derivado];
    for (entero64 factor = inicio_del_derivado[derivado]; factor < inicio_del_derivado[derivado + 1]; factor++) valor *= potencia_entera(punto[variable_del_factor_derivado[factor]], exponente_del_factor_derivado[factor]);
    return valor;
}

/* =====================================================================================
 *  0. SECUENCIAL — el PASO 3 literal: para cada derivada parcial, sustituir y sumar
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  jacobiano_secuencial()
 *
 *  PASO 3 literal y con un solo hilo: para cada entrada (cada derivada parcial),
 *  sustituir el punto en todos sus monomios derivados y sumarlos. Es la REFERENCIA de
 *  la familia simbólica.
 *
 *  (Cocina: un único cocinero cocina todas las fichas, una tras otra.)
 * ------------------------------------------------------------------------------------- */
static void jacobiano_secuencial(const double *punto, double *jacobiano) {
    for (entero64 entrada = 0; entrada < num_entradas_jacobiano; entrada++) {
        double suma = 0.0;
        for (entero64 derivado = inicio_derivados_de_entrada[entrada]; derivado < inicio_derivados_de_entrada[entrada + 1]; derivado++) suma += valor_monomio_derivado(derivado, punto);
        jacobiano[entrada] = suma;
    }
}

/* =====================================================================================
 *  1. POR VARIABLES — cada hilo evalúa derivadas parciales completas (columnas)
 *  + Cada jacobiano[entrada] lo escribe un solo hilo: sin condiciones de carrera.
 *  + Mismo orden de suma que el secuencial: resultado idéntico bit a bit.
 *  − Las derivadas tienen tamaños distintos: necesita reparto dinámico (guided/dynamic).
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  jacobiano_por_variables()
 *
 *  Paralelo sobre las variables (columnas): cada hilo evalúa derivadas parciales
 *  completas. Reparto schedule(runtime): lo decide -S (guided por defecto), porque las
 *  derivadas tienen tamaños muy distintos.
 *
 *  (Cocina: cada cocinero se queda con fichas enteras; nadie toca la ficha de otro, así
 *  que no hay peleas, y como cada uno suma su ficha en el mismo orden que el cocinero
 *  solitario, el plato sale idéntico.)
 * ------------------------------------------------------------------------------------- */
static void jacobiano_por_variables(const double *punto, double *jacobiano) {
    /* OpenMP: bucle repartido entre los hilos; reparto elegido al ejecutar con -S (guided por
     * defecto). (Cocina: los cocineros se reparten estas comandas; las comandas se cogen como diga
     * el jefe.) */
    #pragma omp parallel for schedule(runtime)
    for (entero64 variable = 0; variable < num_variables; variable++)
        for (entero64 entrada = inicio_entradas_de_variable[variable]; entrada < inicio_entradas_de_variable[variable + 1]; entrada++) {
            double suma = 0.0;
            for (entero64 derivado = inicio_derivados_de_entrada[entrada]; derivado < inicio_derivados_de_entrada[entrada + 1]; derivado++) suma += valor_monomio_derivado(derivado, punto);
            jacobiano[entrada] = suma;
        }
}

/* -------------------------------------------------------------------------------------
 *  jacobiano_por_variables_con_hilos()
 *
 *  Igual que jacobiano_por_variables, pero con un número de hilos concreto
 *  (num_threads(hilos)). La usa el estudio anidado B (varios puntos a la vez, cada uno
 *  con T2 hilos).
 *
 *  (Cocina: lo mismo, pero el jefe dice exactamente cuántos cocineros trabajan en este
 *  pedido.)
 * ------------------------------------------------------------------------------------- */
void jacobiano_por_variables_con_hilos(const double *punto, double *jacobiano, int hilos) {
    (void)hilos;                                   /* sin OpenMP no se usa */
    /* OpenMP: bucle repartido entre los hilos; reparto elegido al ejecutar con -S (guided por
     * defecto); con hilos hilos. (Cocina: los cocineros se reparten estas comandas; las comandas
     * se cogen como diga el jefe; solo trabajan hilos cocineros.) */
    #pragma omp parallel for schedule(runtime) num_threads(hilos)
    for (entero64 variable = 0; variable < num_variables; variable++)
        for (entero64 entrada = inicio_entradas_de_variable[variable]; entrada < inicio_entradas_de_variable[variable + 1]; entrada++) {
            double suma = 0.0;
            for (entero64 derivado = inicio_derivados_de_entrada[entrada]; derivado < inicio_derivados_de_entrada[entrada + 1]; derivado++) suma += valor_monomio_derivado(derivado, punto);
            jacobiano[entrada] = suma;
        }
}

/* =====================================================================================
 *  2. POR MONOMIOS — dos fases
 *     Fase A: todos los monomios derivados en paralelo (reparto perfecto: todos cuestan
 *             parecido) -> valor_de_cada_derivado[p].   Fase B: cada entrada suma sus valores.
 *  + Equilibrado aunque haya pocas variables con derivadas enormes.
 *  − Escribe y vuelve a leer DM doubles: más tráfico de memoria.
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  jacobiano_por_monomios()
 *
 *  Dos fases dentro de una sola región paralela: (A) todos los monomios derivados en
 *  paralelo con reparto static (todos cuestan parecido) -> valor_de_cada_derivado[];
 *  entre las fases, el 'omp for' pone una barrera implícita; (B) cada entrada suma sus
 *  valores.
 *
 *  (Cocina: primero todos cocinan líneas sueltas y las dejan en una bandeja común;
 *  cuando todos han terminado, se junta lo de cada ficha. Muy equilibrado, pero hay que
 *  llevar y traer la bandeja.)
 * ------------------------------------------------------------------------------------- */
static void jacobiano_por_monomios(const double *punto, double *jacobiano) {
    /* OpenMP: se abre un equipo de hilos y TODOS ejecutan el bloque. (Cocina: ¡todos a cocinar!) */
    #pragma omp parallel
    {
        /* OpenMP: los hilos del equipo se reparten este bucle; al acabar se esperan (barrera
         * implícita); reparto fijo a partes iguales. (Cocina: reparto de comandas entre los que ya
         * están cocinando; a cada uno el mismo número de comandas, decidido antes de empezar.) */
        #pragma omp for schedule(static)
        for (entero64 derivado = 0; derivado < num_monomios_derivados; derivado++) valor_de_cada_derivado[derivado] = valor_monomio_derivado(derivado, punto);

        /* OpenMP: los hilos del equipo se reparten este bucle; al acabar se esperan (barrera
         * implícita); reparto elegido al ejecutar con -S (guided por defecto). (Cocina: reparto de
         * comandas entre los que ya están cocinando; las comandas se cogen como diga el jefe.) */
        #pragma omp for schedule(runtime)
        for (entero64 entrada = 0; entrada < num_entradas_jacobiano; entrada++) {
            double suma = 0.0;
            for (entero64 derivado = inicio_derivados_de_entrada[entrada]; derivado < inicio_derivados_de_entrada[entrada + 1]; derivado++) suma += valor_de_cada_derivado[derivado];
            jacobiano[entrada] = suma;
        }
    }
}

/* =====================================================================================
 *  3. ANIDADO — dos niveles de paralelismo (estudio que pide el enunciado)
 *     Nivel externo: T1 hilos se reparten las variables (derivadas parciales).
 *     Nivel interno: cada derivada con >= umbral_anidado monomios se reparte entre T2 hilos.
 *  Requiere omp_set_max_active_levels(2).
 *
 *  Nota: la primera versión usaba la cláusula if(...) de OpenMP para no abrir el equipo
 *  interno en derivadas pequeñas. Medido: aun con la condición falsa, OpenMP crea una
 *  región paralela de 1 hilo cada vez, y con millones de derivadas pequeñas era hasta
 *  2,7 veces MÁS LENTO que el secuencial. Comprobar la condición antes, en C, lo evita.
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  jacobiano_anidado()
 *
 *  Dos niveles: hilos_nivel_externo hilos se reparten las variables y, SOLO si una
 *  derivada tiene al menos umbral_anidado monomios, se abre un equipo interno de
 *  hilos_nivel_interno hilos con reduction(+:suma) para esa derivada. La condición se
 *  comprueba en C antes del #pragma para no crear equipos inútiles.
 *
 *  (Cocina: jefes de partida con pinches. Cada jefe coge fichas; si una ficha es
 *  enorme, llama a sus pinches para repartírsela; si es pequeña, la hace solo, porque
 *  llamar a los pinches cuesta más que el trabajo.)
 * ------------------------------------------------------------------------------------- */
static void jacobiano_anidado(const double *punto, double *jacobiano) {
    /* OpenMP: bucle repartido entre los hilos; reparto elegido al ejecutar con -S (guided por
     * defecto); con hilos_nivel_externo hilos. (Cocina: los cocineros se reparten estas comandas;
     * las comandas se cogen como diga el jefe; solo trabajan hilos_nivel_externo cocineros.) */
    #pragma omp parallel for schedule(runtime) num_threads(hilos_nivel_externo)
    for (entero64 variable = 0; variable < num_variables; variable++)
        for (entero64 entrada = inicio_entradas_de_variable[variable]; entrada < inicio_entradas_de_variable[variable + 1]; entrada++) {
            entero64 primer_derivado = inicio_derivados_de_entrada[entrada], fin_derivados = inicio_derivados_de_entrada[entrada + 1];
            double suma = 0.0;
            if (hilos_nivel_interno > 1 && fin_derivados - primer_derivado >= umbral_anidado) {
                /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales; con
                 * hilos_nivel_interno hilos; cada hilo suma en su copia privada de suma y al final
                 * OpenMP las junta. (Cocina: los cocineros se reparten estas comandas; a cada uno
                 * el mismo número de comandas, decidido antes de empezar; solo trabajan
                 * hilos_nivel_interno cocineros; cada cocinero su cuenco; al final se vuelcan
                 * todos en la olla.) */
                #pragma omp parallel for schedule(static) num_threads(hilos_nivel_interno) reduction(+:suma)
                for (entero64 derivado = primer_derivado; derivado < fin_derivados; derivado++) suma += valor_monomio_derivado(derivado, punto);
            } else {
                for (entero64 derivado = primer_derivado; derivado < fin_derivados; derivado++) suma += valor_monomio_derivado(derivado, punto);
            }
            jacobiano[entrada] = suma;
        }
}

/* =====================================================================================
 *  4 y 5. DIRECTAS — optimización algorítmica: no usan los polinomios derivados.
 *  Recorren los monomios ORIGINALES y calculan todas sus derivadas de golpe:
 *     monomio c·p0·p1·...·p(k-1), pj = x_vj^ej
 *     ∂/∂x_vj = c · ej·x_vj^(ej-1) · producto_izquierda[j] · producto_derecha[j+1]
 *     producto_izquierda[j] = p0···p(j-1),  producto_derecha[j+1] = p(j+1)···p(k-1)
 *     -> O(k), sin divisiones
 *  Ahorran la memoria del PASO 1 (útil para problemas enormes), pero varios monomios
 *  contribuyen a la misma entrada -> hace falta atomic o copias privadas.
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  derivar_monomio_completo()
 *
 *  Calcula de golpe TODAS las derivadas de un monomio original en el punto y las deja
 *  en 'derivadas'. Para cada factor j: potencias[j] = x^e y derivadas_de_potencias[j] =
 *  e·x^(e-1) (con una sola potencia). Luego productos acumulados por la izquierda y por
 *  la derecha: derivada j = c · derivadas_de_potencias[j] · producto_izquierda[j] ·
 *  producto_derecha[j+1]. Coste O(k), sin divisiones. Devuelve k (nº de factores).
 *
 *  (Cocina: leer una línea de la receta UNA vez y calcular a la vez cuánto aporta a la
 *  ficha de cada uno de sus ingredientes, sin escribir fichas.)
 * ------------------------------------------------------------------------------------- */
static inline int derivar_monomio_completo(entero64 monomio, const double *punto, double *derivadas) {
    entero64 primer_factor = inicio_del_monomio[monomio];
    int num_factores_monomio = (int)(inicio_del_monomio[monomio + 1] - primer_factor);
    double potencias[MAX_VARIABLES_POR_MONOMIO], derivadas_de_potencias[MAX_VARIABLES_POR_MONOMIO], producto_izquierda[MAX_VARIABLES_POR_MONOMIO + 1], producto_derecha[MAX_VARIABLES_POR_MONOMIO + 1];
    for (int posicion = 0; posicion < num_factores_monomio; posicion++) {
        int exponente = exponente_del_factor[primer_factor + posicion];
        double valor_variable = punto[variable_del_factor[primer_factor + posicion]];
        double potencia_menos_uno = potencia_entera(valor_variable, exponente - 1);                  /* x^(e-1): una sola potencia   */
        derivadas_de_potencias[posicion] = exponente * potencia_menos_uno;                              /* derivada de x^e              */
        potencias[posicion]  = potencia_menos_uno * valor_variable;                             /* x^e                          */
    }
    producto_izquierda[0] = 1.0;
    for (int posicion = 0; posicion < num_factores_monomio; posicion++) producto_izquierda[posicion + 1] = producto_izquierda[posicion] * potencias[posicion];
    producto_derecha[num_factores_monomio] = 1.0;
    for (int posicion = num_factores_monomio - 1; posicion >= 0; posicion--) producto_derecha[posicion] = producto_derecha[posicion + 1] * potencias[posicion];
    double coeficiente = coeficiente_del_monomio[monomio];
    for (int posicion = 0; posicion < num_factores_monomio; posicion++) derivadas[posicion] = coeficiente * derivadas_de_potencias[posicion] * producto_izquierda[posicion] * producto_derecha[posicion + 1];
    return num_factores_monomio;
}

/* -------------------------------------------------------------------------------------
 *  jacobiano_directo_secuencial()
 *
 *  Referencia secuencial de la familia directa: pone el Jacobiano a 0, recorre los
 *  monomios originales y suma cada derivada en su entrada (entrada_del_factor).
 *
 *  (Cocina: un único cocinero que cocina directamente de la receta original, sin
 *  fichas.)
 * ------------------------------------------------------------------------------------- */
static void jacobiano_directo_secuencial(const double *punto, double *jacobiano) {
    for (entero64 entrada = 0; entrada < num_entradas_jacobiano; entrada++) jacobiano[entrada] = 0.0;
    double derivadas_del_monomio[MAX_VARIABLES_POR_MONOMIO];
    for (entero64 monomio = 0; monomio < num_monomios; monomio++) {
        int num_factores_monomio = derivar_monomio_completo(monomio, punto, derivadas_del_monomio);
        entero64 primer_factor = inicio_del_monomio[monomio];
        for (int posicion = 0; posicion < num_factores_monomio; posicion++) jacobiano[entrada_del_factor[primer_factor + posicion]] += derivadas_del_monomio[posicion];
    }
}

/* -------------------------------------------------------------------------------------
 *  jacobiano_directo_atomico()
 *
 *  Paralelo sobre los monomios originales. Varios monomios aportan a la MISMA entrada,
 *  así que cada suma se protege con '#pragma omp atomic'.
 *
 *  (Cocina: muchos cocineros apuntando en las mismas fichas; para no perder ninguna
 *  suma, hacen turno en la ficha (atomic). Si muchos quieren la misma, hay cola.)
 * ------------------------------------------------------------------------------------- */
static void jacobiano_directo_atomico(const double *punto, double *jacobiano) {
    /* OpenMP: se abre un equipo de hilos y TODOS ejecutan el bloque. (Cocina: ¡todos a cocinar!) */
    #pragma omp parallel
    {
        /* OpenMP: los hilos del equipo se reparten este bucle; al acabar se esperan (barrera
         * implícita); reparto fijo a partes iguales. (Cocina: reparto de comandas entre los que ya
         * están cocinando; a cada uno el mismo número de comandas, decidido antes de empezar.) */
        #pragma omp for schedule(static)
        for (entero64 entrada = 0; entrada < num_entradas_jacobiano; entrada++) jacobiano[entrada] = 0.0;

        double derivadas_del_monomio[MAX_VARIABLES_POR_MONOMIO];
        /* OpenMP: los hilos del equipo se reparten este bucle; al acabar se esperan (barrera
         * implícita); reparto elegido al ejecutar con -S (guided por defecto). (Cocina: reparto de
         * comandas entre los que ya están cocinando; las comandas se cogen como diga el jefe.) */
        #pragma omp for schedule(runtime)
        for (entero64 monomio = 0; monomio < num_monomios; monomio++) {
            int num_factores_monomio = derivar_monomio_completo(monomio, punto, derivadas_del_monomio);
            entero64 primer_factor = inicio_del_monomio[monomio];
            for (int posicion = 0; posicion < num_factores_monomio; posicion++) {
                /* OpenMP: suma protegida: un solo hilo cada vez sobre ese dato. (Cocina: turno en
                 * la olla para no perder ninguna suma.) */
                #pragma omp atomic
                jacobiano[entrada_del_factor[primer_factor + posicion]] += derivadas_del_monomio[posicion];
            }
        }
    }
}

/* -------------------------------------------------------------------------------------
 *  jacobiano_directo_privado()
 *
 *  Paralelo sobre los monomios originales; cada hilo suma en SU copia privada
 *  (copias_privadas[mi_hilo]) sin protecciones. Después, en paralelo por entradas, se
 *  suman las copias de todos los hilos y se ponen a 0 ('sumar y limpiar'), para que
 *  estén listas la próxima vez sin tener que borrarlas aparte.
 *
 *  (Cocina: cada cocinero apunta en su propia libreta; al final se suman todas las
 *  libretas en el tablón y se borran para el siguiente pedido.)
 * ------------------------------------------------------------------------------------- */
static void jacobiano_directo_privado(const double *punto, double *jacobiano) {
    /* OpenMP: se abre un equipo de hilos y TODOS ejecutan el bloque. (Cocina: ¡todos a cocinar!) */
    #pragma omp parallel
    {
        int total_hilos  = omp_get_num_threads();
        int mi_hilo = omp_get_thread_num();
        double *mi_copia = copias_privadas[mi_hilo];
        double derivadas_del_monomio[MAX_VARIABLES_POR_MONOMIO];

        /* OpenMP: los hilos del equipo se reparten este bucle; al acabar se esperan (barrera
         * implícita); reparto elegido al ejecutar con -S (guided por defecto). (Cocina: reparto de
         * comandas entre los que ya están cocinando; las comandas se cogen como diga el jefe.) */
        #pragma omp for schedule(runtime)
        for (entero64 monomio = 0; monomio < num_monomios; monomio++) {
            int num_factores_monomio = derivar_monomio_completo(monomio, punto, derivadas_del_monomio);
            entero64 primer_factor = inicio_del_monomio[monomio];
            for (int posicion = 0; posicion < num_factores_monomio; posicion++) mi_copia[entrada_del_factor[primer_factor + posicion]] += derivadas_del_monomio[posicion];
        }

        /* OpenMP: los hilos del equipo se reparten este bucle; al acabar se esperan (barrera
         * implícita); reparto fijo a partes iguales. (Cocina: reparto de comandas entre los que ya
         * están cocinando; a cada uno el mismo número de comandas, decidido antes de empezar.) */
        #pragma omp for schedule(static)
        for (entero64 entrada = 0; entrada < num_entradas_jacobiano; entrada++) {
            double suma = 0.0;
            for (int hilo = 0; hilo < total_hilos; hilo++) { suma += copias_privadas[hilo][entrada]; copias_privadas[hilo][entrada] = 0.0; }
            jacobiano[entrada] = suma;
        }
    }
}

const char *nombre_estrategia[NUM_ESTRATEGIAS] = {
    "secuencial", "por_variables", "por_monomios", "anidado",
    "directo_secuencial", "directo_atomico", "directo_privado"
};
tipo_funcion_jacobiano funcion_estrategia[NUM_ESTRATEGIAS] = {
    jacobiano_secuencial, jacobiano_por_variables, jacobiano_por_monomios, jacobiano_anidado,
    jacobiano_directo_secuencial, jacobiano_directo_atomico, jacobiano_directo_privado
};

/* =====================================================================================
 *  Preparación, disponibilidad y utilidades
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  preparar_evaluacion()
 *
 *  Reserva UNA vez los buffers del PASO 3: los valores de los monomios derivados (para
 *  por_monomios) y, si caben, las copias privadas por hilo. Cada hilo reserva y pone a
 *  0 su propia copia ('primer toque'), así su memoria queda cerca de él. También activa
 *  el paralelismo anidado (omp_set_max_active_levels(2)).
 *
 *  (Cocina: antes de abrir, cada cocinero prepara su libreta y la deja en SU encimera.)
 * ------------------------------------------------------------------------------------- */
void preparar_evaluacion(int hilos) {
    omp_set_max_active_levels(2);                       /* permite el paralelismo anidado */
    if (derivadas_construidas)
        valor_de_cada_derivado = reservar(sizeof(double) * (num_monomios_derivados > 0 ? num_monomios_derivados : 1), "valor_de_cada_derivado");
    if ((double)hilos * num_entradas_jacobiano * sizeof(double) <= LIMITE_MEMORIA) {
        copias_privadas = reservar(sizeof(double *) * hilos, "copias_privadas");
        num_copias_privadas = hilos;
        /* OpenMP: se abre un equipo de hilos y TODOS ejecutan el bloque; con hilos hilos. (Cocina:
         * ¡todos a cocinar!; solo trabajan hilos cocineros.) */
        #pragma omp parallel num_threads(hilos)
        {
            int mi_hilo = omp_get_thread_num();               /* 1er toque desde su hilo */
            copias_privadas[mi_hilo] = reservar_cero(num_entradas_jacobiano, sizeof(double), "copias_privadas");
        }
    }
}

/* -------------------------------------------------------------------------------------
 *  liberar_evaluacion()
 *
 *  Libera los buffers del PASO 3 (incluidos los de los lotes).
 *
 *  (Cocina: recoger las libretas al cerrar.)
 * ------------------------------------------------------------------------------------- */
void liberar_evaluacion(void) {
    free(valor_de_cada_derivado);
    for (int hilo = 0; hilo < num_copias_privadas; hilo++) free(copias_privadas[hilo]);
    free(copias_privadas);
    for (int hilo = 0; hilo < num_copias_privadas_lote; hilo++) free(copias_privadas_lote[hilo]);
    free(copias_privadas_lote);
    valor_de_cada_derivado = NULL; copias_privadas = NULL; num_copias_privadas = 0;
    copias_privadas_lote = NULL; num_copias_privadas_lote = 0;
}

/* -------------------------------------------------------------------------------------
 *  estrategia_disponible()
 *
 *  Dice si una estrategia se puede usar: las simbólicas (0-3) necesitan el PASO 1
 *  materializado (sin -D); la de copias privadas, que las copias existan para esos
 *  hilos.
 *
 *  (Cocina: ¿hay fichas escritas? ¿hay libretas para todos los cocineros?)
 * ------------------------------------------------------------------------------------- */
int estrategia_disponible(int estrategia, int hilos) {
    if (estrategia <= 3 && !derivadas_construidas) return 0;
    if (estrategia == 6) return copias_privadas != NULL && hilos <= num_copias_privadas;
    return 1;
}

/* -------------------------------------------------------------------------------------
 *  memoria_evaluacion()
 *
 *  Bytes que ocupan los buffers de evaluación (para el informe de memoria).
 *
 *  (Cocina: cuánto sitio ocupan las bandejas y libretas.)
 * ------------------------------------------------------------------------------------- */
double memoria_evaluacion(int hilos) {
    double bytes = 0.0;
    if (derivadas_construidas) bytes += (double)num_monomios_derivados * 8;
    if ((double)hilos * num_entradas_jacobiano * 8 <= LIMITE_MEMORIA) bytes += (double)hilos * num_entradas_jacobiano * 8;
    return bytes;
}

/* -------------------------------------------------------------------------------------
 *  evaluar_funciones()
 *
 *  Calcula f(x) de cada función, en paralelo sobre los monomios. Varios monomios suman
 *  en la misma función: se usa reduction sobre un ARRAY (OpenMP 4.5): cada hilo acumula
 *  en su copia de valor_de_funcion[0..E-1] y OpenMP las suma al final.
 *
 *  (Cocina: cuánto vale cada plato completo con las cantidades de hoy; cada cocinero
 *  lleva su cuenta y el jefe las suma.)
 * ------------------------------------------------------------------------------------- */
void evaluar_funciones(const double *punto, double *valor_de_funcion) {
    entero64 total_funciones = num_funciones;
    for (entero64 funcion = 0; funcion < total_funciones; funcion++) valor_de_funcion[funcion] = 0.0;
    /* OpenMP: bucle repartido entre los hilos; reparto elegido al ejecutar con -S (guided por
     * defecto); cada hilo suma en su copia privada de valor_de_funcion y al final OpenMP las
     * junta. (Cocina: los cocineros se reparten estas comandas; las comandas se cogen como diga el
     * jefe; cada cocinero su cuenco; al final se vuelcan todos en la olla.) */
    #pragma omp parallel for schedule(runtime) reduction(+:valor_de_funcion[:total_funciones])
    for (entero64 monomio = 0; monomio < num_monomios; monomio++) {
        double valor = coeficiente_del_monomio[monomio];
        for (entero64 factor = inicio_del_monomio[monomio]; factor < inicio_del_monomio[monomio + 1]; factor++) valor *= potencia_entera(punto[variable_del_factor[factor]], exponente_del_factor[factor]);
        valor_de_funcion[funcion_del_monomio[monomio]] += valor;
    }
}

/* -------------------------------------------------------------------------------------
 *  expandir_gradiente()
 *
 *  Para una sola función: pasa del Jacobiano disperso (solo entradas no nulas) al
 *  gradiente completo de N componentes, poniendo 0 en las variables que no aparecen.
 *
 *  (Cocina: escribir el tablón completo, con un 0 en los ingredientes que el plato no
 *  usa.)
 * ------------------------------------------------------------------------------------- */
void expandir_gradiente(const double *jacobiano, double *gradiente) {
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 variable = 0; variable < num_variables; variable++)
        gradiente[variable] = (inicio_entradas_de_variable[variable] < inicio_entradas_de_variable[variable + 1]) ? jacobiano[inicio_entradas_de_variable[variable]] : 0.0;
}

/* ---------- Impresión del PASO 3, como en el enunciado ---------- */
/* -------------------------------------------------------------------------------------
 *  imprimir_valor()
 *
 *  Imprime un número; si es negativo, entre paréntesis (como al sustituir a mano).
 *
 *  (Cocina: escribir una cantidad en la pizarra.)
 * ------------------------------------------------------------------------------------- */
static void imprimir_valor(double valor) {
    if (valor < 0) printf("(%g)", valor); else printf("%g", valor);
}

/* -------------------------------------------------------------------------------------
 *  imprimir_sustitucion()
 *
 *  Imprime una derivada con el punto ya sustituido: '3·2 + 2'. Solo para mostrar el
 *  PASO 3.
 *
 *  (Cocina: la ficha con las cantidades puestas en lugar de los nombres.)
 * ------------------------------------------------------------------------------------- */
static void imprimir_sustitucion(entero64 entrada, const double *punto) {
    if (entrada < 0) { printf("0"); return; }
    char nada_escrito = 1;
    for (entero64 derivado = inicio_derivados_de_entrada[entrada]; derivado < inicio_derivados_de_entrada[entrada + 1]; derivado++) {
        double coeficiente = coeficiente_del_derivado[derivado];
        int num_factores_monomio = (int)(inicio_del_derivado[derivado + 1] - inicio_del_derivado[derivado]);
        if (nada_escrito) { if (coeficiente < 0) printf("-"); }
        else      printf(coeficiente < 0 ? " - " : " + ");
        double valor_absoluto = fabs(coeficiente);
        int escribir_coeficiente = (valor_absoluto != 1.0 || num_factores_monomio == 0);
        if (escribir_coeficiente) printf("%g", valor_absoluto);
        for (entero64 factor = inicio_del_derivado[derivado]; factor < inicio_del_derivado[derivado + 1]; factor++) {
            if (escribir_coeficiente || factor > inicio_del_derivado[derivado]) printf("·");
            imprimir_valor(punto[variable_del_factor_derivado[factor]]);
            if (exponente_del_factor_derivado[factor] > 1) printf("^%d", exponente_del_factor_derivado[factor]);
        }
        nada_escrito = 0;
    }
    if (nada_escrito) printf("0");
}

/* -------------------------------------------------------------------------------------
 *  imprimir_paso3()
 *
 *  Imprime el PASO 3 como en el enunciado: cada derivada sustituida y su valor, y al
 *  final ∇f(punto) = (...) o la matriz J(punto).
 *
 *  (Cocina: el tablón con los números de hoy.)
 * ------------------------------------------------------------------------------------- */
void imprimir_paso3(const double *punto, const double *jacobiano) {
    char nombre_variable[64];
    printf("\nPASO 3. Evaluación numérica en el punto (");
    for (entero64 variable = 0; variable < num_variables; variable++) { nombre_de_variable(variable, nombre_variable, sizeof nombre_variable); printf("%s%s", variable ? ", " : "", nombre_variable); }
    printf(") = (");
    for (entero64 variable = 0; variable < num_variables; variable++) { if (variable) printf(", "); printf("%g", punto[variable]); }
    printf(")\n");

    for (entero64 funcion = 0; funcion < num_funciones; funcion++) {
        if (num_funciones > 1) printf("\n  f%lld:\n", funcion + 1);
        for (entero64 variable = 0; variable < num_variables; variable++) {
            entero64 entrada = buscar_entrada_jacobiano(funcion, variable);
            nombre_de_variable(variable, nombre_variable, sizeof nombre_variable);
            if (num_funciones == 1) printf("\n  ∂f/∂%s = ", nombre_variable);
            else          printf("  ∂f%lld/∂%s = ", funcion + 1, nombre_variable);
            imprimir_sustitucion(entrada, punto);
            printf(" = %g\n", entrada < 0 ? 0.0 : jacobiano[entrada]);
        }
    }

    printf("\n  %s(", num_funciones == 1 ? "∇f" : "J");
    for (entero64 variable = 0; variable < num_variables; variable++) { if (variable) printf(", "); printf("%g", punto[variable]); }
    printf(") = ");
    if (num_funciones == 1) {
        printf("(");
        for (entero64 variable = 0; variable < num_variables; variable++) {
            entero64 entrada = buscar_entrada_jacobiano(0, variable);
            printf("%s%g", variable ? ", " : "", entrada < 0 ? 0.0 : jacobiano[entrada]);
        }
        printf(")\n");
    } else {
        printf("\n");
        for (entero64 funcion = 0; funcion < num_funciones; funcion++) {
            printf("    [");
            for (entero64 variable = 0; variable < num_variables; variable++) {
                entero64 entrada = buscar_entrada_jacobiano(funcion, variable);
                printf(" %8g", entrada < 0 ? 0.0 : jacobiano[entrada]);
            }
            printf(" ]\n");
        }
    }
}

/* =====================================================================================
 *  MODELO DE BYTES (para calcular el ancho de banda conseguido, en GB/s)
 *  S = bytes de un índice (4 con tipo_indice de 32 bits, 8 con 64 bits)
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  bytes_movidos_estrategia()
 *
 *  Modelo de los bytes 'útiles' que una estrategia lee y escribe en UNA evaluación
 *  (índices, coeficientes, variables, exponentes, valores del punto, resultado).
 *  Dividido entre el tiempo da GB/s. Es una cota INFERIOR: un acceso salteado trae una
 *  línea entera de 64 B.
 *
 *  (Cocina: cuántos kilos tiene que traer el pinche del almacén para un pedido.)
 * ------------------------------------------------------------------------------------- */
double bytes_movidos_estrategia(int estrategia, int hilos) {
    double bytes_indice = sizeof(tipo_indice);
    double total_variables = num_variables, total_monomios = num_monomios, total_factores = num_factores, total_entradas = num_entradas_jacobiano, total_derivados = num_monomios_derivados, total_factores_derivados = num_factores_derivados;
    if (estrategia <= 3) {                       /* familia simbólica */
        double bytes = total_variables * bytes_indice                        /* col_start                       */
                 + total_entradas * (bytes_indice + 8)                /* inicio_derivados + escribir     */
                 + total_derivados * (bytes_indice + 8)                 /* inicio_del_derivado + coeficiente_del_derivado                */
                 + total_factores_derivados * (4 + 1 + 8);          /* variable_del_factor_derivado + exponente_del_factor_derivado + leer x[var]    */
        if (estrategia == 2) bytes += total_derivados * 16;               /* escribir y releer valor_de_cada_derivado          */
        return bytes;
    }
    double bytes = total_monomios * (bytes_indice + 8)                      /* inicio_del_monomio + coeficiente_del_monomio                */
             + total_factores * (4 + 1 + 8 + bytes_indice + 16);      /* var, exp, punto, entrada, J R+W */
    if (estrategia == 5) bytes += total_entradas * 8;                   /* poner el Jacobiano a 0          */
    if (estrategia == 6) bytes += hilos * total_entradas * 16 + total_entradas * 8;/* sumar y limpiar copias          */
    return bytes;
}

/* -------------------------------------------------------------------------------------
 *  bytes_movidos_lote()
 *
 *  Lo mismo que bytes_movidos_estrategia, para un lote de PUNTOS_POR_LOTE puntos.
 *
 *  (Cocina: los kilos para una bandeja de 8 pedidos.)
 * ------------------------------------------------------------------------------------- */
double bytes_movidos_lote(int estrategia_lote, int hilos) {
    double bytes_indice = sizeof(tipo_indice), puntos = PUNTOS_POR_LOTE;
    double total_variables = num_variables, total_monomios = num_monomios, total_factores = num_factores, total_entradas = num_entradas_jacobiano, total_derivados = num_monomios_derivados, total_factores_derivados = num_factores_derivados;
    if (estrategia_lote == 0)
        return total_variables * bytes_indice + total_entradas * (bytes_indice + 8 * puntos) + total_derivados * (bytes_indice + 8) + total_factores_derivados * (5 + 8 * puntos);
    return total_monomios * (bytes_indice + 8) + total_factores * (5 + 8 * puntos + bytes_indice + 16 * puntos) + hilos * total_entradas * puntos * 16 + total_entradas * puntos * 8;
}

/* =====================================================================================
 *  LOTES DE PUNTOS — leer cada monomio una vez para PUNTOS_POR_LOTE puntos
 *
 *  Evaluar P puntos uno a uno lee TODA la estructura (start, coef, var, expo...) P veces.
 *  En lotes de 8, la lee P/8 veces: por cada byte de estructura leído se hacen 8 veces
 *  más cuentas. Como el programa está limitado por la memoria, eso es lo que acelera.
 *  Además el bucle interno "for punto_lote < PUNTOS_POR_LOTE" hace la MISMA operación sobre 8 datos
 *  seguidos: el compilador lo convierte en instrucciones SIMD (#pragma omp simd).
 * ===================================================================================== */

/* -------------------------------------------------------------------------------------
 *  multiplicar_por_potencia_lote()
 *
 *  valores[b] *= bases[b]^exponente para los 8 puntos del lote, con exponenciación
 *  rápida. El bucle sobre el exponente es igual para los 8 y las cuentas se vectorizan
 *  con '#pragma omp simd'. Da exactamente lo mismo que potencia_entera.
 *
 *  (Cocina: una mano con 8 cucharones: la misma operación en 8 platos a la vez.)
 * ------------------------------------------------------------------------------------- */
static inline void multiplicar_por_potencia_lote(double *restrict valores, const double *restrict bases, int exponente) {
    double resultado[PUNTOS_POR_LOTE], base_al_cuadrado[PUNTOS_POR_LOTE];
    #pragma omp simd
    for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) { resultado[punto_lote] = 1.0; base_al_cuadrado[punto_lote] = bases[punto_lote]; }
    while (exponente > 0) {
        if (exponente & 1) {
            #pragma omp simd
            for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) resultado[punto_lote] *= base_al_cuadrado[punto_lote];
        }
        #pragma omp simd
        for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) base_al_cuadrado[punto_lote] *= base_al_cuadrado[punto_lote];
        exponente >>= 1;
    }
    #pragma omp simd
    for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) valores[punto_lote] *= resultado[punto_lote];
}

/* -------------------------------------------------------------------------------------
 *  lote_simbolico()
 *
 *  Como por_variables, pero cada monomio derivado se lee UNA vez y se evalúa en los 8
 *  puntos del lote. Los puntos van intercalados (puntos_lote[variable*8 + punto_lote])
 *  para que los 8 valores de una variable estén seguidos en memoria.
 *
 *  (Cocina: leer cada línea de la ficha una vez y aplicarla a una bandeja de 8
 *  pedidos.)
 * ------------------------------------------------------------------------------------- */
static void lote_simbolico(const double *puntos_lote, double *jacobianos_lote) {
    /* OpenMP: bucle repartido entre los hilos; reparto elegido al ejecutar con -S (guided por
     * defecto). (Cocina: los cocineros se reparten estas comandas; las comandas se cogen como diga
     * el jefe.) */
    #pragma omp parallel for schedule(runtime)
    for (entero64 variable = 0; variable < num_variables; variable++)
        for (entero64 entrada = inicio_entradas_de_variable[variable]; entrada < inicio_entradas_de_variable[variable + 1]; entrada++) {
            double sumas[PUNTOS_POR_LOTE];
            #pragma omp simd
            for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) sumas[punto_lote] = 0.0;
            for (entero64 derivado = inicio_derivados_de_entrada[entrada]; derivado < inicio_derivados_de_entrada[entrada + 1]; derivado++) {
                double valores[PUNTOS_POR_LOTE];
                double coeficiente = coeficiente_del_derivado[derivado];
                #pragma omp simd
                for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) valores[punto_lote] = coeficiente;
                for (entero64 factor = inicio_del_derivado[derivado]; factor < inicio_del_derivado[derivado + 1]; factor++)
                    multiplicar_por_potencia_lote(valores, puntos_lote + (entero64)variable_del_factor_derivado[factor] * PUNTOS_POR_LOTE, exponente_del_factor_derivado[factor]);
                #pragma omp simd
                for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) sumas[punto_lote] += valores[punto_lote];
            }
            #pragma omp simd
            for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) jacobianos_lote[entrada * PUNTOS_POR_LOTE + punto_lote] = sumas[punto_lote];
        }
}

/* -------------------------------------------------------------------------------------
 *  lote_directo()
 *
 *  Como directo_privado, pero en lotes de 8 puntos: cada monomio original se lee una
 *  vez y se derivan todas sus variables en los 8 puntos (productos por la izquierda y
 *  la derecha vectorizados). Cada hilo suma en su copia privada; al final, sumar y
 *  limpiar.
 *
 *  (Cocina: leer cada línea de la receta original una vez y repartir su aportación a
 *  las fichas de 8 pedidos, cada cocinero en su libreta.)
 * ------------------------------------------------------------------------------------- */
static void lote_directo(const double *puntos_lote, double *jacobianos_lote) {
    /* OpenMP: se abre un equipo de hilos y TODOS ejecutan el bloque. (Cocina: ¡todos a cocinar!) */
    #pragma omp parallel
    {
        int total_hilos  = omp_get_num_threads();
        int mi_hilo = omp_get_thread_num();
        double *mi_copia = copias_privadas_lote[mi_hilo];
        double potencias[MAX_VARIABLES_POR_MONOMIO][PUNTOS_POR_LOTE], derivadas_de_potencias[MAX_VARIABLES_POR_MONOMIO][PUNTOS_POR_LOTE], producto_izquierda[PUNTOS_POR_LOTE], producto_derecha[MAX_VARIABLES_POR_MONOMIO + 1][PUNTOS_POR_LOTE];

        /* OpenMP: los hilos del equipo se reparten este bucle; al acabar se esperan (barrera
         * implícita); reparto elegido al ejecutar con -S (guided por defecto). (Cocina: reparto de
         * comandas entre los que ya están cocinando; las comandas se cogen como diga el jefe.) */
        #pragma omp for schedule(runtime)
        for (entero64 monomio = 0; monomio < num_monomios; monomio++) {
            entero64 primer_factor = inicio_del_monomio[monomio];
            int num_factores_monomio = (int)(inicio_del_monomio[monomio + 1] - primer_factor);
            for (int posicion = 0; posicion < num_factores_monomio; posicion++) {
                int exponente = exponente_del_factor[primer_factor + posicion];
                const double *valores_variable = puntos_lote + (entero64)variable_del_factor[primer_factor + posicion] * PUNTOS_POR_LOTE;
                double potencia_menos_uno[PUNTOS_POR_LOTE];
                #pragma omp simd
                for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) potencia_menos_uno[punto_lote] = 1.0;
                multiplicar_por_potencia_lote(potencia_menos_uno, valores_variable, exponente - 1);                 /* x^(e-1) */
                #pragma omp simd
                for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) { derivadas_de_potencias[posicion][punto_lote] = exponente * potencia_menos_uno[punto_lote]; potencias[posicion][punto_lote] = potencia_menos_uno[punto_lote] * valores_variable[punto_lote]; }
            }
            #pragma omp simd
            for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) producto_derecha[num_factores_monomio][punto_lote] = 1.0;
            for (int posicion = num_factores_monomio - 1; posicion >= 0; posicion--) {
                #pragma omp simd
                for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) producto_derecha[posicion][punto_lote] = producto_derecha[posicion + 1][punto_lote] * potencias[posicion][punto_lote];
            }
            double coeficiente = coeficiente_del_monomio[monomio];
            #pragma omp simd
            for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) producto_izquierda[punto_lote] = coeficiente;
            for (int posicion = 0; posicion < num_factores_monomio; posicion++) {
                double *destino = mi_copia + (entero64)entrada_del_factor[primer_factor + posicion] * PUNTOS_POR_LOTE;
                #pragma omp simd
                for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) {
                    destino[punto_lote] += producto_izquierda[punto_lote] * derivadas_de_potencias[posicion][punto_lote] * producto_derecha[posicion + 1][punto_lote];
                    producto_izquierda[punto_lote] *= potencias[posicion][punto_lote];
                }
            }
        }

        /* OpenMP: los hilos del equipo se reparten este bucle; al acabar se esperan (barrera
         * implícita); reparto fijo a partes iguales. (Cocina: reparto de comandas entre los que ya
         * están cocinando; a cada uno el mismo número de comandas, decidido antes de empezar.) */
        #pragma omp for schedule(static)                    /* sumar y limpiar */
        for (entero64 casilla = 0; casilla < num_entradas_jacobiano * PUNTOS_POR_LOTE; casilla++) {
            double suma = 0.0;
            for (int hilo = 0; hilo < total_hilos; hilo++) { suma += copias_privadas_lote[hilo][casilla]; copias_privadas_lote[hilo][casilla] = 0.0; }
            jacobianos_lote[casilla] = suma;
        }
    }
}

const char *nombre_estrategia_lote[NUM_ESTRATEGIAS_LOTE] = { "lote_simbolico", "lote_directo" };
tipo_funcion_lote    funcion_estrategia_lote[NUM_ESTRATEGIAS_LOTE]   = { lote_simbolico, lote_directo };

/* -------------------------------------------------------------------------------------
 *  lote_disponible()
 *
 *  Dice si una estrategia de lote se puede usar; la directa reserva sus copias privadas
 *  la primera vez que se usa (si caben en LIMITE_MEMORIA).
 *
 *  (Cocina: ¿hay bandejas y libretas para los 8 pedidos?)
 * ------------------------------------------------------------------------------------- */
int lote_disponible(int estrategia_lote, int hilos) {
    if (estrategia_lote == 0) return derivadas_construidas;
    if (copias_privadas_lote == NULL) {                               /* se reservan al primer uso */
        double bytes = (double)hilos * num_entradas_jacobiano * PUNTOS_POR_LOTE * sizeof(double);
        if (bytes > LIMITE_MEMORIA) return 0;
        copias_privadas_lote = reservar(sizeof(double *) * hilos, "copias_privadas_lote");
        num_copias_privadas_lote = hilos;
        /* OpenMP: se abre un equipo de hilos y TODOS ejecutan el bloque; con hilos hilos. (Cocina:
         * ¡todos a cocinar!; solo trabajan hilos cocineros.) */
        #pragma omp parallel num_threads(hilos)
        {
            int mi_hilo = omp_get_thread_num();
            copias_privadas_lote[mi_hilo] = reservar_cero((size_t)num_entradas_jacobiano * PUNTOS_POR_LOTE, sizeof(double), "copias_privadas_lote");
        }
    }
    return hilos <= num_copias_privadas_lote;
}
