/* =====================================================================================
 *  generador.c — PROGRAMA EXTERNO que genera funciones o sistemas de prueba y los guarda
 *                en un fichero, para dárselos después a ./gradiente con -f.
 *
 *  Separar la generación del cálculo permite:
 *    - medir por separado el tiempo de generar los datos y el de calcular
 *    - repetir exactamente el mismo problema en distintas máquinas o versiones
 *      (secuencial, OpenMP, CUDA) leyendo el mismo fichero
 *
 *  Uso:
 *    ./generador -n 1000000 -m 10000000 -o problema.bin     (binario: rápido)
 *    ./generador -n 50 -m 200 -E 3 -o sistema.txt            (texto: legible)
 *    ./gradiente -f problema.bin -b
 *
 *  (Cocina: el inventor de recetas trabajando en OTRA cocina: deja el libro en la
 *  cámara (un fichero) para que el restaurante lo use después; así se cronometra por
 *  separado inventar y cocinar.)
 * ===================================================================================== */
#include <unistd.h>
#include "comun.h"
#include "polinomio.h"
#include "punto.h"

/* -------------------------------------------------------------------------------------
 *  main()
 *
 *  Programa externo: lee las opciones, genera la función (y un punto) con los mismos
 *  parámetros que ./gradiente, la guarda en un fichero (.bin binario, si no texto) y,
 *  si se pide con -p, el punto en otro fichero. Cronometra la generación y la escritura
 *  por separado.
 *
 *  (Cocina: el inventor de recetas trabaja en otra cocina y nos deja el libro en la
 *  cámara.)
 * ------------------------------------------------------------------------------------- */
int main(int argc, char **argv) {
    double inicio_programa = omp_get_wtime();
    entero64 total_variables = 100000, monomios_por_funcion = 1000000, total_funciones = 1, ventana = 0;
    int max_variables_por_monomio = 8, max_exponente = 3, desordenar = 0, guardar_punto = 1;
    unsigned long long semilla = 12345;
    char *fichero_salida = NULL, *fichero_punto = NULL;

    int opcion;
    while ((opcion = getopt(argc, argv, "n:m:E:k:e:s:L:ZNo:p:h")) != -1) {
        switch (opcion) {
            case 'n': total_variables = atoll(optarg); break;
            case 'm': monomios_por_funcion = atoll(optarg); break;
            case 'E': total_funciones = atoll(optarg); break;
            case 'k': max_variables_por_monomio = atoi(optarg); break;
            case 'e': max_exponente = atoi(optarg); break;
            case 's': semilla = strtoull(optarg, NULL, 10); break;
            case 'L': ventana = atoll(optarg); break;
            case 'Z': desordenar = 1; break;
            case 'N': guardar_punto = 0; break;
            case 'o': fichero_salida = optarg; break;
            case 'p': fichero_punto = optarg; break;
            default:
                printf("Uso: %s -o FICHERO [opciones]\n"
                       "  -n N   variables (%lld)        -m M   monomios por función (%lld)\n"
                       "  -E E   funciones (%lld)          -k K   máx. variables por monomio (%d)\n"
                       "  -e X   máx. exponente (%d)      -s S   semilla (%llu)\n"
                       "  -L W   estructura local (ventana W)   -Z  desordenar variables\n"
                       "  -N     no guardar el punto dentro del fichero de la función\n"
                       "  -p F   guardar además el punto en un fichero de datos aparte (para -F)\n"
                       "  FICHERO terminado en .bin -> binario; cualquier otro -> texto\n",
                       argv[0], total_variables, monomios_por_funcion, total_funciones, max_variables_por_monomio, max_exponente, semilla);
                return opcion == 'h' ? 0 : 1;
        }
    }
    if (fichero_salida == NULL) { fprintf(stderr, "Falta -o FICHERO (usa -h para ver la ayuda)\n"); return 1; }
    if (total_variables <= 0 || monomios_por_funcion <= 0 || total_funciones <= 0 || total_variables > 2147483647LL) { fprintf(stderr, "Tamaños no válidos\n"); return 1; }
    if (max_exponente < 1) max_exponente = 1;
    if (max_exponente > 255) max_exponente = 255;

    double inicio_reloj = omp_get_wtime();
    generar_funcion_aleatoria(total_funciones, total_variables, monomios_por_funcion, max_variables_por_monomio, max_exponente, semilla, ventana, desordenar);
    double *punto = reservar(sizeof(double) * num_variables, "punto");
    generar_valores_aleatorios(num_variables, semilla, punto);
    double tiempo_generacion = omp_get_wtime() - inicio_reloj;

    inicio_reloj = omp_get_wtime();
    escribir_funcion_en_fichero(fichero_salida, guardar_punto ? punto : NULL);
    if (fichero_punto) { escribir_punto_en_fichero(fichero_punto, punto); printf("Punto guardado en '%s'\n", fichero_punto); }
    double tiempo_escritura = omp_get_wtime() - inicio_reloj;

    printf("  %lld funciones, %lld variables, %lld monomios, %lld casillas (%d hilos)\n",
           num_funciones, num_variables, num_monomios, num_factores, omp_get_max_threads());
    printf("  Tiempo de generación: %.3f s   |   escritura: %.3f s   |   total: %.3f s\n",
           tiempo_generacion, tiempo_escritura, omp_get_wtime() - inicio_programa);
    free(punto);
    liberar_funcion();
    return 0;
}
