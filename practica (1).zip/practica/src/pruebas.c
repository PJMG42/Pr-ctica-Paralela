/* =====================================================================================
 *  pruebas.c — Batería de pruebas automáticas
 *
 *  (Cocina: la visita del catador (ver pruebas.h).)
 * ===================================================================================== */
#include "pruebas.h"
#include "comun.h"
#include "polinomio.h"
#include "derivadas.h"
#include "evaluacion.h"
#include "experimentos.h"
#include "reordenar.h"

#define TOLERANCIA 1e-12

static int fallos = 0, total = 0;

/* -------------------------------------------------------------------------------------
 *  anotar_resultado()
 *
 *  Apunta una prueba como OK o FALLO (con el detalle) y lleva la cuenta.
 *
 *  (Cocina: el catador marca cada plato como bueno o malo.)
 * ------------------------------------------------------------------------------------- */
static void anotar_resultado(int todo_correcto, const char *nombre, const char *detalle) {
    total++;
    if (todo_correcto) printf("  [ OK  ] %s\n", nombre);
    else  { printf("  [FALLO] %s  -> %s\n", nombre, detalle); fallos++; }
}

/* =====================================================================================
 *  1. ECUACIONES DE PRUEBA CON RESULTADO CONOCIDO
 *     esperado: Jacobiano denso E×N por filas (para E = 1, el gradiente)
 * ===================================================================================== */
#define NUM_PRUEBAS_FIJAS 8
static const char *nombre_prueba_fija[NUM_PRUEBAS_FIJAS] = {
    "Ejemplo del enunciado: 3xy + 4yz + 2x + 5 en (1,2,3)",
    "Sistema del enunciado (3 ecuaciones) en (1,2,3)",
    "Solo una constante: f = 7",
    "Exponente alto: x^10 en x = 2",
    "Coeficientes negativos y variable repetida: -2*x*x*y + 3*y^0",
    "Variable que no aparece: x*y en (2,3,4)",
    "Nombres largos: 0.5*masa*vel^2 + 9.81*masa*altura",
    "Notación pegada del enunciado: yz3 + x2 en (1,2,3)",
};
static const char *texto_prueba_fija[NUM_PRUEBAS_FIJAS] = {
    "variables: x y z\nf: 3xy + 4yz + 2x + 5\npunto: 1 2 3\n",
    "variables: x y z\nf1: 3x^2 + yz + z + 5 = 2\nf2: 2x + yz^3 + 2x + 2 = 0\n"
        "f3: 3xz + 8yz + z^2 + 1 = 4\npunto: 1 2 3\n",
    "variables: x y\nf: 7\npunto: 5 6\n",
    "variables: x\nf: x^10\npunto: 2\n",
    "variables: x y\nf: -2*x*x*y + 3*y^0\npunto: 1.5 -2\n",
    "variables: x y z\nf: x*y\npunto: 2 3 4\n",
    "variables: masa vel altura\nenergia: 0.5*masa*vel^2 + 9.81*masa*altura\npunto: 2 3 10\n",
    "variables: x y z\nf: yz3 + x2\npunto: 1 2 3\n",
};
static const double jacobiano_esperado_0[] = {8, 15, 8};
static const double jacobiano_esperado_1[] = {6, 3, 3,   4, 27, 54,   9, 24, 25};
static const double jacobiano_esperado_2[] = {0, 0};
static const double jacobiano_esperado_3[] = {5120};
static const double jacobiano_esperado_4[] = {12, -4.5};          /* d/dx = -4xy, d/dy = -2x^2 */
static const double jacobiano_esperado_5[] = {3, 2, 0};
static const double jacobiano_esperado_6[] = {102.6, 6, 19.62};
static const double jacobiano_esperado_7[] = {2, 27, 54};
static const double *jacobiano_esperado[NUM_PRUEBAS_FIJAS] = { jacobiano_esperado_0, jacobiano_esperado_1, jacobiano_esperado_2, jacobiano_esperado_3, jacobiano_esperado_4, jacobiano_esperado_5, jacobiano_esperado_6, jacobiano_esperado_7 };
static const double valor_esperado_funcion[NUM_PRUEBAS_FIJAS][3] = {          /* f(x) esperado (F para sistemas) */
    {37}, {15, 60, 63}, {7}, {1024}, {12}, {6}, {205.2}, {55},   /* -2·2,25·(-2) + 3 = 12 */
};

/* -------------------------------------------------------------------------------------
 *  prueba_fija()
 *
 *  Prueba una ecuación de resultado conocido: comprueba f(x) y, con TODAS las
 *  estrategias y con 1, 2, ..., hilos hilos, que cada derivada vale lo esperado
 *  (tolerancia 1e-12).
 *
 *  (Cocina: un plato cuyo sabor exacto ya conocemos; da igual cuántos cocineros lo
 *  hagan.)
 * ------------------------------------------------------------------------------------- */
static void prueba_fija(int numero_prueba, int hilos) {
    leer_funcion_de_texto(texto_prueba_fija[numero_prueba]);
    double tiempo_indice, tiempo_simbolico;
    derivar_simbolicamente(1, &tiempo_indice, &tiempo_simbolico);
    preparar_evaluacion(hilos);
    double *punto = punto_del_fichero;
    double *jacobiano = reservar(sizeof(double) * (num_entradas_jacobiano > 0 ? num_entradas_jacobiano : 1), "jacobiano");
    double *valor_de_funcion = reservar(sizeof(double) * num_funciones, "valor_de_funcion");
    char detalle[256] = "";
    int todo_correcto = 1;

    evaluar_funciones(punto, valor_de_funcion);
    for (entero64 funcion = 0; funcion < num_funciones; funcion++)
        if (fabs(valor_de_funcion[funcion] - valor_esperado_funcion[numero_prueba][funcion]) > TOLERANCIA * (1 + fabs(valor_esperado_funcion[numero_prueba][funcion]))) {
            todo_correcto = 0; snprintf(detalle, sizeof detalle, "f%lld(x) = %g, esperado %g", funcion + 1, valor_de_funcion[funcion], valor_esperado_funcion[numero_prueba][funcion]);
        }

    for (int estrategia = 0; estrategia < NUM_ESTRATEGIAS && todo_correcto; estrategia++) {
        for (int hilos_prueba = 1; hilos_prueba <= hilos && todo_correcto; hilos_prueba++) {
            if (!estrategia_disponible(estrategia, hilos_prueba)) continue;
            omp_set_num_threads(hilos_prueba);
            funcion_estrategia[estrategia](punto, jacobiano);
            for (entero64 funcion = 0; funcion < num_funciones && todo_correcto; funcion++)
                for (entero64 variable = 0; variable < num_variables && todo_correcto; variable++) {
                    entero64 entrada = buscar_entrada_jacobiano(funcion, variable);
                    double valor = entrada < 0 ? 0.0 : jacobiano[entrada], esperado = jacobiano_esperado[numero_prueba][funcion * num_variables + variable];
                    if (fabs(valor - esperado) > TOLERANCIA * (1 + fabs(esperado))) {
                        todo_correcto = 0;
                        snprintf(detalle, sizeof detalle, "%s con %d hilos: J[%lld][%lld] = %g, esperado %g",
                                 nombre_estrategia[estrategia], hilos_prueba, funcion + 1, variable + 1, valor, esperado);
                    }
                }
        }
    }
    anotar_resultado(todo_correcto, nombre_prueba_fija[numero_prueba], detalle);
    free(jacobiano); free(valor_de_funcion);
    liberar_evaluacion(); liberar_derivadas(); liberar_funcion();
    omp_set_num_threads(hilos);
}

/* =====================================================================================
 *  2. PROBLEMAS ALEATORIOS: secuencial == paralelo
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  prueba_aleatoria()
 *
 *  Prueba un problema aleatorio: (a) todas las estrategias y números de hilos frente al
 *  secuencial (por_variables y por_monomios deben ser idénticas bit a bit); (b) los
 *  lotes de 8 puntos frente a evaluar punto a punto; (c) con una sola función, que
 *  reordenar no cambia el gradiente.
 *
 *  (Cocina: recetas inventadas grandes: el plato de muchos cocineros debe saber igual
 *  que el de uno solo.)
 * ------------------------------------------------------------------------------------- */
static void prueba_aleatoria(const char *nombre, entero64 total_funciones, entero64 total_variables, entero64 monomios_por_funcion, entero64 ventana, int desordenar, int hilos) {
    omp_set_num_threads(hilos);
    generar_funcion_aleatoria(total_funciones, total_variables, monomios_por_funcion, 8, 3, 777, ventana, desordenar);
    double *punto = reservar(sizeof(double) * num_variables, "punto");
    generar_valores_aleatorios(num_variables, 99, punto);
    double tiempo_indice, tiempo_simbolico;
    derivar_simbolicamente(1, &tiempo_indice, &tiempo_simbolico);
    preparar_evaluacion(hilos);
    entero64 tamano_jacobiano = num_entradas_jacobiano > 0 ? num_entradas_jacobiano : 1;
    double *jacobiano_referencia = reservar(sizeof(double) * tamano_jacobiano, "jacobiano_referencia");
    double *jacobiano    = reservar(sizeof(double) * tamano_jacobiano, "jacobiano");
    char detalle[256] = "";
    int todo_correcto = 1;

    omp_set_num_threads(1);
    funcion_estrategia[0](punto, jacobiano_referencia);

    /* 2a. Todas las estrategias, todos los nº de hilos */
    for (int estrategia = 1; estrategia < NUM_ESTRATEGIAS && todo_correcto; estrategia++)
        for (int hilos_prueba = 1; hilos_prueba <= hilos && todo_correcto; hilos_prueba++) {
            if (!estrategia_disponible(estrategia, hilos_prueba)) continue;
            if (estrategia == 3) { hilos_nivel_externo = hilos_prueba > 1 ? hilos_prueba / 2 : 1; hilos_nivel_interno = hilos_prueba > 1 ? 2 : 1; umbral_anidado = 1; }
            omp_set_num_threads(hilos_prueba);
            funcion_estrategia[estrategia](punto, jacobiano);
            double error = error_relativo_maximo(jacobiano, jacobiano_referencia, num_entradas_jacobiano);
            int identico_bit_a_bit = memcmp(jacobiano, jacobiano_referencia, sizeof(double) * num_entradas_jacobiano) == 0;
            int debe_ser_identico = (estrategia == 1 || estrategia == 2);         /* mismo orden de suma */
            if ((debe_ser_identico && !identico_bit_a_bit) || error > TOLERANCIA) {
                todo_correcto = 0;
                snprintf(detalle, sizeof detalle, "%s con %d hilos: error %.1e%s", nombre_estrategia[estrategia], hilos_prueba, error,
                         debe_ser_identico && !identico_bit_a_bit ? " (debería ser idéntico bit a bit)" : "");
            }
        }
    umbral_anidado = 1000;
    anotar_resultado(todo_correcto, nombre, detalle);

    /* 2b. Lotes de 8 puntos frente a punto a punto */
    todo_correcto = 1; detalle[0] = '\0';
    double *puntos_lote = reservar(sizeof(double) * num_variables * PUNTOS_POR_LOTE, "puntos_lote");
    double *jacobianos_lote = reservar(sizeof(double) * tamano_jacobiano * PUNTOS_POR_LOTE, "jacobianos_lote");
    double *un_punto = reservar(sizeof(double) * num_variables, "un_punto");
    for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++) {                      /* 8 puntos distintos */
        generar_valores_aleatorios(num_variables, 1000 + punto_lote, un_punto);
        for (entero64 variable = 0; variable < num_variables; variable++) puntos_lote[variable * PUNTOS_POR_LOTE + punto_lote] = un_punto[variable];
    }
    for (int estrategia_lote = 0; estrategia_lote < NUM_ESTRATEGIAS_LOTE && todo_correcto; estrategia_lote++) {
        if (!lote_disponible(estrategia_lote, hilos)) continue;
        omp_set_num_threads(hilos);
        funcion_estrategia_lote[estrategia_lote](puntos_lote, jacobianos_lote);
        omp_set_num_threads(1);
        for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE && todo_correcto; punto_lote++) {
            for (entero64 variable = 0; variable < num_variables; variable++) un_punto[variable] = puntos_lote[variable * PUNTOS_POR_LOTE + punto_lote];
            funcion_estrategia[0](un_punto, jacobiano_referencia);
            for (entero64 entrada = 0; entrada < num_entradas_jacobiano; entrada++) jacobiano[entrada] = jacobianos_lote[entrada * PUNTOS_POR_LOTE + punto_lote];
            double error = error_relativo_maximo(jacobiano, jacobiano_referencia, num_entradas_jacobiano);
            if (error > TOLERANCIA) { todo_correcto = 0; snprintf(detalle, sizeof detalle, "%s, punto %d: error %.1e", nombre_estrategia_lote[estrategia_lote], punto_lote, error); }
        }
    }
    char nombre_completo[160]; snprintf(nombre_completo, sizeof nombre_completo, "%s — lotes de %d puntos", nombre, PUNTOS_POR_LOTE);
    anotar_resultado(todo_correcto, nombre_completo, detalle);

    /* 2c. Reordenar no cambia el resultado (solo una función: se compara el gradiente) */
    if (total_funciones == 1) {
        double *gradiente_original = reservar(sizeof(double) * num_variables, "gradiente_original");
        double *gradiente_reordenado = reservar(sizeof(double) * num_variables, "gradiente_reordenado");
        omp_set_num_threads(1);
        funcion_estrategia[0](punto, jacobiano_referencia);
        expandir_gradiente(jacobiano_referencia, gradiente_original);
        liberar_evaluacion(); liberar_derivadas();
        omp_set_num_threads(hilos);
        reordenar_variables_y_monomios(punto);
        derivar_simbolicamente(1, &tiempo_indice, &tiempo_simbolico);
        preparar_evaluacion(hilos);
        free(jacobiano_referencia); free(jacobiano);
        tamano_jacobiano = num_entradas_jacobiano > 0 ? num_entradas_jacobiano : 1;
        jacobiano_referencia = reservar(sizeof(double) * tamano_jacobiano, "jacobiano_referencia"); jacobiano = reservar(sizeof(double) * tamano_jacobiano, "jacobiano");
        funcion_estrategia[1](punto, jacobiano);
        double *gradiente_permutado = reservar(sizeof(double) * num_variables, "gradiente_permutado");
        expandir_gradiente(jacobiano, gradiente_permutado);
        volver_al_orden_original(gradiente_permutado, gradiente_reordenado);
        double error = error_relativo_maximo(gradiente_reordenado, gradiente_original, num_variables);
        snprintf(detalle, sizeof detalle, "error %.1e", error);
        snprintf(nombre_completo, sizeof nombre_completo, "%s — reordenado (BFS)", nombre);
        anotar_resultado(error <= TOLERANCIA, nombre_completo, detalle);
        free(gradiente_original); free(gradiente_reordenado); free(gradiente_permutado);
    }

    free(punto); free(jacobiano_referencia); free(jacobiano); free(puntos_lote); free(jacobianos_lote); free(un_punto);
    liberar_evaluacion(); liberar_derivadas(); liberar_funcion();
    omp_set_num_threads(hilos);
}

/* -------------------------------------------------------------------------------------
 *  ejecutar_pruebas()
 *
 *  Ejecuta toda la batería (8 ecuaciones fijas y 4 problemas aleatorios) y devuelve el
 *  número de fallos (0 = todo bien).
 *
 *  (Cocina: la visita completa del catador.)
 * ------------------------------------------------------------------------------------- */
int ejecutar_pruebas(int hilos) {
    fallos = 0; total = 0;
    imprimir_linea();
    printf("PRUEBAS AUTOMÁTICAS (hasta %d hilos, índices de %d bits)\n\n", hilos, BITS_INDICE);
    printf(" Ecuaciones de prueba con resultado conocido (todas las estrategias, 1..%d hilos):\n", hilos);
    for (int numero_prueba = 0; numero_prueba < NUM_PRUEBAS_FIJAS; numero_prueba++) prueba_fija(numero_prueba, hilos);

    printf("\n Problemas aleatorios: paralelo == secuencial:\n");
    prueba_aleatoria("Gradiente, 1000 variables, 20.000 monomios", 1, 1000, 20000, 0, 0, hilos);
    prueba_aleatoria("Gradiente, 20 variables (muchos conflictos)", 1, 20, 20000, 0, 0, hilos);
    prueba_aleatoria("Gradiente, estructura local desordenada", 1, 5000, 20000, 32, 1, hilos);
    prueba_aleatoria("Sistema de 5 ecuaciones, 500 variables", 5, 500, 4000, 0, 0, hilos);

    imprimir_linea();
    if (fallos == 0) printf("RESULTADO: %d de %d pruebas correctas\n", total, total);
    else             printf("RESULTADO: %d FALLOS de %d pruebas\n", fallos, total);
    imprimir_linea();
    return fallos;
}
