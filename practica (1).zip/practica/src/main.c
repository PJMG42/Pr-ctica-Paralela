/* =====================================================================================
 *  main.c — Cálculo paralelo (OpenMP) del gradiente de funciones multivariables
 *           y del Jacobiano de sistemas de ecuaciones.
 *
 *  Sigue el método del enunciado:
 *     PASO 1  Derivadas parciales (simbólicas)          -> derivadas.c
 *     PASO 2  Formulación del gradiente / Jacobiano     -> derivadas.c
 *     PASO 3  Evaluación numérica en un punto           -> evaluacion.c
 *
 *  Uso rápido:
 *     ./gradiente -x                 ejemplo del enunciado: f = 3xy + 4yz + 2x + 5 en (1,2,3)
 *     ./gradiente -X                 sistema de 3 ecuaciones del enunciado (Jacobiano)
 *     ./gradiente -f mi_funcion.txt  función o sistema escrito en un fichero
 *     ./gradiente -n 1000000 -m 10000000 -b -A -l -C -B     problema grande + estudios
 *     ./gradiente -h                 todas las opciones
 *
 *  (Cocina: la RECEPCIÓN del restaurante: apunta el pedido (opciones), trae la receta,
 *  manda escribir las fichas, recibe las cantidades, organiza a los cocineros, llama al
 *  catador y al final entrega la hoja de tiempos.)
 * ===================================================================================== */
#include <unistd.h>
#include "comun.h"
#include "polinomio.h"
#include "derivadas.h"
#include "evaluacion.h"
#include "experimentos.h"
#include "reordenar.h"
#include "pruebas.h"
#include "punto.h"

/* ---------- Configuración ---------- */
static entero64   opcion_num_variables = 100000, opcion_monomios_por_funcion = 1000000, opcion_num_funciones = 1, opcion_ventana_localidad = 0;
static int   opcion_max_variables_monomio = 8, opcion_max_exponente = 3, num_hilos = 0, opcion_repeticiones = 3;
static unsigned long long opcion_semilla = 12345;
static int   opcion_ejemplo = 0, opcion_sistema_ejemplo = 0, opcion_escalabilidad_fuerte = 0, opcion_estudio_anidado = 0;
static int   opcion_num_puntos = 0, opcion_sin_paso1 = 0, opcion_imprimir_pasos = -1, opcion_hilos_externos = 0, opcion_hilos_internos = 0;
static int   opcion_desordenar = 0, opcion_reordenar = 0, opcion_estudio_lotes = 0, opcion_estudio_bloque = 0;
static int   opcion_escalabilidad_debil = 0, opcion_medir_ancho_banda = 0, opcion_pruebas = 0;
static char *opcion_fichero_funcion = NULL, *opcion_fichero_salida = NULL, *opcion_fichero_gradiente = NULL;
static char *opcion_reparto = "guided";
static int   origen_del_punto = PUNTO_ORIGEN;            /* origen del punto: fijado al compilar */
static int   origen_elegido_al_ejecutar = 0;
static const char *fichero_del_punto = PUNTO_FICHERO;

/* -------------------------------------------------------------------------------------
 *  ayuda()
 *
 *  Imprime todas las opciones del programa (-h).
 *
 *  (Cocina: la carta de servicios de la recepción.)
 * ------------------------------------------------------------------------------------- */
static void ayuda(const char *nombre_programa) {
    printf("Uso: %s [opciones]\n\n"
           "  Función a derivar:\n"
           "    -x          ejemplo del enunciado: f(x,y,z) = 3xy + 4yz + 2x + 5, punto (1,2,3)\n"
           "    -X          sistema de 3 ecuaciones del enunciado (Jacobiano), punto (1,2,3)\n"
           "    -f FICH     lee la función / sistema de un fichero (formato en el README)\n"
           "    (sin -x/-X/-f se genera una aleatoria con estos parámetros:)\n"
           "    -n N        nº de variables                 (defecto %lld)\n"
           "    -m M        nº de monomios POR función      (defecto %lld)\n"
           "    -E E        nº de funciones (ecuaciones)    (defecto %lld)\n"
           "    -k K        máx. variables por monomio      (defecto %d, máx. %d)\n"
           "    -e EXP      máx. exponente                  (defecto %d)\n"
           "    -s S        semilla aleatoria               (defecto %llu)\n"
           "    -L W        estructura local: variables de cada monomio dentro de una ventana W\n"
           "    -Z          desordenar la numeración de variables (simula una entrada mal numerada)\n\n"
           "  Paralelismo y optimizaciones:\n"
           "    -t T        nº de hilos                     (defecto: nº de núcleos)\n"
           "    -S tipo     reparto: static | dynamic[,c] | guided[,c]   (defecto guided)\n"
           "    -r R        repeticiones por medida (se toma la mejor)   (defecto %d)\n"
           "    -a T1xT2    hilos de la estrategia anidada en la tabla   (ej. 8x2)\n"
           "    -u U        umbral de monomios para abrir equipo interno (defecto %lld)\n"
           "    -R          reordenar variables y monomios (BFS tipo Cuthill-McKee)\n"
           "    -D          no materializar el PASO 1 (solo estrategias directas; ahorra memoria)\n\n"
           "  Estudios:\n"
           "    -b          escalabilidad fuerte: 1, 2, 4, ..., T hilos con el mismo problema\n"
           "    -W          escalabilidad débil: el problema crece con los hilos (-n y -m por hilo)\n"
           "    -A          paralelismo anidado (todas las combinaciones T1×T2)\n"
           "    -l          lotes: leer cada monomio una vez para %d puntos (SIMD)\n"
           "    -P PUNTOS   nº de puntos para -A y -l    (defecto: T para -A, 64 para -l)\n"
           "    -C          tamaño de bloque del reparto (static / dynamic,c / guided,c)\n"
           "    -B          medir el ancho de banda pico de la RAM (STREAM triad) -> columna %%pico\n"
           "    -T          batería de pruebas automáticas (también: make test)\n\n"
           "  Punto donde se evalúa y valida el gradiente:\n"
           "    -O origen   auto | teclado | fichero | aleatorio | interactivo\n"
           "                (por defecto el elegido al compilar: make PUNTO=...)\n"
           "    -F FICH     leer el punto de un fichero de datos (implica -O fichero)\n"
           "    -I          modo interactivo: tras derivar, se elige con un comando de dónde leer\n"
           "                el punto, y se puede evaluar en varios puntos (= -O interactivo)\n\n"
           "  Salida:\n"
           "    -p / -q     forzar / ocultar la impresión de los pasos 1-2-3\n"
           "    -o FICH     guarda la función (y el punto) en formato de texto\n"
           "    -G FICH     guarda el gradiente (o el Jacobiano) calculado\n"
           "    -h          esta ayuda\n\n"
           "  Afinidad de hilos: variables de entorno (ver afinidad.sh), p. ej.\n"
           "    OMP_PROC_BIND=close OMP_PLACES=cores %s ...\n",
           nombre_programa, opcion_num_variables, opcion_monomios_por_funcion, opcion_num_funciones, opcion_max_variables_monomio, MAX_VARIABLES_POR_MONOMIO, opcion_max_exponente, opcion_semilla, opcion_repeticiones,
           umbral_anidado, PUNTOS_POR_LOTE, nombre_programa);
}

/* -------------------------------------------------------------------------------------
 *  aplicar_reparto()
 *
 *  Traduce el texto de -S ('static', 'dynamic,64', 'guided,16'...) a omp_set_schedule.
 *  Lo usan las estrategias con schedule(runtime).
 *
 *  (Cocina: decir a los cocineros cómo cogen las comandas del gancho.)
 * ------------------------------------------------------------------------------------- */
static void aplicar_reparto(const char *texto) {
    char copia[64];
    strncpy(copia, texto, sizeof copia - 1);
    copia[sizeof copia - 1] = '\0';
    int tamano_bloque = 0;
    char *posicion_coma = strchr(copia, ',');
    if (posicion_coma) { *posicion_coma = '\0'; tamano_bloque = atoi(posicion_coma + 1); }
    omp_sched_t tipo_reparto;
    if      (strcmp(copia, "static")  == 0) tipo_reparto = omp_sched_static;
    else if (strcmp(copia, "dynamic") == 0) tipo_reparto = omp_sched_dynamic;
    else if (strcmp(copia, "guided")  == 0) tipo_reparto = omp_sched_guided;
    else { fprintf(stderr, "Reparto desconocido '%s' (static | dynamic | guided)\n", copia); exit(1); }
    omp_set_schedule(tipo_reparto, tamano_bloque);
}

/* -------------------------------------------------------------------------------------
 *  leer_argumentos()
 *
 *  Lee las opciones de la línea de órdenes con getopt y comprueba que los valores
 *  tienen sentido.
 *
 *  (Cocina: la recepción apunta lo que pide el cliente.)
 * ------------------------------------------------------------------------------------- */
static void leer_argumentos(int argc, char **argv) {
    int opcion;
    while ((opcion = getopt(argc, argv, "xXf:n:m:E:k:e:s:L:Zt:S:r:a:u:RDbWAlP:CBTO:F:Ipqo:G:h")) != -1) {
        switch (opcion) {
            case 'x': opcion_ejemplo = 1; break;
            case 'X': opcion_sistema_ejemplo = 1; break;
            case 'f': opcion_fichero_funcion = optarg; break;
            case 'n': opcion_num_variables = atoll(optarg); break;
            case 'm': opcion_monomios_por_funcion = atoll(optarg); break;
            case 'E': opcion_num_funciones = atoll(optarg); break;
            case 'k': opcion_max_variables_monomio = atoi(optarg); break;
            case 'e': opcion_max_exponente = atoi(optarg); break;
            case 's': opcion_semilla = strtoull(optarg, NULL, 10); break;
            case 'L': opcion_ventana_localidad = atoll(optarg); break;
            case 'Z': opcion_desordenar = 1; break;
            case 't': num_hilos = atoi(optarg); break;
            case 'S': opcion_reparto = optarg; break;
            case 'r': opcion_repeticiones = atoi(optarg); break;
            case 'a': if (sscanf(optarg, "%dx%d", &opcion_hilos_externos, &opcion_hilos_internos) != 2 || opcion_hilos_externos < 1 || opcion_hilos_internos < 1) {
                          fprintf(stderr, "Formato de -a: T1xT2 (ej. 8x2)\n"); exit(1);
                      } break;
            case 'u': umbral_anidado = atoll(optarg); break;
            case 'R': opcion_reordenar = 1; break;
            case 'D': opcion_sin_paso1 = 1; break;
            case 'b': opcion_escalabilidad_fuerte = 1; break;
            case 'W': opcion_escalabilidad_debil = 1; break;
            case 'A': opcion_estudio_anidado = 1; break;
            case 'l': opcion_estudio_lotes = 1; break;
            case 'P': opcion_num_puntos = atoi(optarg); break;
            case 'C': opcion_estudio_bloque = 1; break;
            case 'B': opcion_medir_ancho_banda = 1; break;
            case 'T': opcion_pruebas = 1; break;
            case 'O': origen_del_punto = origen_desde_nombre(optarg); origen_elegido_al_ejecutar = 1;
                      if (origen_del_punto < 0) {
                          fprintf(stderr, "Origen del punto desconocido '%s' (auto | teclado | fichero | aleatorio | interactivo)\n", optarg);
                          exit(1);
                      } break;
            case 'F': fichero_del_punto = optarg; origen_del_punto = ORIGEN_FICHERO; origen_elegido_al_ejecutar = 1; break;
            case 'I': origen_del_punto = ORIGEN_INTERACTIVO; origen_elegido_al_ejecutar = 1; break;
            case 'p': opcion_imprimir_pasos = 1; break;
            case 'q': opcion_imprimir_pasos = 0; break;
            case 'o': opcion_fichero_salida = optarg; break;
            case 'G': opcion_fichero_gradiente = optarg; break;
            case 'h': ayuda(argv[0]); exit(0);
            default:  ayuda(argv[0]); exit(1);
        }
    }
    if (opcion_num_variables <= 0 || opcion_monomios_por_funcion <= 0 || opcion_num_funciones <= 0) { fprintf(stderr, "n, m y E deben ser > 0\n"); exit(1); }
    if (opcion_num_variables > 2147483647LL) { fprintf(stderr, "n máx. 2^31 - 1\n"); exit(1); }
    if (opcion_ventana_localidad < 0) opcion_ventana_localidad = 0;
    if (opcion_max_exponente < 1) opcion_max_exponente = 1;
    if (opcion_max_exponente > 255) opcion_max_exponente = 255;
    if (opcion_repeticiones < 1) opcion_repeticiones = 1;
    if (umbral_anidado < 1) umbral_anidado = 1;
}

/* -------------------------------------------------------------------------------------
 *  imprimir_fila_tiempo()
 *
 *  Imprime una fila del desglose de tiempos alineada. Cuenta los caracteres de verdad
 *  (no los bytes) para que las tildes UTF-8 no descoloquen la columna.
 *
 *  (Cocina: una línea de la hoja de tiempos de la cocina.)
 * ------------------------------------------------------------------------------------- */
static void imprimir_fila_tiempo(const char *etiqueta, double segundos, const char *texto_extra) {
    int letras = 0;
    for (const char *caracter = etiqueta; *caracter; caracter++) if (((unsigned char)*caracter & 0xC0) != 0x80) letras++;
    printf("  %s", etiqueta);
    for (int columna = letras; columna < 50; columna++) putchar(' ');
    printf("%10.4f%s\n", segundos, texto_extra ? texto_extra : "");
}

/* -------------------------------------------------------------------------------------
 *  imprimir_afinidad()
 *
 *  Muestra qué política de afinidad está activa (OMP_PROC_BIND y OMP_PLACES, que se
 *  fijan con variables de entorno).
 *
 *  (Cocina: decir si cada cocinero tiene fogón fijo o el encargado los va moviendo.)
 * ------------------------------------------------------------------------------------- */
static void imprimir_afinidad(void) {
    const char *nombres[] = { "false (el SO mueve los hilos)", "true", "primary", "close", "spread" };
    int politica = (int)omp_get_proc_bind();
    const char *lugares = getenv("OMP_PLACES");
    printf("  Afinidad: OMP_PROC_BIND=%s   |   OMP_PLACES=%s (%d lugares)\n",
           (politica >= 0 && politica <= 4) ? nombres[politica] : "?", lugares ? lugares : "(sin definir)",
           omp_get_num_places());
}

/* =====================================================================================
 *  ESCALABILIDAD DÉBIL
 *  El trabajo POR HILO es constante: con h hilos, h·n variables y h·m monomios.
 *  Ideal: el tiempo no cambia. Eficiencia débil = t(1 hilo) / t(h hilos).
 *  (La fuerte, -b, mantiene el problema fijo y añade hilos.)
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  escalabilidad_debil()
 *
 *  Escalabilidad DÉBIL: con h hilos se genera un problema h veces mayor (h·n variables,
 *  h·m monomios), de modo que el trabajo POR HILO es constante. Lo ideal es que el
 *  tiempo no cambie: eficiencia débil = t(1 hilo) / t(h hilos).
 *
 *  (Cocina: el doble de invitados con el doble de cocineros: ¿se sirve en el mismo
 *  tiempo?)
 * ------------------------------------------------------------------------------------- */
static void escalabilidad_debil(void) {
    int lista_hilos[64], num_pruebas = 0;
    for (int hilos_prueba = 1; hilos_prueba <= num_hilos && num_pruebas < 63; hilos_prueba *= 2) lista_hilos[num_pruebas++] = hilos_prueba;
    if (lista_hilos[num_pruebas - 1] != num_hilos) lista_hilos[num_pruebas++] = num_hilos;
    int estrategias[3] = {1, 5, 6};
    double tiempo_un_hilo[3] = {0, 0, 0};
    double bytes_por_monomio = opcion_sin_paso1 ? 150.0 : 400.0;

    imprimir_linea();
    printf("ESCALABILIDAD DÉBIL: %lld variables y %lld monomios POR HILO\n", opcion_num_variables, opcion_monomios_por_funcion * opcion_num_funciones);
    printf("  Memoria del caso mayor (%d hilos): ~%.1f GB\n\n", num_hilos,
           bytes_por_monomio * opcion_monomios_por_funcion * opcion_num_funciones * num_hilos / 1073741824.0);
    printf("  %5s %12s", "hilos", "monomios");
    for (int indice = 0; indice < 3; indice++) printf(" %21s", nombre_estrategia[estrategias[indice]]);
    printf("\n  %5s %12s", "", "");
    for (int indice = 0; indice < 3; indice++) printf(" %10s %10s", "tiempo(s)", "eficiencia");
    printf("\n");

    for (int prueba = 0; prueba < num_pruebas; prueba++) {
        int hilos_prueba = lista_hilos[prueba];
        omp_set_num_threads(num_hilos);                 /* construir con todos los hilos */
        generar_funcion_aleatoria(opcion_num_funciones, opcion_num_variables * hilos_prueba, opcion_monomios_por_funcion * hilos_prueba, opcion_max_variables_monomio, opcion_max_exponente, opcion_semilla, opcion_ventana_localidad, opcion_desordenar);
        double *punto = reservar(sizeof(double) * num_variables, "punto");
        generar_valores_aleatorios(num_variables, opcion_semilla, punto);
        if (opcion_reordenar) reordenar_variables_y_monomios(punto);
        double tiempo_indice, tiempo_simbolico;
        derivar_simbolicamente(!opcion_sin_paso1, &tiempo_indice, &tiempo_simbolico);
        preparar_evaluacion(num_hilos);
        double *jacobiano = reservar(sizeof(double) * (num_entradas_jacobiano > 0 ? num_entradas_jacobiano : 1), "jacobiano");

        printf("  %5d %12lld", hilos_prueba, num_monomios);
        for (int indice = 0; indice < 3; indice++) {
            if (!estrategia_disponible(estrategias[indice], hilos_prueba)) { printf(" %10s %10s", "-", "-"); continue; }
            double tiempo = medir_tiempo(funcion_estrategia[estrategias[indice]], hilos_prueba, opcion_repeticiones, punto, jacobiano);
            if (prueba == 0) tiempo_un_hilo[indice] = tiempo;
            printf(" %10.4f %9.0f%%", tiempo, 100.0 * tiempo_un_hilo[indice] / tiempo);
            fflush(stdout);
        }
        printf("\n");
        free(punto); free(jacobiano);
        liberar_evaluacion(); liberar_derivadas(); liberar_funcion();
    }
    printf("\n  Eficiencia débil ideal = 100%% (mismo tiempo con el doble de hilos y de trabajo).\n");
    omp_set_num_threads(num_hilos);
}

/* =====================================================================================
 *  EVALUACIÓN EN UN PUNTO (modo interactivo): PASO 3 secuencial y paralelo, medidos
 *  con omp_get_wtime, comprobación secuencial == paralelo y validación numérica.
 * ===================================================================================== */
static double *ultimo_jacobiano = NULL;          /* último Jacobiano calculado (para "guardar") */

/* -------------------------------------------------------------------------------------
 *  evaluar_en_punto()
 *
 *  Modo interactivo: evalúa un punto ya obtenido. Calcula f(x), el PASO 3 secuencial de
 *  referencia y tres estrategias paralelas, cada una cronometrada con omp_get_wtime,
 *  comprueba que coinciden con el secuencial, muestra el gradiente y lo valida con
 *  diferencias finitas. Guarda el último Jacobiano para el comando 'guardar'.
 *
 *  (Cocina: con las fichas ya escritas, cocinar un pedido nuevo y que lo pruebe el
 *  catador.)
 * ------------------------------------------------------------------------------------- */
static void evaluar_en_punto(const double *punto_recibido, int imprimir_pasos) {
    double *punto  = reservar(sizeof(double) * num_variables, "punto");
    memcpy(punto, punto_recibido, sizeof(double) * num_variables);
    entero64 tamano_jacobiano = num_entradas_jacobiano > 0 ? num_entradas_jacobiano : 1;
    double *jacobiano_referencia = reservar(sizeof(double) * tamano_jacobiano, "jacobiano_referencia");
    double *jacobiano_paralelo = reservar(sizeof(double) * tamano_jacobiano, "jacobiano_paralelo");
    double *valor_de_funcion = reservar(sizeof(double) * num_funciones, "valor_de_funcion");

    double inicio_reloj = omp_get_wtime();
    evaluar_funciones(punto, valor_de_funcion);
    double tiempo_funcion = omp_get_wtime() - inicio_reloj;

    int estrategia_referencia = derivadas_construidas ? 0 : ESTRATEGIA_DIRECTA_SECUENCIAL;
    omp_set_num_threads(1);
    inicio_reloj = omp_get_wtime();
    funcion_estrategia[estrategia_referencia](punto, jacobiano_referencia);
    double tiempo_secuencial = omp_get_wtime() - inicio_reloj;

    if (imprimir_pasos && derivadas_construidas) imprimir_paso3(punto, jacobiano_referencia);
    imprimir_linea();
    if (num_funciones == 1) printf("  f(x) = %.10g   (%.4f s)\n", valor_de_funcion[0], tiempo_funcion);
    else          printf("  F(x) evaluado en %.4f s\n", tiempo_funcion);
    printf("  %-19s %10s %9s %13s %5s\n", "PASO 3", "Tiempo(s)", "Speedup", "Error vs sec", "Bit");
    printf("  %-19s %10.4f %8.2fx %13s %5s\n", nombre_estrategia[estrategia_referencia], tiempo_secuencial, 1.0, "-", "-");
    int estrategias[] = {1, 5, 6};
    for (int indice = 0; indice < 3; indice++) {
        int estrategia = estrategias[indice];
        if (!estrategia_disponible(estrategia, num_hilos)) continue;
        omp_set_num_threads(num_hilos);
        inicio_reloj = omp_get_wtime();
        funcion_estrategia[estrategia](punto, jacobiano_paralelo);
        double tiempo = omp_get_wtime() - inicio_reloj;
        printf("  %-19s %10.4f %8.2fx %13.1e %5s\n", nombre_estrategia[estrategia], tiempo, tiempo_secuencial / tiempo,
               error_relativo_maximo(jacobiano_paralelo, jacobiano_referencia, num_entradas_jacobiano), memcmp(jacobiano_paralelo, jacobiano_referencia, sizeof(double) * num_entradas_jacobiano) == 0 ? "sí" : "no");
    }
    omp_set_num_threads(num_hilos);

    if (num_funciones == 1 && !(imprimir_pasos && derivadas_construidas)) {
        double *gradiente = reservar(sizeof(double) * num_variables, "g"), *gradiente_original = reservar(sizeof(double) * num_variables, "gradiente");
        expandir_gradiente(jacobiano_referencia, gradiente);
        volver_al_orden_original(gradiente, gradiente_original);
        double norma = 0.0;
        for (entero64 variable = 0; variable < num_variables; variable++) norma += gradiente_original[variable] * gradiente_original[variable];
        printf("\n  ∇f(x) = ( ");
        entero64 mostrar = num_variables <= 20 ? num_variables : 8;
        for (entero64 variable = 0; variable < mostrar; variable++) printf("%.6g%s", gradiente_original[variable], variable + 1 < mostrar ? ", " : "");
        if (num_variables > mostrar) printf(", ... (%lld más)", num_variables - mostrar);
        printf(" )   ||∇f(x)|| = %.10g\n", sqrt(norma));
        free(gradiente); free(gradiente_original);
    }
    comprobar_diferencias_finitas(punto, jacobiano_referencia, 5);
    free(ultimo_jacobiano); ultimo_jacobiano = jacobiano_referencia;
    free(jacobiano_paralelo); free(valor_de_funcion); free(punto);
}

/* -------------------------------------------------------------------------------------
 *  guardar_resultado()
 *
 *  Guarda el último gradiente (uno por línea, orden original) o, si es un sistema, el
 *  Jacobiano como 'fila columna valor'.
 *
 *  (Cocina: apuntar el resultado del pedido en el registro.)
 * ------------------------------------------------------------------------------------- */
static void guardar_resultado(const char *ruta) {
    FILE *fichero = fopen(ruta, "w");
    if (fichero == NULL) { printf("  No puedo crear '%s'\n", ruta); return; }
    if (num_funciones == 1) {
        double *gradiente = reservar(sizeof(double) * num_variables, "g"), *gradiente_original = reservar(sizeof(double) * num_variables, "gradiente");
        expandir_gradiente(ultimo_jacobiano, gradiente);
        volver_al_orden_original(gradiente, gradiente_original);
        for (entero64 variable = 0; variable < num_variables; variable++) fprintf(fichero, "%.17g\n", gradiente_original[variable]);
        free(gradiente); free(gradiente_original);
    } else {
        fprintf(fichero, "# fila columna valor\n");
        for (entero64 variable = 0; variable < num_variables; variable++)
            for (entero64 entrada = inicio_entradas_de_variable[variable]; entrada < inicio_entradas_de_variable[variable + 1]; entrada++)
                fprintf(fichero, "%d %lld %.17g\n", funcion_de_la_entrada[entrada] + 1,
                        (numero_original_de_variable ? (entero64)numero_original_de_variable[variable] : variable) + 1, ultimo_jacobiano[entrada]);
    }
    fclose(fichero);
    printf("  Guardado en '%s'\n", ruta);
}

/* -------------------------------------------------------------------------------------
 *  ayuda_interactivo()
 *
 *  Lista de comandos del modo interactivo.
 *
 *  (Cocina: las opciones que da el camarero.)
 * ------------------------------------------------------------------------------------- */
static void ayuda_interactivo(void) {
    printf("\n  Las derivadas (PASO 1 y 2) ya están calculadas. Elige de dónde leer el punto:\n"
           "    teclado            escribir los valores en el terminal          (atajo: 1)\n"
           "    fichero [RUTA]     leerlos de un fichero de datos               (atajo: 2)\n"
           "    aleatorio [SEM]    valores aleatorios en [0.5, 1)               (atajo: 3)\n"
           "    original           el punto que traía el fichero de la función  (atajo: 4)\n"
           "    guardar RUTA       guardar el último gradiente / Jacobiano calculado\n"
           "    ayuda              ver esta lista          salir   terminar     (atajo: q)\n");
}

/* -------------------------------------------------------------------------------------
 *  modo_interactivo()
 *
 *  Bucle de comandos 'punto>': después de derivar (PASO 1 y 2) se elige de dónde leer
 *  el punto (teclado, fichero, aleatorio, original) y se evalúa; se puede repetir con
 *  tantos puntos como se quiera SIN volver a derivar. 'guardar' escribe el último
 *  resultado.
 *
 *  (Cocina: las fichas están colgadas; el camarero va preguntando '¿siguiente pedido?'
 *  y la cocina solo tiene que sustituir y cocinar.)
 * ------------------------------------------------------------------------------------- */
static void modo_interactivo(int imprimir_pasos) {
    double *punto = reservar(sizeof(double) * num_variables, "punto");
    char linea[1024];
    int puntos_evaluados = 0;
    ayuda_interactivo();
    for (;;) {
        printf("\npunto> ");
        fflush(stdout);
        if (fgets(linea, sizeof linea, stdin) == NULL) { printf("\n"); break; }
        char *comando = strtok(linea, " \t\r\n");
        char *argumento = strtok(NULL, " \t\r\n");
        if (comando == NULL) continue;
        int punto_leido = 0;
        double inicio_reloj = omp_get_wtime();
        if (!strcmp(comando, "salir") || !strcmp(comando, "q") || !strcmp(comando, "exit")) break;
        else if (!strcmp(comando, "ayuda") || !strcmp(comando, "?")) { ayuda_interactivo(); continue; }
        else if (!strcmp(comando, "teclado") || !strcmp(comando, "1")) punto_leido = leer_punto_de_teclado(punto);
        else if (!strcmp(comando, "fichero") || !strcmp(comando, "2")) {
            char ruta[1024];
            if (argumento) snprintf(ruta, sizeof ruta, "%s", argumento);
            else {
                printf("  Ruta del fichero [%s]: ", fichero_del_punto);
                fflush(stdout);
                if (fgets(ruta, sizeof ruta, stdin) == NULL) break;
                ruta[strcspn(ruta, "\r\n")] = '\0';
                if (ruta[0] == '\0') snprintf(ruta, sizeof ruta, "%s", fichero_del_punto);
            }
            punto_leido = leer_punto_de_fichero(ruta, punto);
        }
        else if (!strcmp(comando, "aleatorio") || !strcmp(comando, "3")) {
            punto_aleatorio(argumento ? strtoull(argumento, NULL, 10) : opcion_semilla + puntos_evaluados, punto);
            punto_leido = 1;
        }
        else if (!strcmp(comando, "original") || !strcmp(comando, "4")) {
            if (punto_del_fichero) { memcpy(punto, punto_del_fichero, sizeof(double) * num_variables); punto_leido = 1; }
            else printf("  El fichero de la función no traía punto.\n");
        }
        else if (!strcmp(comando, "guardar")) {
            if (ultimo_jacobiano == NULL) printf("  Todavía no se ha evaluado ningún punto.\n");
            else if (argumento == NULL) printf("  Uso: guardar RUTA\n");
            else guardar_resultado(argumento);
            continue;
        }
        else { printf("  Comando desconocido. Escribe 'ayuda'.\n"); continue; }

        if (!punto_leido) { printf("  No se ha podido leer el punto.\n"); continue; }
        printf("  Punto obtenido en %.4f s\n", omp_get_wtime() - inicio_reloj);
        evaluar_en_punto(punto, imprimir_pasos);
        puntos_evaluados++;
    }
    printf("  Puntos evaluados: %d (con una sola derivación)\n", puntos_evaluados);
    free(punto); free(ultimo_jacobiano); ultimo_jacobiano = NULL;
}

/* -------------------------------------------------------------------------------------
 *  main()
 *
 *  Programa principal. Orden: opciones -> hilos y reparto -> cabecera (núcleos,
 *  afinidad, origen del punto) -> [pruebas o escalabilidad débil] -> 1. función
 *  (ejemplo, fichero o aleatoria) -> reordenación opcional -> 2. PASO 1 y 2 -> 3. punto
 *  (o modo interactivo) -> 4. f(x) y PASO 3 secuencial -> 5. todas las estrategias,
 *  gradiente y comprobación -> 6. estudios -> 7. desglose de tiempos. Cada fase se
 *  cronometra con omp_get_wtime.
 *
 *  (Cocina: el servicio completo, desde que entra el pedido hasta la hoja de tiempos
 *  final.)
 * ------------------------------------------------------------------------------------- */
int main(int argc, char **argv) {
    double inicio_programa = omp_get_wtime();              /* reloj desde el arranque */
    leer_argumentos(argc, argv);

    int nucleos = omp_get_num_procs();
    if (num_hilos <= 0) num_hilos = nucleos;
    omp_set_num_threads(num_hilos);
    aplicar_reparto(opcion_reparto);
    hilos_nivel_externo = opcion_hilos_externos ? opcion_hilos_externos : (num_hilos >= 2 ? num_hilos / 2 : 1);
    hilos_nivel_interno = opcion_hilos_internos ? opcion_hilos_internos : (num_hilos >= 2 ? 2 : 1);

    imprimir_linea();
#ifdef _OPENMP
    printf("GRADIENTES / JACOBIANOS DE FUNCIONES MULTIVARIABLES — versión OpenMP\n");
#else
    printf("GRADIENTES / JACOBIANOS DE FUNCIONES MULTIVARIABLES — versión SECUENCIAL (sin OpenMP)\n");
#endif
    printf("  Núcleos detectados: %d   |   Hilos: %d   |   Reparto: %s   |   Índices: %d bits\n",
           nucleos, num_hilos, opcion_reparto, BITS_INDICE);
    imprimir_afinidad();
    printf("  Origen del punto: %s%s%s   (%s)\n", nombre_del_origen[origen_del_punto],
           origen_del_punto == ORIGEN_FICHERO ? " -> " : "", origen_del_punto == ORIGEN_FICHERO ? fichero_del_punto : "",
           origen_elegido_al_ejecutar ? "elegido con una opción al ejecutar" : "fijado al compilar");
    if (num_hilos > nucleos) printf("  Aviso: más hilos que núcleos -> compiten entre sí.\n");

    if (opcion_medir_ancho_banda) {
        ancho_banda_pico_gbs = medir_ancho_banda_pico(num_hilos);
        printf("  Ancho de banda pico de la RAM (STREAM triad, %d hilos): %.1f GB/s\n", num_hilos, ancho_banda_pico_gbs);
    }

    if (opcion_pruebas) return ejecutar_pruebas(num_hilos) == 0 ? 0 : 1;
    if (opcion_escalabilidad_debil) { escalabilidad_debil(); return 0; }

    /* ---------- 1. La función (o el sistema) ---------- */
    double tiempo_previo = omp_get_wtime() - inicio_programa;   /* todo lo anterior a la entrada de datos */
    double inicio_reloj = omp_get_wtime();
    if      (opcion_ejemplo) cargar_ejemplo_enunciado();
    else if (opcion_sistema_ejemplo) cargar_sistema_enunciado();
    else if (opcion_fichero_funcion) leer_funcion_de_fichero(opcion_fichero_funcion);
    else generar_funcion_aleatoria(opcion_num_funciones, opcion_num_variables, opcion_monomios_por_funcion, opcion_max_variables_monomio, opcion_max_exponente, opcion_semilla, opcion_ventana_localidad, opcion_desordenar);
    double tiempo_construccion = omp_get_wtime() - inicio_reloj;

    printf("  Funciones: %lld   |   Variables: %lld   |   Monomios: %lld   |   Casillas: %lld\n",
           num_funciones, num_variables, num_monomios, num_factores);
    printf("  Construcción de la función: %.3f s\n", tiempo_construccion);
    if (opcion_ventana_localidad > 0 || opcion_desordenar)
        printf("  Estructura: %s%s\n", opcion_ventana_localidad > 0 ? "local (ventana) " : "aleatoria ",
               opcion_desordenar ? "+ variables desordenadas" : "");

    /* ---------- Reordenación (opcional) ---------- */
    printf("  Localidad: distancia media entre variables consecutivas = %.0f\n", distancia_media_accesos());
    double tiempo_reordenar = 0.0;
    if (opcion_reordenar) {
        tiempo_reordenar = reordenar_variables_y_monomios(NULL);
        printf("  Reordenación BFS: %.3f s   ->   distancia media = %.0f\n", tiempo_reordenar, distancia_media_accesos());
    }

    int es_pequeno = (num_variables <= 12 && num_monomios <= 60);
    int imprimir_pasos = (opcion_imprimir_pasos >= 0) ? opcion_imprimir_pasos : es_pequeno;

    /* ---------- 2. PASO 1: derivadas parciales ---------- */
    double tiempo_indice, tiempo_simbolico;
    derivar_simbolicamente(!opcion_sin_paso1, &tiempo_indice, &tiempo_simbolico);
    printf("  PASO 1 (derivación simbólica): índice %.3f s + monomios derivados %.3f s\n", tiempo_indice, tiempo_simbolico);
    printf("  Entradas no nulas del %s: %lld\n", num_funciones == 1 ? "gradiente" : "Jacobiano", num_entradas_jacobiano);

    inicio_reloj = omp_get_wtime();
    preparar_evaluacion(num_hilos);
    double tiempo_preparacion = omp_get_wtime() - inicio_reloj;

    printf("\n  Memoria:\n");
    imprimir_bytes("función (coef, start, var, expo)",
                   (double)num_monomios * (12 + sizeof(tipo_indice)) + (double)num_factores * 5 + (double)num_funciones * 8);
    imprimir_bytes("PASO 1 (índices + derivadas)", memoria_derivadas());
    imprimir_bytes("buffers de evaluación", memoria_evaluacion(num_hilos));

    if (imprimir_pasos) {
        imprimir_linea();
        if (num_funciones == 1) {
            char nombre_variable[64];
            printf("f(");
            for (entero64 variable = 0; variable < num_variables; variable++) { nombre_de_variable(variable, nombre_variable, sizeof nombre_variable); printf("%s%s", variable ? ", " : "", nombre_variable); }
            printf(") = "); imprimir_funcion(stdout, 0); printf("\n");
        } else {
            printf("Sistema de %lld ecuaciones (todo pasado a la izquierda: F(x) = 0)\n", num_funciones);
        }
        if (derivadas_construidas) { imprimir_paso1(); imprimir_paso2(); }
    }

    /* ---------- 3. El punto (las derivadas ya están calculadas) ---------- */
    if (origen_del_punto == ORIGEN_INTERACTIVO) {
        modo_interactivo(imprimir_pasos);
        imprimir_linea();
        printf("DESGLOSE DE TIEMPOS (s)\n");
        imprimir_fila_tiempo("Antes de la entrada de datos (arranque, opciones)", tiempo_previo, NULL);
        imprimir_fila_tiempo(opcion_fichero_funcion ? "Entrada de datos: lectura del fichero"
                                : "Entrada de datos: generación / ejemplo", tiempo_construccion, NULL);
        if (opcion_reordenar) imprimir_fila_tiempo("Reordenación", tiempo_reordenar, NULL);
        imprimir_fila_tiempo("PASO 1 + 2: derivación simbólica", tiempo_indice + tiempo_simbolico, NULL);
        imprimir_fila_tiempo("TOTAL del programa (incluye la espera al usuario)", omp_get_wtime() - inicio_programa, NULL);
        imprimir_linea();
        liberar_evaluacion(); liberar_derivadas(); liberar_funcion();
        return 0;
    }
    double *punto = reservar(sizeof(double) * num_variables, "punto");
    fflush(stdout);                         /* que lo anterior salga antes que posibles errores */
    inicio_reloj = omp_get_wtime();
    if (!obtener_punto(origen_del_punto, fichero_del_punto, opcion_semilla, punto)) {
        fprintf(stderr, "No se ha podido obtener el punto (origen: %s)\n", nombre_del_origen[origen_del_punto]);
        return 1;
    }
    double tiempo_punto = omp_get_wtime() - inicio_reloj;
    if (origen_del_punto == ORIGEN_FICHERO)   printf("  Punto leído del fichero '%s' (%.4f s)\n", fichero_del_punto, tiempo_punto);
    else if (origen_del_punto == ORIGEN_AUTO) printf("  Punto: %s\n", punto_del_fichero ? "el del fichero de la función" : "aleatorio en [0.5, 1)");
    else                                printf("  Punto: %s\n", nombre_del_origen[origen_del_punto]);

    /* ---------- 4. f(x) ---------- */
    double *valor_de_funcion = reservar(sizeof(double) * num_funciones, "valor_de_funcion");
    inicio_reloj = omp_get_wtime();
    evaluar_funciones(punto, valor_de_funcion);
    double tiempo_funcion = omp_get_wtime() - inicio_reloj;

    /* ---------- 4. PASO 3: referencia secuencial ---------- */
    double *jacobiano_referencia = reservar(sizeof(double) * (num_entradas_jacobiano > 0 ? num_entradas_jacobiano : 1), "jacobiano_referencia");
    double *jacobiano_temporal = reservar(sizeof(double) * (num_entradas_jacobiano > 0 ? num_entradas_jacobiano : 1), "jacobiano_temporal");
    omp_set_num_threads(1);
    inicio_reloj = omp_get_wtime();
    if (derivadas_construidas) funcion_estrategia[0](punto, jacobiano_referencia);
    else                 funcion_estrategia[ESTRATEGIA_DIRECTA_SECUENCIAL](punto, jacobiano_referencia);
    double tiempo_referencia = omp_get_wtime() - inicio_reloj;
    omp_set_num_threads(num_hilos);

    if (imprimir_pasos && derivadas_construidas) imprimir_paso3(punto, jacobiano_referencia);

    imprimir_linea();
    if (num_funciones == 1) printf("f(x) = %.10g      (%.4f s)\n", valor_de_funcion[0], tiempo_funcion);
    else {
        printf("F(x) evaluado (%.4f s):", tiempo_funcion);
        for (entero64 funcion = 0; funcion < num_funciones && funcion < 6; funcion++) printf("  F%lld = %.6g", funcion + 1, valor_de_funcion[funcion]);
        if (num_funciones > 6) printf("  ...");
        printf("\n");
    }

    /* ---------- 5. Todas las estrategias ---------- */
    inicio_reloj = omp_get_wtime();
    double tiempo_secuencial = comparar_estrategias(num_hilos, opcion_repeticiones, punto, jacobiano_referencia, jacobiano_temporal);
    double tiempo_tabla = omp_get_wtime() - inicio_reloj;

    double norma = 0.0;
    for (entero64 entrada = 0; entrada < num_entradas_jacobiano; entrada++) norma += jacobiano_referencia[entrada] * jacobiano_referencia[entrada];
    if (num_funciones == 1) {
        double *gradiente  = reservar(sizeof(double) * num_variables, "gradiente");
        double *gradiente_original = reservar(sizeof(double) * num_variables, "gradiente_original");
        expandir_gradiente(jacobiano_referencia, gradiente);
        volver_al_orden_original(gradiente, gradiente_original);               /* si se reordenó, volver al orden original */
        printf("\n  ∇f(x) = ( ");
        entero64 mostrar = num_variables <= 20 ? num_variables : 8;
        for (entero64 variable = 0; variable < mostrar; variable++) printf("%.6g%s", gradiente_original[variable], variable + 1 < mostrar ? ", " : "");
        if (num_variables > mostrar) printf(", ... (%lld más)", num_variables - mostrar);
        printf(" )\n  ||∇f(x)|| = %.10g\n", sqrt(norma));
        if (opcion_fichero_gradiente) {
            FILE *fichero = fopen(opcion_fichero_gradiente, "w");
            if (fichero) { for (entero64 variable = 0; variable < num_variables; variable++) fprintf(fichero, "%.17g\n", gradiente_original[variable]); fclose(fichero);
                      printf("  Gradiente guardado en '%s' (orden original de variables)\n", opcion_fichero_gradiente); }
        }
        free(gradiente); free(gradiente_original);
    } else {
        printf("\n  Jacobiano: %lld entradas no nulas de %lld × %lld   ||J||_F = %.10g\n",
               num_entradas_jacobiano, num_funciones, num_variables, sqrt(norma));
        if (opcion_fichero_gradiente) {
            FILE *fichero = fopen(opcion_fichero_gradiente, "w");
            if (fichero) {
                fprintf(fichero, "# fila columna valor   (columna = nº original de la variable)\n");
                for (entero64 variable = 0; variable < num_variables; variable++)
                    for (entero64 entrada = inicio_entradas_de_variable[variable]; entrada < inicio_entradas_de_variable[variable + 1]; entrada++)
                        fprintf(fichero, "%d %lld %.17g\n", funcion_de_la_entrada[entrada] + 1,
                                (numero_original_de_variable ? (entero64)numero_original_de_variable[variable] : variable) + 1, jacobiano_referencia[entrada]);
                fclose(fichero);
                printf("  Jacobiano guardado en '%s'\n", opcion_fichero_gradiente);
            }
        }
    }

    inicio_reloj = omp_get_wtime();
    comprobar_diferencias_finitas(punto, jacobiano_referencia, 5);
    double tiempo_comprobacion = omp_get_wtime() - inicio_reloj;

    /* ---------- 6. Estudios ---------- */
    inicio_reloj = omp_get_wtime();
    if (opcion_escalabilidad_fuerte) escalabilidad_fuerte(num_hilos, opcion_repeticiones, tiempo_secuencial, punto, jacobiano_temporal);
    if (opcion_estudio_bloque)    estudio_tamano_bloque(num_hilos, opcion_repeticiones, punto, jacobiano_temporal);
    if (opcion_estudio_anidado)  estudio_anidado(num_hilos, opcion_repeticiones, tiempo_secuencial, punto, jacobiano_temporal,
                                      opcion_num_puntos > 0 ? opcion_num_puntos : num_hilos, opcion_semilla);
    if (opcion_estudio_lotes)    estudio_lotes(num_hilos, opcion_repeticiones, opcion_num_puntos > 0 ? opcion_num_puntos : 64, opcion_semilla);

    double tiempo_estudios = omp_get_wtime() - inicio_reloj;

    inicio_reloj = omp_get_wtime();
    if (opcion_fichero_salida) { imprimir_linea(); escribir_funcion_en_fichero(opcion_fichero_salida, punto); }
    double tiempo_salida = omp_get_wtime() - inicio_reloj;

    /* ---------- 7. Desglose de tiempos ---------- */
    imprimir_linea();
    printf("DESGLOSE DE TIEMPOS (s)\n");
    imprimir_fila_tiempo("Antes de la entrada de datos (arranque, opciones)", tiempo_previo, NULL);
    imprimir_fila_tiempo(opcion_fichero_funcion ? "Entrada de datos: lectura del fichero"
                            : "Entrada de datos: generación / ejemplo", tiempo_construccion, NULL);
    if (opcion_reordenar) imprimir_fila_tiempo("Reordenación", tiempo_reordenar, NULL);
    imprimir_fila_tiempo("PASO 1 + 2: derivación simbólica", tiempo_indice + tiempo_simbolico, NULL);
    imprimir_fila_tiempo("Preparación de buffers de evaluación", tiempo_preparacion, NULL);
    imprimir_fila_tiempo(origen_del_punto == ORIGEN_TECLADO ? "Lectura del punto (incluye lo que tardas en teclear)"
                                             : "Obtención del punto", tiempo_punto, NULL);
    imprimir_fila_tiempo("Evaluación de f(x)", tiempo_funcion, NULL);
    imprimir_fila_tiempo("PASO 3 secuencial (una evaluación de referencia)", tiempo_referencia, NULL);
    if (mejor_tiempo_paralelo > 0) {
        char extra[96];
        snprintf(extra, sizeof extra, "   (%s, %d hilos)", mejor_estrategia_paralela, num_hilos);
        imprimir_fila_tiempo("PASO 3 paralelo (mejor estrategia)", mejor_tiempo_paralelo, extra);
    }
    imprimir_fila_tiempo("Medición de todas las estrategias (con reps.)", tiempo_tabla, NULL);
    imprimir_fila_tiempo("Comprobación con diferencias finitas", tiempo_comprobacion, NULL);
    if (tiempo_estudios > 0.001) imprimir_fila_tiempo("Estudios (-b -C -A -l)", tiempo_estudios, NULL);
    if (opcion_fichero_salida) imprimir_fila_tiempo("Escritura del fichero de salida", tiempo_salida, NULL);
    imprimir_fila_tiempo("TOTAL del programa", omp_get_wtime() - inicio_programa, NULL);
    imprimir_linea();

    free(punto); free(valor_de_funcion); free(jacobiano_referencia); free(jacobiano_temporal);
    liberar_evaluacion();
    liberar_derivadas();
    liberar_funcion();
    return 0;
}
