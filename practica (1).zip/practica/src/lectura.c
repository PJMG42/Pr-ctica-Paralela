/* =====================================================================================
 *  lectura.c — LECTURA Y ESCRITURA DE DATOS
 *
 *  Formas de proporcionar la función (o el sistema) al programa:
 *    1. Ejemplos del enunciado incorporados        (cargar_ejemplo_enunciado / _sistema_)
 *    2. Fichero de TEXTO, legible y editable:       variables: x y z
 *                                                   f: 3xy + 4yz + 2x + 5
 *                                                   punto: 1 2 3
 *    3. Fichero NUMÉRICO (versión anterior):        n m / coef k v e v e ... / punto
 *    4. Fichero BINARIO (.bin): mucho más rápido de leer y escribir para problemas
 *       grandes (lo genera el programa externo ./generador o la opción -o fich.bin)
 *    (5. Generación aleatoria dentro del programa: generacion.c)
 *
 *  (Cocina: COPIAR RECETAS al libro de la cocina desde el cuaderno del cliente: escrito
 *  a mano (texto), en plantilla de números (numérico) o envasado al vacío (binario,
 *  rapidísimo).)
 * ===================================================================================== */
#include "polinomio.h"
#include <ctype.h>

/* =====================================================================================
 *  1. CONSTRUCTOR INCREMENTAL (para lectura de ficheros y ejemplos)
 *     Los arrays crecen dinámicamente (se duplica la capacidad cuando se llenan).
 * ===================================================================================== */
static entero64 capacidad_funciones = 0, capacidad_monomios = 0, capacidad_factores = 0;

/* -------------------------------------------------------------------------------------
 *  constructor_iniciar()
 *
 *  Prepara los arrays globales vacíos, con una capacidad inicial pequeña que luego
 *  crecerá.
 *
 *  (Cocina: abrir un cuaderno nuevo para copiar recetas.)
 * ------------------------------------------------------------------------------------- */
static void constructor_iniciar(void) {
    num_funciones = 0; num_monomios = 0; num_factores = 0;
    capacidad_funciones = 8; capacidad_monomios = 64; capacidad_factores = 256;
    inicio_de_funcion      = reservar(sizeof(entero64) * (capacidad_funciones + 1), "inicio_de_funcion");
    funcion_del_monomio = reservar(sizeof(int) * capacidad_monomios, "funcion_del_monomio");
    coeficiente_del_monomio           = reservar(sizeof(double) * capacidad_monomios, "coeficiente_del_monomio");
    inicio_del_monomio          = reservar(sizeof(tipo_indice) * (capacidad_monomios + 1), "inicio_del_monomio");
    variable_del_factor            = reservar(sizeof(int) * capacidad_factores, "variable_del_factor");
    exponente_del_factor           = reservar(capacidad_factores, "exponente_del_factor");
    inicio_de_funcion[0] = 0;
    inicio_del_monomio[0] = 0;
}

/* -------------------------------------------------------------------------------------
 *  constructor_nueva_funcion()
 *
 *  Empieza una función nueva (una ecuación más del sistema). Si no cabe, duplica la
 *  capacidad de inicio_de_funcion.
 *
 *  (Cocina: empezar un plato nuevo del menú en el cuaderno.)
 * ------------------------------------------------------------------------------------- */
static void constructor_nueva_funcion(void) {
    if (num_funciones + 1 > capacidad_funciones) {
        capacidad_funciones *= 2;
        inicio_de_funcion = redimensionar(inicio_de_funcion, sizeof(entero64) * (capacidad_funciones + 1), "inicio_de_funcion");
    }
    num_funciones++;
    inicio_de_funcion[num_funciones] = num_monomios;
}

/* -------------------------------------------------------------------------------------
 *  constructor_anadir_monomio()
 *
 *  Añade a la función actual el monomio coeficiente · Π variables[j]^exponentes[j]. Los
 *  factores con exponente 0 se omiten (x^0 = 1) y un monomio con coeficiente 0 no se
 *  guarda. Si los arrays se llenan, se duplica su tamaño (redimensionar): coste medio
 *  constante por monomio.
 *
 *  (Cocina: copiar una línea de receta al libro; si se acaba el cuaderno, se cambia por
 *  uno del doble de páginas.)
 * ------------------------------------------------------------------------------------- */
static void constructor_anadir_monomio(double coeficiente, int num_factores_monomio, const int *variables, const int *exponentes) {
    if (coeficiente == 0.0) return;                    /* un monomio nulo no aporta nada (ej. "= 0") */
    if (num_monomios + 1 > capacidad_monomios) {
        capacidad_monomios *= 2;
        funcion_del_monomio = redimensionar(funcion_del_monomio, sizeof(int) * capacidad_monomios, "funcion_del_monomio");
        coeficiente_del_monomio  = redimensionar(coeficiente_del_monomio,  sizeof(double) * capacidad_monomios, "coeficiente_del_monomio");
        inicio_del_monomio = redimensionar(inicio_del_monomio, sizeof(tipo_indice) * (capacidad_monomios + 1), "inicio_del_monomio");
    }
    comprobar_cabe_en_indice(num_factores + num_factores_monomio, "casillas de la función");
    comprobar_cabe_en_indice(num_monomios + 1, "monomios de la función");
    if (num_factores + num_factores_monomio > capacidad_factores) {
        while (num_factores + num_factores_monomio > capacidad_factores) capacidad_factores *= 2;
        variable_del_factor  = redimensionar(variable_del_factor,  sizeof(int) * capacidad_factores, "variable_del_factor");
        exponente_del_factor = redimensionar(exponente_del_factor, capacidad_factores, "exponente_del_factor");
    }
    coeficiente_del_monomio[num_monomios] = coeficiente;
    funcion_del_monomio[num_monomios] = (int)(num_funciones - 1);
    for (int posicion = 0; posicion < num_factores_monomio; posicion++) {
        if (exponentes[posicion] == 0) continue;
        variable_del_factor[num_factores]  = variables[posicion];
        exponente_del_factor[num_factores] = (unsigned char)exponentes[posicion];
        num_factores++;
    }
    num_monomios++;
    inicio_del_monomio[num_monomios] = (tipo_indice)num_factores;
    inicio_de_funcion[num_funciones] = num_monomios;
}

/* =====================================================================================
 *  2. ANALIZADOR DEL FORMATO DE TEXTO
 *
 *    # comentario
 *    variables: x y z           (o "variables: 1000"  -> x0, x1, ..., x999)
 *    f: 3xy + 4yz + 2x + 5      (una línea por función; cualquier etiqueta seguida de ':')
 *    g: 3x^2 + yz + z + 5 = 2   (con '=' se pasa todo a la izquierda: lhs - rhs)
 *    punto: 1 2 3               (opcional)
 *
 *  Monomios: coeficiente opcional y factores separados por '*' o espacios.
 *    - Exponentes con '^':     3*x^2*y        3 x^2 y
 *    - Si TODAS las variables tienen nombre de una letra, se pueden escribir pegadas
 *      y con el exponente detrás, como en el enunciado:   3xy   yz3 (= y·z^3)   x2 (= x^2)
 *    - Una variable repetida en el mismo monomio se combina: x*x -> x^2
 * ===================================================================================== */
static int linea_actual = 0;

/* -------------------------------------------------------------------------------------
 *  error_texto()
 *
 *  Muestra un error de lectura con el número de línea y el trozo de texto donde
 *  ocurrió, y termina.
 *
 *  (Cocina: 'en la línea 3 de tu receta no entiendo lo que pone'.)
 * ------------------------------------------------------------------------------------- */
static void error_texto(const char *mensaje, const char *cerca_de) {
    fprintf(stderr, "Error en la línea %d: %s", linea_actual, mensaje);
    if (cerca_de && *cerca_de) fprintf(stderr, "  (cerca de \"%.25s\")", cerca_de);
    fprintf(stderr, "\n");
    exit(1);
}

/* -------------------------------------------------------------------------------------
 *  buscar_variable_por_nombre()
 *
 *  Devuelve el número de la variable que se llama así (los 'longitud' primeros
 *  caracteres de 'nombre'), o -1 si no existe. Con nombres por defecto entiende x0, x1,
 *  x2...
 *
 *  (Cocina: buscar en la lista de ingredientes cuál es 'cebolla'.)
 * ------------------------------------------------------------------------------------- */
static int buscar_variable_por_nombre(const char *nombre, int longitud) {
    if (nombres_de_variables == NULL) {                              /* nombres por defecto x0, x1, ... */
        if (longitud < 2 || nombre[0] != 'x') return -1;
        entero64 variable = 0;
        for (int posicion = 1; posicion < longitud; posicion++) {
            if (!isdigit((unsigned char)nombre[posicion])) return -1;
            variable = variable * 10 + (nombre[posicion] - '0');
            if (variable >= num_variables) return -1;
        }
        return (int)variable;
    }
    for (entero64 posicion = 0; posicion < num_variables; posicion++)
        if ((int)strlen(nombres_de_variables[posicion]) == longitud && strncmp(nombres_de_variables[posicion], nombre, longitud) == 0) return (int)posicion;
    return -1;
}

/* -------------------------------------------------------------------------------------
 *  anadir_factor_al_termino()
 *
 *  Añade variable^exponente al monomio que se está leyendo. Si la variable ya estaba,
 *  suma los exponentes (x*x -> x^2). Devuelve la posición del factor.
 *
 *  (Cocina: si la línea dice 'tomate, tomate', se apunta 'tomate x2'.)
 * ------------------------------------------------------------------------------------- */
static int anadir_factor_al_termino(int *variables, int *exponentes, int *num_factores_monomio, int variable, int exponente) {
    for (int posicion = 0; posicion < *num_factores_monomio; posicion++)
        if (variables[posicion] == variable) { exponentes[posicion] += exponente; return posicion; }
    if (*num_factores_monomio >= MAX_VARIABLES_POR_MONOMIO) error_texto("demasiadas variables distintas en un monomio (máx. 16)", NULL);
    variables[*num_factores_monomio] = variable; exponentes[*num_factores_monomio] = exponente;
    return (*num_factores_monomio)++;
}

/* -------------------------------------------------------------------------------------
 *  analizar_expresion()
 *
 *  Lee una suma de monomios del texto, desde 'cursor' hasta '=' o el fin de la línea, y
 *  los va añadiendo a la función. Entiende coeficientes (3, 0.5), variables, exponentes
 *  con '^' y, si los nombres son de una letra, la notación pegada del enunciado: 'yz3'
 *  = y·z^3. signo_del_lado es +1 a la izquierda del '=' y -1 a la derecha (todo pasa
 *  restando a la izquierda). Devuelve dónde se ha parado.
 *
 *  (Cocina: leer una línea del cuaderno del cliente y pasarla al libro, término a
 *  término.)
 * ------------------------------------------------------------------------------------- */
static char *analizar_expresion(char *cursor, double signo_del_lado) {
    int hay_termino = 0;
    for (;;) {
        double signo_del_termino = 1.0;
        int hubo_signo = 0;
        while (isspace((unsigned char)*cursor)) cursor++;
        while (*cursor == '+' || *cursor == '-') {
            if (*cursor == '-') signo_del_termino = -signo_del_termino;
            cursor++; hubo_signo = 1;
            while (isspace((unsigned char)*cursor)) cursor++;
        }
        if (*cursor == '\0' || *cursor == '=') {
            if (hubo_signo || !hay_termino) error_texto("falta un término", cursor);
            break;
        }
        if (hay_termino && !hubo_signo) error_texto("se esperaba '+' o '-' entre términos", cursor);

        /* ---- un término: coeficiente y factores ---- */
        double coeficiente = 1.0;
        int variables[MAX_VARIABLES_POR_MONOMIO], exponentes[MAX_VARIABLES_POR_MONOMIO], num_factores_monomio = 0, piezas_leidas = 0;
        for (;;) {
            while (isspace((unsigned char)*cursor) || *cursor == '*') cursor++;
            if (isdigit((unsigned char)*cursor) || *cursor == '.') {              /* número */
                char *fin_numero;
                double numero = strtod(cursor, &fin_numero);
                if (fin_numero == cursor) error_texto("número mal escrito", cursor);
                coeficiente *= numero; cursor = fin_numero; piezas_leidas++;
                continue;
            }
            if (isalpha((unsigned char)*cursor) || *cursor == '_') {               /* variable(s) */
                char *inicio_nombre = cursor;
                while (isalnum((unsigned char)*cursor) || *cursor == '_') cursor++;
                int longitud = (int)(cursor - inicio_nombre);
                int posicion_factor = -1, exponente_puesto = 1;
                if (nombres_de_una_letra) {                     /* "yz3" -> y · z^3 */
                    char *letra = inicio_nombre;
                    while (letra < cursor) {
                        if (!isalpha((unsigned char)*letra)) error_texto("nombre de variable no válido", letra);
                        int variable = buscar_variable_por_nombre(letra, 1);
                        if (variable < 0) error_texto("variable no declarada", letra);
                        letra++;
                        int exponente = 1;
                        if (letra < cursor && isdigit((unsigned char)*letra)) {
                            exponente = 0;
                            while (letra < cursor && isdigit((unsigned char)*letra)) { exponente = exponente * 10 + (*letra - '0'); letra++; }
                        }
                        posicion_factor = anadir_factor_al_termino(variables, exponentes, &num_factores_monomio, variable, exponente);
                        exponente_puesto = exponente;
                    }
                } else {
                    int variable = buscar_variable_por_nombre(inicio_nombre, longitud);
                    if (variable < 0) error_texto("variable no declarada", inicio_nombre);
                    posicion_factor = anadir_factor_al_termino(variables, exponentes, &num_factores_monomio, variable, 1);
                }
                while (isspace((unsigned char)*cursor)) cursor++;
                if (*cursor == '^') {                                         /* exponente */
                    cursor++;
                    while (isspace((unsigned char)*cursor)) cursor++;
                    if (!isdigit((unsigned char)*cursor)) error_texto("se esperaba un exponente entero", cursor);
                    long exponente_escrito = strtol(cursor, &cursor, 10);
                    exponentes[posicion_factor] += (int)exponente_escrito - exponente_puesto;
                }
                piezas_leidas++;
                continue;
            }
            break;
        }
        if (piezas_leidas == 0) error_texto("término vacío o carácter no válido", cursor);
        for (int posicion = 0; posicion < num_factores_monomio; posicion++)
            if (exponentes[posicion] < 0 || exponentes[posicion] > 255) error_texto("exponente fuera de rango [0, 255]", NULL);
        constructor_anadir_monomio(signo_del_lado * signo_del_termino * coeficiente, num_factores_monomio, variables, exponentes);
        hay_termino = 1;
    }
    return cursor;
}

/* -------------------------------------------------------------------------------------
 *  leer_variables()
 *
 *  Lee la línea 'variables:'. Puede ser una lista de nombres (x y z) o un número
 *  (variables: 1000 -> x0..x999). Comprueba nombres válidos y no repetidos.
 *
 *  (Cocina: apuntar la lista de ingredientes que va a usar el menú.)
 * ------------------------------------------------------------------------------------- */
static void leer_variables(char *cursor) {
    while (isspace((unsigned char)*cursor)) cursor++;
    char *fin_numero;
    long cantidad = strtol(cursor, &fin_numero, 10);
    char *resto = fin_numero;
    while (isspace((unsigned char)*resto)) resto++;
    if (fin_numero != cursor && *resto == '\0') {                       /* "variables: 1000" */
        if (cantidad <= 0) error_texto("el nº de variables debe ser > 0", cursor);
        num_variables = cantidad; nombres_de_variables = NULL; nombres_de_una_letra = 0;
        return;
    }
    entero64 capacidad = 8;                                            /* "variables: x y z" */
    nombres_de_variables = reservar(sizeof(char *) * capacidad, "nombres_de_variables");
    num_variables = 0; nombres_de_una_letra = 1;
    char *palabra = strtok(cursor, " \t,");
    while (palabra) {
        if (!(isalpha((unsigned char)palabra[0]) || palabra[0] == '_')) error_texto("nombre de variable no válido", palabra);
        for (char *caracter = palabra; *caracter; caracter++)
            if (!(isalnum((unsigned char)*caracter) || *caracter == '_')) error_texto("nombre de variable no válido", palabra);
        for (entero64 variable = 0; variable < num_variables; variable++)
            if (strcmp(nombres_de_variables[variable], palabra) == 0) error_texto("variable repetida", palabra);
        if (num_variables >= capacidad) { capacidad *= 2; nombres_de_variables = redimensionar(nombres_de_variables, sizeof(char *) * capacidad, "nombres_de_variables"); }
        nombres_de_variables[num_variables] = reservar(strlen(palabra) + 1, "nombres_de_variables");
        strcpy(nombres_de_variables[num_variables], palabra);
        if (strlen(palabra) != 1) nombres_de_una_letra = 0;
        num_variables++;
        palabra = strtok(NULL, " \t,");
    }
    if (num_variables == 0) error_texto("no hay variables", NULL);
}

/* -------------------------------------------------------------------------------------
 *  leer_linea_punto()
 *
 *  Lee la línea 'punto:' del fichero: un valor por variable (separados por espacios o
 *  comas).
 *
 *  (Cocina: las cantidades sugeridas que trae la propia receta.)
 * ------------------------------------------------------------------------------------- */
static void leer_linea_punto(char *cursor) {
    punto_del_fichero = reservar(sizeof(double) * num_variables, "punto_del_fichero");
    for (entero64 variable = 0; variable < num_variables; variable++) {
        char *fin_numero;
        punto_del_fichero[variable] = strtod(cursor, &fin_numero);
        if (fin_numero == cursor) error_texto("faltan valores en el punto", cursor);
        cursor = fin_numero;
        while (isspace((unsigned char)*cursor) || *cursor == ',') cursor++;
    }
    if (*cursor != '\0') error_texto("sobran valores en el punto", cursor);
}

/* -------------------------------------------------------------------------------------
 *  analizar_texto()
 *
 *  Recorre un texto completo línea a línea: quita comentarios (#), separa la etiqueta
 *  (lo de antes de ':') y decide qué es: 'variables', 'punto' o una función (cualquier
 *  otra etiqueta). Las funciones pueden tener '='.
 *
 *  (Cocina: leer el cuaderno del cliente entero y repartir cada línea a quien
 *  corresponda.)
 * ------------------------------------------------------------------------------------- */
static void analizar_texto(char *texto) {
    constructor_iniciar();
    int hay_variables = 0;
    linea_actual = 0;
    char *linea = texto;
    while (linea && *linea) {
        char *siguiente_linea = strchr(linea, '\n');
        if (siguiente_linea) *siguiente_linea++ = '\0';
        linea_actual++;
        char *comentario = strchr(linea, '#'); if (comentario) *comentario = '\0';
        char *retorno_carro  = strchr(linea, '\r'); if (retorno_carro) *retorno_carro = '\0';
        char *cursor = linea;
        while (isspace((unsigned char)*cursor)) cursor++;
        if (*cursor == '\0') { linea = siguiente_linea; continue; }

        char *dos_puntos = strchr(cursor, ':');
        if (dos_puntos == NULL) error_texto("falta la etiqueta (ej. 'f:' o 'variables:')", cursor);
        *dos_puntos = '\0';
        char *etiqueta = cursor, *cuerpo = dos_puntos + 1;
        char *fin_etiqueta = dos_puntos - 1;
        while (fin_etiqueta >= etiqueta && isspace((unsigned char)*fin_etiqueta)) *fin_etiqueta-- = '\0';

        if (strcmp(etiqueta, "variables") == 0) {
            if (hay_variables) error_texto("'variables' aparece dos veces", NULL);
            leer_variables(cuerpo);
            hay_variables = 1;
        } else if (strcmp(etiqueta, "punto") == 0) {
            if (!hay_variables) error_texto("'punto' antes de 'variables'", NULL);
            leer_linea_punto(cuerpo);
        } else {
            if (!hay_variables) error_texto("hay que declarar 'variables:' antes de las funciones", NULL);
            constructor_nueva_funcion();
            char *resto = analizar_expresion(cuerpo, +1.0);
            if (*resto == '=') {
                resto = analizar_expresion(resto + 1, -1.0);
                if (*resto == '=') error_texto("hay dos '=' en la misma ecuación", resto);
            }
        }
        linea = siguiente_linea;
    }
    if (!hay_variables) error_texto("falta la línea 'variables:'", NULL);
    if (num_funciones == 0) error_texto("no hay ninguna función", NULL);
}

/* =====================================================================================
 *  3. FORMATO NUMÉRICO (compatibilidad con la versión anterior; una sola función)
 *       n m
 *       coef k  v e  v e ...      <- un monomio por línea
 *       x0 x1 ... x(n-1)          <- el punto (opcional)
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  leer_formato_numerico()
 *
 *  Lee el formato numérico antiguo: 'n m', luego un monomio por línea (coef k v e v e
 *  ...) y, opcionalmente, el punto.
 *
 *  (Cocina: recetas escritas solo con números, como en una plantilla antigua.)
 * ------------------------------------------------------------------------------------- */
static void leer_formato_numerico(FILE *fichero) {
    entero64 cantidad_variables, cantidad_monomios;
    if (fscanf(fichero, "%lld %lld", &cantidad_variables, &cantidad_monomios) != 2 || cantidad_variables <= 0 || cantidad_monomios <= 0) {
        fprintf(stderr, "Error: cabecera 'n m' incorrecta\n"); exit(1);
    }
    num_variables = cantidad_variables; nombres_de_variables = NULL; nombres_de_una_letra = 0;
    constructor_iniciar();
    constructor_nueva_funcion();
    for (entero64 monomio = 0; monomio < cantidad_monomios; monomio++) {
        double coeficiente; int num_factores_monomio;
        if (fscanf(fichero, "%lf %d", &coeficiente, &num_factores_monomio) != 2 || num_factores_monomio < 0 || num_factores_monomio > MAX_VARIABLES_POR_MONOMIO) {
            fprintf(stderr, "Error: monomio %lld mal escrito (o más de %d variables)\n", monomio, MAX_VARIABLES_POR_MONOMIO); exit(1);
        }
        int variables[MAX_VARIABLES_POR_MONOMIO], exponentes[MAX_VARIABLES_POR_MONOMIO], factores_distintos = 0;
        for (int posicion = 0; posicion < num_factores_monomio; posicion++) {
            entero64 variable; int exponente;
            if (fscanf(fichero, "%lld %d", &variable, &exponente) != 2 || variable < 0 || variable >= cantidad_variables || exponente < 0 || exponente > 255) {
                fprintf(stderr, "Error: monomio %lld tiene una variable o exponente no válido\n", monomio); exit(1);
            }
            int posicion_factor = anadir_factor_al_termino(variables, exponentes, &factores_distintos, (int)variable, exponente);
            if (exponentes[posicion_factor] > 255) { fprintf(stderr, "Error: exponente > 255 en monomio %lld\n", monomio); exit(1); }
        }
        constructor_anadir_monomio(coeficiente, factores_distintos, variables, exponentes);
    }
    double *punto = reservar(sizeof(double) * cantidad_variables, "punto");
    entero64 variable;
    for (variable = 0; variable < cantidad_variables; variable++) if (fscanf(fichero, "%lf", &punto[variable]) != 1) break;
    if (variable == cantidad_variables) punto_del_fichero = punto; else free(punto);
}

/* =====================================================================================
 *  4. FORMATO BINARIO
 *     "GRADBIN1" | num_funciones num_variables num_monomios num_factores hay_punto (int64)
 *     | inicio_de_funcion (int64, E+1) | funcion_del_monomio (int32, M)
 *     | coeficiente_del_monomio (double, M) | inicio_del_monomio (int64, M+1)
 *     | variable_del_factor (int32, NNZ) | exponente_del_factor (uint8, NNZ)
 *     | punto (double, N, si hay)
 *  Los índices se guardan SIEMPRE en 64 bits: el mismo fichero sirve para la versión
 *  de 32 y de 64 bits. Portabilidad: los números se guardan en el formato de la máquina
 *  (little-endian en x86 y ARM habituales); el texto es el formato 100 % portable.
 * ===================================================================================== */
#define FIRMA_FICHERO_BINARIO "GRADBIN1"
#define TAMANO_BLOQUE_BINARIO (1 << 20)

/* -------------------------------------------------------------------------------------
 *  leer_bloque_binario()
 *
 *  Lee 'cantidad' elementos de un fichero binario; si faltan, avisa de que el fichero
 *  está incompleto.
 *
 *  (Cocina: sacar un paquete de la cámara congelada comprobando que está entero.)
 * ------------------------------------------------------------------------------------- */
static void leer_bloque_binario(void *destino, size_t tamano_elemento, size_t cantidad, FILE *fichero, const char *para_que) {
    if (fread(destino, tamano_elemento, cantidad, fichero) != cantidad) { fprintf(stderr, "Error: fichero binario incompleto (%s)\n", para_que); exit(1); }
}

/* -------------------------------------------------------------------------------------
 *  escribir_bloque_binario()
 *
 *  Escribe 'cantidad' elementos en un fichero binario.
 *
 *  (Cocina: envasar al vacío un paquete y meterlo en la cámara.)
 * ------------------------------------------------------------------------------------- */
static void escribir_bloque_binario(const void *origen, size_t tamano_elemento, size_t cantidad, FILE *fichero) {
    if (fwrite(origen, tamano_elemento, cantidad, fichero) != cantidad) { fprintf(stderr, "Error al escribir el fichero binario\n"); exit(1); }
}

/* -------------------------------------------------------------------------------------
 *  leer_formato_binario()
 *
 *  Lee un fichero .bin: firma 'GRADBIN1', cabecera con los tamaños y los arrays tal
 *  cual están en memoria. Es muchísimo más rápido que analizar texto.
 *  inicio_del_monomio se guarda siempre en 64 bits y aquí se convierte a tipo_indice
 *  por bloques. Al final se comprueba que los datos son coherentes (un fichero dañado
 *  no debe colgar el programa).
 *
 *  (Cocina: sacar el libro de recetas de la cámara: ya viene ordenado, solo hay que
 *  descongelar.)
 * ------------------------------------------------------------------------------------- */
static void leer_formato_binario(FILE *fichero) {
    char firma[8];
    entero64 cabecera[5];
    leer_bloque_binario(firma, 1, 8, fichero, "cabecera");
    leer_bloque_binario(cabecera, sizeof(entero64), 5, fichero, "cabecera");
    num_funciones = cabecera[0]; num_variables = cabecera[1]; num_monomios = cabecera[2]; num_factores = cabecera[3];
    if (num_funciones <= 0 || num_variables <= 0 || num_monomios < 0 || num_factores < 0) { fprintf(stderr, "Error: cabecera binaria no válida\n"); exit(1); }
    comprobar_cabe_en_indice(num_factores, "casillas del fichero binario");
    comprobar_cabe_en_indice(num_monomios, "monomios del fichero binario");
    nombres_de_variables = NULL; nombres_de_una_letra = 0; numero_original_de_variable = NULL;

    inicio_de_funcion      = reservar(sizeof(entero64) * (num_funciones + 1), "inicio_de_funcion");
    funcion_del_monomio = reservar(sizeof(int) * (num_monomios > 0 ? num_monomios : 1), "funcion_del_monomio");
    coeficiente_del_monomio           = reservar(sizeof(double) * (num_monomios > 0 ? num_monomios : 1), "coeficiente_del_monomio");
    inicio_del_monomio          = reservar(sizeof(tipo_indice) * (num_monomios + 1), "inicio_del_monomio");
    variable_del_factor            = reservar(sizeof(int) * (num_factores > 0 ? num_factores : 1), "variable_del_factor");
    exponente_del_factor           = reservar(num_factores > 0 ? num_factores : 1, "exponente_del_factor");

    leer_bloque_binario(inicio_de_funcion, sizeof(entero64), num_funciones + 1, fichero, "inicio_de_funcion");
    leer_bloque_binario(funcion_del_monomio, sizeof(int), num_monomios, fichero, "funcion_del_monomio");
    leer_bloque_binario(coeficiente_del_monomio, sizeof(double), num_monomios, fichero, "coeficiente_del_monomio");
    entero64 *bloque = reservar(sizeof(entero64) * TAMANO_BLOQUE_BINARIO, "bloque");     /* start: 64 -> tipo_indice */
    for (entero64 inicio_bloque = 0; inicio_bloque <= num_monomios; inicio_bloque += TAMANO_BLOQUE_BINARIO) {
        entero64 cantidad = (num_monomios + 1 - inicio_bloque < TAMANO_BLOQUE_BINARIO) ? num_monomios + 1 - inicio_bloque : TAMANO_BLOQUE_BINARIO;
        leer_bloque_binario(bloque, sizeof(entero64), cantidad, fichero, "inicio_del_monomio");
        for (entero64 posicion = 0; posicion < cantidad; posicion++) inicio_del_monomio[inicio_bloque + posicion] = (tipo_indice)bloque[posicion];
    }
    free(bloque);
    leer_bloque_binario(variable_del_factor, sizeof(int), num_factores, fichero, "variable_del_factor");
    leer_bloque_binario(exponente_del_factor, 1, num_factores, fichero, "exponente_del_factor");
    if (cabecera[4]) {
        punto_del_fichero = reservar(sizeof(double) * num_variables, "punto_del_fichero");
        leer_bloque_binario(punto_del_fichero, sizeof(double), num_variables, fichero, "punto");
    }
    /* comprobaciones de coherencia: un fichero corrupto no debe colgar el programa */
    if (inicio_de_funcion[0] != 0 || inicio_de_funcion[num_funciones] != num_monomios || inicio_del_monomio[0] != 0 || inicio_del_monomio[num_monomios] != num_factores) {
        fprintf(stderr, "Error: fichero binario incoherente\n"); exit(1);
    }
    for (entero64 factor = 0; factor < num_factores; factor++)
        if (variable_del_factor[factor] < 0 || variable_del_factor[factor] >= num_variables) { fprintf(stderr, "Error: variable fuera de rango en el binario\n"); exit(1); }
}

/* -------------------------------------------------------------------------------------
 *  escribir_formato_binario()
 *
 *  Escribe la función (y el punto, si se da) en formato binario .bin.
 *
 *  (Cocina: congelar el libro de recetas para la próxima vez.)
 * ------------------------------------------------------------------------------------- */
static void escribir_formato_binario(const char *nombre_fichero, const double *punto) {
    FILE *fichero = fopen(nombre_fichero, "wb");
    if (fichero == NULL) { fprintf(stderr, "No puedo crear '%s'\n", nombre_fichero); return; }
    entero64 cabecera[5] = { num_funciones, num_variables, num_monomios, num_factores, punto != NULL };
    escribir_bloque_binario(FIRMA_FICHERO_BINARIO, 1, 8, fichero);
    escribir_bloque_binario(cabecera, sizeof(entero64), 5, fichero);
    escribir_bloque_binario(inicio_de_funcion, sizeof(entero64), num_funciones + 1, fichero);
    escribir_bloque_binario(funcion_del_monomio, sizeof(int), num_monomios, fichero);
    escribir_bloque_binario(coeficiente_del_monomio, sizeof(double), num_monomios, fichero);
    entero64 *bloque = reservar(sizeof(entero64) * TAMANO_BLOQUE_BINARIO, "bloque");
    for (entero64 inicio_bloque = 0; inicio_bloque <= num_monomios; inicio_bloque += TAMANO_BLOQUE_BINARIO) {
        entero64 cantidad = (num_monomios + 1 - inicio_bloque < TAMANO_BLOQUE_BINARIO) ? num_monomios + 1 - inicio_bloque : TAMANO_BLOQUE_BINARIO;
        for (entero64 posicion = 0; posicion < cantidad; posicion++) bloque[posicion] = inicio_del_monomio[inicio_bloque + posicion];
        escribir_bloque_binario(bloque, sizeof(entero64), cantidad, fichero);
    }
    free(bloque);
    escribir_bloque_binario(variable_del_factor, sizeof(int), num_factores, fichero);
    escribir_bloque_binario(exponente_del_factor, 1, num_factores, fichero);
    if (punto) escribir_bloque_binario(punto, sizeof(double), num_variables, fichero);
    fclose(fichero);
}

/* -------------------------------------------------------------------------------------
 *  leer_funcion_de_fichero()
 *
 *  Abre un fichero y detecta su formato: si empieza por 'GRADBIN1' es binario; si lo
 *  primero (sin comentarios) es un número, es el formato numérico; si no, es texto.
 *
 *  (Cocina: mirar qué tipo de cuaderno nos han traído antes de empezar a copiar.)
 * ------------------------------------------------------------------------------------- */
void leer_funcion_de_fichero(const char *nombre_fichero) {
    FILE *fichero = fopen(nombre_fichero, "rb");
    if (fichero == NULL) { fprintf(stderr, "No puedo abrir '%s'\n", nombre_fichero); exit(1); }

    char firma[8] = {0};
    if (fread(firma, 1, 8, fichero) == 8 && memcmp(firma, FIRMA_FICHERO_BINARIO, 8) == 0) {
        rewind(fichero);
        leer_formato_binario(fichero);
        fclose(fichero);
        return;
    }
    rewind(fichero);

    /* Autodetección: si lo primero (sin comentarios) es un número -> formato numérico */
    int caracter, es_numerico = 0;
    while ((caracter = fgetc(fichero)) != EOF) {
        if (caracter == '#') { while ((caracter = fgetc(fichero)) != EOF && caracter != '\n') ; continue; }
        if (isspace(caracter)) continue;
        es_numerico = isdigit(caracter);
        break;
    }
    rewind(fichero);

    if (es_numerico) {
        leer_formato_numerico(fichero);
    } else {
        fseek(fichero, 0, SEEK_END);
        long tamano = ftell(fichero);
        rewind(fichero);
        char *texto = reservar(tamano + 1, "texto");
        size_t leidos = fread(texto, 1, tamano, fichero);
        texto[leidos] = '\0';
        analizar_texto(texto);
        free(texto);
    }
    fclose(fichero);
}

/* -------------------------------------------------------------------------------------
 *  leer_funcion_de_texto()
 *
 *  Construye la función a partir de un texto que está en memoria (se usa en las pruebas
 *  y en los ejemplos del enunciado).
 *
 *  (Cocina: copiar una receta que nos dictan, en vez de leerla de un cuaderno.)
 * ------------------------------------------------------------------------------------- */
void leer_funcion_de_texto(const char *texto) {
    char *copia = reservar(strlen(texto) + 1, "copia");
    strcpy(copia, texto);
    analizar_texto(copia);
    free(copia);
}

/* -------------------------------------------------------------------------------------
 *  cargar_ejemplo_enunciado()
 *
 *  Carga el ejemplo del enunciado: f(x,y,z) = 3xy + 4yz + 2x + 5 en el punto (1, 2, 3).
 *
 *  (Cocina: la receta de prueba con tomate, cebolla y ajo.)
 * ------------------------------------------------------------------------------------- */
void cargar_ejemplo_enunciado(void) {
    char texto[] =
        "variables: x y z\n"
        "f: 3xy + 4yz + 2x + 5\n"
        "punto: 1 2 3\n";
    analizar_texto(texto);
}

/* -------------------------------------------------------------------------------------
 *  cargar_sistema_enunciado()
 *
 *  Carga el sistema de 3 ecuaciones del enunciado. El enunciado no da punto: se usa
 *  (1,2,3).
 *
 *  (Cocina: el menú de prueba de tres platos.)
 * ------------------------------------------------------------------------------------- */
void cargar_sistema_enunciado(void) {
    /* Tal y como aparece en el enunciado (los superíndices se escriben con '^').
     * El enunciado no da punto: se usa (1, 2, 3) como en el ejemplo del gradiente. */
    char texto[] =
        "variables: x y z\n"
        "f1: 3x^2 + yz + z + 5 = 2\n"
        "f2: 2x + yz^3 + 2x + 2 = 0\n"
        "f3: 3xz + 8yz + z^2 + 1 = 4\n"
        "punto: 1 2 3\n";
    analizar_texto(texto);
}

/* -------------------------------------------------------------------------------------
 *  nombre_interno_de_variable()
 *
 *  Nombre de la variable en la numeración INTERNA actual (para escribir ficheros
 *  coherentes con el orden en que están los datos).
 *
 *  (Cocina: la etiqueta del estante donde está ahora el ingrediente.)
 * ------------------------------------------------------------------------------------- */
static void nombre_interno_de_variable(entero64 variable, char *texto, size_t tamano) {
    if (nombres_de_variables) snprintf(texto, tamano, "%s", nombres_de_variables[variable]);
    else           snprintf(texto, tamano, "x%lld", variable);
}

/* -------------------------------------------------------------------------------------
 *  escribir_funcion_en_fichero()
 *
 *  Guarda la función (y el punto) en un fichero: si el nombre acaba en .bin, en
 *  binario; si no, en formato de texto, que se puede volver a leer con -f.
 *
 *  (Cocina: pasar a limpio el libro de recetas para otro día.)
 * ------------------------------------------------------------------------------------- */
void escribir_funcion_en_fichero(const char *nombre_fichero, const double *punto) {
    size_t longitud = strlen(nombre_fichero);
    if (longitud > 4 && strcmp(nombre_fichero + longitud - 4, ".bin") == 0) {
        escribir_formato_binario(nombre_fichero, punto);
        printf("Función guardada en '%s' (binario)\n", nombre_fichero);
        return;
    }
    FILE *fichero = fopen(nombre_fichero, "w");
    if (fichero == NULL) { fprintf(stderr, "No puedo crear '%s'\n", nombre_fichero); return; }
    if (nombres_de_variables) {
        fputs("variables:", fichero);
        for (entero64 variable = 0; variable < num_variables; variable++) fprintf(fichero, " %s", nombres_de_variables[variable]);
        fputc('\n', fichero);
    } else {
        fprintf(fichero, "variables: %lld\n", num_variables);
    }
    char nombre[64];
    for (entero64 funcion = 0; funcion < num_funciones; funcion++) {
        fprintf(fichero, "f%lld:", funcion + 1);
        if (inicio_de_funcion[funcion] == inicio_de_funcion[funcion + 1]) fputs(" 0", fichero);
        for (entero64 monomio = inicio_de_funcion[funcion]; monomio < inicio_de_funcion[funcion + 1]; monomio++) {
            fprintf(fichero, " %s %.17g", coeficiente_del_monomio[monomio] < 0 ? "-" : "+", fabs(coeficiente_del_monomio[monomio]));
            for (entero64 factor = inicio_del_monomio[monomio]; factor < inicio_del_monomio[monomio + 1]; factor++) {
                nombre_interno_de_variable(variable_del_factor[factor], nombre, sizeof nombre);
                fprintf(fichero, "*%s^%d", nombre, exponente_del_factor[factor]);
            }
        }
        fputc('\n', fichero);
    }
    if (punto) {
        fputs("punto:", fichero);
        for (entero64 variable = 0; variable < num_variables; variable++) fprintf(fichero, " %.17g", punto[variable]);
        fputc('\n', fichero);
    }
    fclose(fichero);
    printf("Función guardada en '%s'\n", nombre_fichero);
}

