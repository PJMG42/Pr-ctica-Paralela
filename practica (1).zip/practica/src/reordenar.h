/* =====================================================================================
 *  reordenar.h — Renumerar variables y reordenar monomios para mejorar la localidad
 *
 *  Idea: si los monomios que se procesan seguidos usan variables con números cercanos,
 *  sus x[var] están en las mismas líneas de caché -> menos viajes a la RAM.
 *
 *  Algoritmo: recorrido en anchura (BFS) por el grafo bipartito variables–monomios, al
 *  estilo de Cuthill–McKee (la técnica clásica para reordenar matrices dispersas):
 *    - se empieza por una variable de grado mínimo (está en "un extremo" del grafo)
 *    - al visitar una variable, se visitan los monomios donde aparece; al visitar un
 *      monomio, se encolan sus variables aún no vistas
 *    - las variables se renumeran en el orden de visita; los monomios se colocan en
 *      el orden de visita (respetando a qué función pertenecen)
 *  Coste O(NNZ), pero SECUENCIAL (un BFS no se paraleliza de forma sencilla).
 *
 *  (Cocina: RECOLOCAR EL ALMACÉN para que los ingredientes que salen en las mismas
 *  recetas estén en estantes vecinos y el pinche no tenga que ir de punta a punta.)
 * ===================================================================================== */
#ifndef REORDENAR_H
#define REORDENAR_H

#include "comun.h"

/* Reordena la función/sistema en el sitio. x (puede ser NULL) se permuta igual.
 * Devuelve los segundos empleados. Después, numero_original_de_variable[nuevo] = original.       */
double reordenar_variables_y_monomios(double *punto);

/* Deshace la permutación de un vector por variables: orig[numero_original_de_variable[i]] = v[i] */
void volver_al_orden_original(const double *vector_interno, double *vector_original);

/* Medida de localidad: distancia media entre las variables de casillas consecutivas.
 * Cuanto menor, más probable que x[var] ya esté en caché.                          */
double distancia_media_accesos(void);

#endif
