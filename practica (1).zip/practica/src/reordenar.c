/* =====================================================================================
 *  reordenar.c — Reordenación BFS (tipo Cuthill–McKee) de variables y monomios
 *
 *  (Cocina: recolocar el almacén (ver reordenar.h).)
 * ===================================================================================== */
#include "reordenar.h"
#include "polinomio.h"
#include "derivadas.h"

static entero64 *grado_para_comparar = NULL;              /* para ordenar variables por grado */
/* -------------------------------------------------------------------------------------
 *  comparar_grado()
 *
 *  Función de comparación para qsort: ordena variables por grado (en cuántos factores
 *  aparecen), de menor a mayor.
 *
 *  (Cocina: ordenar los ingredientes de menos usado a más usado.)
 * ------------------------------------------------------------------------------------- */
static int comparar_grado(const void *primero, const void *segundo) {
    entero64 grado_primero = grado_para_comparar[*(const int *)primero], grado_segundo = grado_para_comparar[*(const int *)segundo];
    return (grado_primero > grado_segundo) - (grado_primero < grado_segundo);
}

/* -------------------------------------------------------------------------------------
 *  reordenar_variables_y_monomios()
 *
 *  Renumera variables y reordena monomios para que lo que se usa junto quede junto en
 *  memoria. Pasos: (1) índice variable -> factores (en paralelo); (2) variables
 *  ordenadas por grado para elegir por dónde empezar; (3) recorrido en anchura (BFS,
 *  con una cola): al visitar una variable se visitan sus monomios y al visitar un
 *  monomio se encolan sus variables; (4) se agrupan los monomios por función
 *  manteniendo el orden del BFS; (5) se reconstruyen los arrays en el orden nuevo (en
 *  paralelo); (6) se permuta todo lo que va por variable (punto, nombres...). Devuelve
 *  los segundos empleados.
 *
 *  (Cocina: recolocar el almacén para que los ingredientes que salen en las mismas
 *  recetas estén en estantes vecinos; así, al traer una caja, viene también lo que se
 *  va a usar enseguida.)
 * ------------------------------------------------------------------------------------- */
double reordenar_variables_y_monomios(double *punto) {
    double inicio_reloj = omp_get_wtime();
    entero64 total_variables = num_variables, total_monomios = num_monomios, total_factores = num_factores, total_funciones = num_funciones;

    /* --- 1. Índice variable -> casillas (transpuesta, en paralelo) y casilla -> monomio --- */
    tipo_indice *inicio_por_variable  = reservar(sizeof(tipo_indice) * (total_variables + 1), "inicio_por_variable");
    tipo_indice *factores_agrupados  = reservar(sizeof(tipo_indice) * (total_factores > 0 ? total_factores : 1), "factores_agrupados");
    tipo_indice *monomio_de_la_casilla = reservar(sizeof(tipo_indice) * (total_factores > 0 ? total_factores : 1), "monomio_de_la_casilla");
    agrupar_factores_por_variable(inicio_por_variable, factores_agrupados);
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 monomio = 0; monomio < total_monomios; monomio++)
        for (entero64 factor = inicio_del_monomio[monomio]; factor < inicio_del_monomio[monomio + 1]; factor++) monomio_de_la_casilla[factor] = (tipo_indice)monomio;

    /* --- 2. Variables ordenadas por grado (para elegir los puntos de inicio) --- */
    int *por_grado = reservar(sizeof(int) * total_variables, "por_grado");
    grado_para_comparar = reservar(sizeof(entero64) * total_variables, "grado_para_comparar");
    for (entero64 variable = 0; variable < total_variables; variable++) { por_grado[variable] = (int)variable; grado_para_comparar[variable] = inicio_por_variable[variable + 1] - inicio_por_variable[variable]; }
    qsort(por_grado, total_variables, sizeof(int), comparar_grado);

    /* --- 3. BFS --- */
    int   *variable_original_en_posicion = reservar(sizeof(int) * total_variables, "variable_original_en_posicion");  /* nuevo -> viejo */
    char  *variable_visitada = reservar_cero(total_variables, 1, "variable_visitada");
    char  *monomio_visitado = reservar_cero(total_monomios, 1, "monomio_visitado");
    tipo_indice *orden_de_monomios = reservar(sizeof(tipo_indice) * (total_monomios > 0 ? total_monomios : 1), "orden_de_monomios");
    entero64 variables_ordenadas = 0, monomios_ordenados = 0, cabeza_de_cola = 0;

    for (entero64 posicion = 0; posicion < total_variables; posicion++) {
        int variable_inicial = por_grado[posicion];
        if (variable_visitada[variable_inicial] || grado_para_comparar[variable_inicial] == 0) continue;
        variable_visitada[variable_inicial] = 1;
        variable_original_en_posicion[variables_ordenadas++] = variable_inicial;
        while (cabeza_de_cola < variables_ordenadas) {
            int variable_actual = variable_original_en_posicion[cabeza_de_cola++];
            for (entero64 casilla = inicio_por_variable[variable_actual]; casilla < inicio_por_variable[variable_actual + 1]; casilla++) {
                tipo_indice monomio = monomio_de_la_casilla[factores_agrupados[casilla]];
                if (monomio_visitado[monomio]) continue;
                monomio_visitado[monomio] = 1;
                orden_de_monomios[monomios_ordenados++] = monomio;
                for (entero64 otro_factor = inicio_del_monomio[monomio]; otro_factor < inicio_del_monomio[monomio + 1]; otro_factor++) {
                    int otra_variable = variable_del_factor[otro_factor];
                    if (!variable_visitada[otra_variable]) { variable_visitada[otra_variable] = 1; variable_original_en_posicion[variables_ordenadas++] = otra_variable; }
                }
            }
        }
    }
    for (entero64 variable = 0; variable < total_variables; variable++) if (!variable_visitada[variable]) variable_original_en_posicion[variables_ordenadas++] = (int)variable;   /* sin uso */
    for (entero64 monomio = 0; monomio < total_monomios; monomio++) if (!monomio_visitado[monomio]) orden_de_monomios[monomios_ordenados++] = (tipo_indice)monomio;  /* constantes */
    free(inicio_por_variable); free(factores_agrupados); free(monomio_de_la_casilla); free(por_grado); free(grado_para_comparar); grado_para_comparar = NULL;
    free(variable_visitada); free(monomio_visitado);

    /* --- 4. Agrupar por función manteniendo el orden BFS (ordenación por recuento) --- */
    tipo_indice *monomio_en_posicion = reservar(sizeof(tipo_indice) * (total_monomios > 0 ? total_monomios : 1), "monomio_en_posicion");
    entero64 *siguiente_hueco_de_funcion = reservar(sizeof(entero64) * (total_funciones + 1), "siguiente_hueco_de_funcion");
    for (entero64 funcion = 0; funcion <= total_funciones; funcion++) siguiente_hueco_de_funcion[funcion] = inicio_de_funcion[funcion];
    for (entero64 posicion = 0; posicion < total_monomios; posicion++) {
        tipo_indice monomio = orden_de_monomios[posicion];
        monomio_en_posicion[siguiente_hueco_de_funcion[funcion_del_monomio[monomio]]++] = monomio;
    }
    free(siguiente_hueco_de_funcion); free(orden_de_monomios);

    int *numero_nuevo_de_variable = reservar(sizeof(int) * total_variables, "numero_nuevo_de_variable");          /* viejo -> nuevo */
    for (entero64 posicion = 0; posicion < total_variables; posicion++) numero_nuevo_de_variable[variable_original_en_posicion[posicion]] = (int)posicion;

    /* --- 5. Reconstruir los arrays en el nuevo orden (en paralelo) --- */
    double        *nuevo_coeficiente  = reservar(sizeof(double) * total_monomios, "nuevo_coeficiente");
    int           *nueva_funcion   = reservar(sizeof(int) * total_monomios, "nueva_funcion");
    tipo_indice         *nuevo_inicio = reservar(sizeof(tipo_indice) * (total_monomios + 1), "nuevo_inicio");
    int           *nueva_variable   = reservar(sizeof(int) * (total_factores > 0 ? total_factores : 1), "nueva_variable");
    unsigned char *nuevo_exponente  = reservar(total_factores > 0 ? total_factores : 1, "nuevo_exponente");
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 posicion = 0; posicion < total_monomios; posicion++) {
        tipo_indice monomio = monomio_en_posicion[posicion];
        nuevo_coeficiente[posicion] = coeficiente_del_monomio[monomio];
        nueva_funcion[posicion]  = funcion_del_monomio[monomio];
        nuevo_inicio[posicion] = inicio_del_monomio[monomio + 1] - inicio_del_monomio[monomio];
    }
    suma_prefija_indices(nuevo_inicio, total_monomios, "reordenar: start");
    nuevo_inicio[total_monomios] = (tipo_indice)total_factores;
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 posicion = 0; posicion < total_monomios; posicion++) {
        tipo_indice monomio = monomio_en_posicion[posicion];
        entero64 destino = nuevo_inicio[posicion];
        for (entero64 factor = inicio_del_monomio[monomio]; factor < inicio_del_monomio[monomio + 1]; factor++, destino++) {
            nueva_variable[destino]  = numero_nuevo_de_variable[variable_del_factor[factor]];
            nuevo_exponente[destino] = exponente_del_factor[factor];
        }
    }
    free(coeficiente_del_monomio); free(funcion_del_monomio); free(inicio_del_monomio); free(variable_del_factor); free(exponente_del_factor);
    coeficiente_del_monomio = nuevo_coeficiente; funcion_del_monomio = nueva_funcion; inicio_del_monomio = nuevo_inicio; variable_del_factor = nueva_variable; exponente_del_factor = nuevo_exponente;
    free(monomio_en_posicion);

    /* --- 6. Permutar todo lo que va "por variable" --- */
    double *temporal = reservar(sizeof(double) * total_variables, "temporal");
    if (punto)       { for (entero64 posicion = 0; posicion < total_variables; posicion++) temporal[posicion] = punto[variable_original_en_posicion[posicion]];       memcpy(punto, temporal, sizeof(double) * total_variables); }
    if (punto_del_fichero) { for (entero64 posicion = 0; posicion < total_variables; posicion++) temporal[posicion] = punto_del_fichero[variable_original_en_posicion[posicion]]; memcpy(punto_del_fichero, temporal, sizeof(double) * total_variables); }
    free(temporal);
    if (nombres_de_variables) {
        char **nuevos_nombres = reservar(sizeof(char *) * total_variables, "nuevos_nombres");
        for (entero64 posicion = 0; posicion < total_variables; posicion++) nuevos_nombres[posicion] = nombres_de_variables[variable_original_en_posicion[posicion]];
        free(nombres_de_variables); nombres_de_variables = nuevos_nombres;
    }
    if (numero_original_de_variable) {                        /* reordenar dos veces: componer */
        for (entero64 posicion = 0; posicion < total_variables; posicion++) variable_original_en_posicion[posicion] = numero_original_de_variable[variable_original_en_posicion[posicion]];
        free(numero_original_de_variable);
    }
    numero_original_de_variable = variable_original_en_posicion;
    free(numero_nuevo_de_variable);
    return omp_get_wtime() - inicio_reloj;
}

/* -------------------------------------------------------------------------------------
 *  volver_al_orden_original()
 *
 *  Deshace la renumeración en un vector por variables (por ejemplo, el gradiente), para
 *  mostrarlo en el orden que espera el usuario.
 *
 *  (Cocina: dar el resultado con los nombres y el orden del cliente, no con los
 *  estantes del almacén.)
 * ------------------------------------------------------------------------------------- */
void volver_al_orden_original(const double *vector_interno, double *vector_original) {
    if (numero_original_de_variable == NULL) { memcpy(vector_original, vector_interno, sizeof(double) * num_variables); return; }
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 variable = 0; variable < num_variables; variable++) vector_original[numero_original_de_variable[variable]] = vector_interno[variable];
}

/* -------------------------------------------------------------------------------------
 *  distancia_media_accesos()
 *
 *  Medida de localidad: distancia media entre los números de variable de factores
 *  consecutivos. Cuanto menor, más probable que el valor de la variable ya esté en
 *  caché.
 *
 *  (Cocina: cuántos pasos de media da el pinche entre un ingrediente y el siguiente.)
 * ------------------------------------------------------------------------------------- */
double distancia_media_accesos(void) {
    if (num_factores < 2) return 0.0;
    double suma = 0.0;
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales; cada hilo suma en su
     * copia privada de suma y al final OpenMP las junta. (Cocina: los cocineros se reparten estas
     * comandas; a cada uno el mismo número de comandas, decidido antes de empezar; cada cocinero
     * su cuenco; al final se vuelcan todos en la olla.) */
    #pragma omp parallel for reduction(+:suma) schedule(static)
    for (entero64 factor = 1; factor < num_factores; factor++) suma += fabs((double)variable_del_factor[factor] - (double)variable_del_factor[factor - 1]);
    return suma / (num_factores - 1);
}
