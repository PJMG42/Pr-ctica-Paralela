/* =====================================================================================
 *  comun.h — Utilidades compartidas por todos los módulos
 *
 *  - Tipos enteros: entero64 (64 bits) e tipo_indice (índices de los arrays grandes)
 *  - Reserva de memoria con comprobación de errores
 *  - Suma prefija paralela (pieza básica para construir arrays tipo CSR en paralelo)
 *  - Potencia entera y generador de números aleatorios paralelizable
 *
 *  (Cocina: los UTENSILIOS comunes de toda la cocina: pedir estantes al almacén
 *  (reservar), numerar las páginas del libro (sumas prefijas), la medida rápida
 *  (potencia_entera) y el dado de cada receta (números aleatorios).)
 * ===================================================================================== */
#ifndef COMUN_H
#define COMUN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "omp_compat.h"

typedef long long entero64;          /* entero de 64 bits (contadores, bucles)              */

/* ---------- Tipo de los ÍNDICES de los arrays grandes ----------
 *  Por defecto 32 bits: la mitad de memoria que 64 bits en todos los arrays de índices
 *  (start, transpuesta, entradas...): menos bytes que leer y problemas más grandes en la
 *  misma RAM. Límite: ~2.100 millones de casillas.
 *  Para problemas mayores (o para comparar):   make INDICES=64                         */
#ifdef INDICES64
typedef long long tipo_indice;
#define MAXIMO_INDICE    9223372036854775807LL
#define BITS_INDICE   64
#else
typedef int tipo_indice;
#define MAXIMO_INDICE    2147483647LL
#define BITS_INDICE   32
#endif

#define MAX_VARIABLES_POR_MONOMIO            16      /* máx. variables distintas en un mismo monomio        */
#define PUNTOS_POR_LOTE            8       /* puntos por lote: 8 doubles = un registro AVX-512    */
#define LIMITE_MEMORIA  (3.0e9) /* bytes máx. para buffers auxiliares opcionales       */

/* ---------- Memoria ---------- */
void *reservar(size_t bytes, const char *para_que);
void *reservar_cero(size_t cuantos_elementos, size_t tamano_elemento, const char *para_que);
void *redimensionar(void *memoria, size_t bytes, const char *para_que);

/* ---------- Sumas prefijas paralelas (exclusive scan) ----------
 *  a = [3, 1, 2, 4]  ->  a = [0, 3, 4, 6]  y devuelve 10
 *  suma_prefija_indices aborta con un mensaje claro si el total no cabe en tipo_indice.             */
entero64 suma_prefija_paralela(entero64 *valores, entero64 longitud);
entero64 suma_prefija_indices(tipo_indice *valores, entero64 longitud, const char *para_que);
void comprobar_cabe_en_indice(entero64 valor, const char *para_que);

/* ---------- Punto aleatorio en [0.5, 1), generado en paralelo ---------- */
void generar_valores_aleatorios(entero64 cantidad, unsigned long long semilla, double *valores);

/* ---------- Salida ---------- */
void imprimir_linea(void);
void imprimir_bytes(const char *nombre, double bytes);

/* -------------------------------------------------------------------------------------
 *  potencia_entera()
 *
 *  base^exponente con exponente entero >= 0, por EXPONENCIACIÓN RÁPIDA: se va elevando
 *  la base al cuadrado (b, b², b⁴, b⁸...) y se multiplican solo las que indica cada bit
 *  del exponente. x^13 = x^8 · x^4 · x: unas 5 operaciones en vez de 12. Más rápido que
 *  pow() y exacto para enteros.
 *
 *  (Cocina: para echar 13 cucharadas no se cuentan una a una: se usan medidas de 8, 4 y
 *  1.)
 * ------------------------------------------------------------------------------------- */
static inline double potencia_entera(double base, int exponente) {
    double resultado = 1.0;
    while (exponente > 0) { if (exponente & 1) resultado *= base; base *= base; exponente >>= 1; }
    return resultado;
}

/* -------------------------------------------------------------------------------------
 *  siguiente_aleatorio()
 *
 *  Generador de números aleatorios splitmix64: a partir del estado, devuelve un número
 *  de 64 bits y avanza el estado. rand() no sirve en paralelo porque tiene un estado
 *  global que comparten todos los hilos.
 *
 *  (Cocina: tirar el dado y pasar a la siguiente cara.)
 * ------------------------------------------------------------------------------------- */
static inline unsigned long long siguiente_aleatorio(unsigned long long *estado) {
    unsigned long long mezcla = (*estado += 0x9E3779B97F4A7C15ULL);
    mezcla = (mezcla ^ (mezcla >> 30)) * 0xBF58476D1CE4E5B9ULL;
    mezcla = (mezcla ^ (mezcla >> 27)) * 0x94D049BB133111EBULL;
    return mezcla ^ (mezcla >> 31);
}

/* -------------------------------------------------------------------------------------
 *  semilla_del_elemento()
 *
 *  Calcula la semilla PROPIA del elemento número 'elemento' mezclando la semilla global
 *  con ese número. Cada monomio (o cada valor) genera su secuencia sin depender de los
 *  demás: el resultado es IDÉNTICO con 1 o con 64 hilos.
 *
 *  (Cocina: cada receta tiene su propio dado; da igual qué cocinero la invente o en qué
 *  orden: sale la misma.)
 * ------------------------------------------------------------------------------------- */
static inline unsigned long long semilla_del_elemento(unsigned long long semilla, entero64 elemento) {
    unsigned long long estado = semilla ^ ((unsigned long long)elemento * 0xD1B54A32D192ED03ULL);
    siguiente_aleatorio(&estado);
    return estado;
}

/* -------------------------------------------------------------------------------------
 *  aleatorio_entre_0_y_1()
 *
 *  Número real uniforme en [0, 1): se quedan los 53 bits altos del número aleatorio
 *  (los que caben en la mantisa de un double).
 *
 *  (Cocina: convertir la tirada del dado en un porcentaje.)
 * ------------------------------------------------------------------------------------- */
static inline double aleatorio_entre_0_y_1(unsigned long long *estado) {       /* uniforme en [0,1) */
    return (siguiente_aleatorio(estado) >> 11) * (1.0 / 9007199254740992.0);
}

#endif
