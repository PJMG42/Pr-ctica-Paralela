/* =====================================================================================
 *  pruebas.h — Batería de pruebas automáticas ("make test" o "./gradiente -T")
 *
 *  1. Ecuaciones de prueba con resultado conocido (calculado a mano): el programa debe
 *     dar exactamente ese gradiente / Jacobiano.
 *  2. Problemas aleatorios: TODAS las estrategias paralelas, con 1, 2, ..., T hilos,
 *     deben dar el mismo resultado que la secuencial (la familia simbólica, idéntico
 *     bit a bit; las demás suman en otro orden, diferencia de redondeo <= 1e-12).
 *
 *  (Cocina: la visita del CATADOR: platos de sabor conocido y la regla de oro: el plato
 *  debe saber igual lo cocine un cocinero o dieciséis.)
 * ===================================================================================== */
#ifndef PRUEBAS_H
#define PRUEBAS_H

/* Devuelve el número de pruebas fallidas (0 = todo correcto) */
int ejecutar_pruebas(int hilos);

#endif
