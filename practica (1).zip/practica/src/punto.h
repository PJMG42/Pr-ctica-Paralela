/* =====================================================================================
 *  punto.h — LECTURA DEL PUNTO donde se evalúa (y se valida) el gradiente
 *
 *  Orígenes posibles:
 *    auto        el punto que trae el fichero de la función; si no trae, uno aleatorio
 *    teclado     se escriben los valores en el terminal
 *    fichero     se leen de un fichero de datos (números separados por espacios)
 *    aleatorio   valores aleatorios en [0.5, 1)
 *    interactivo después de calcular las derivadas (PASO 1 y 2), el programa pide un
 *                COMANDO para elegir de dónde leer el punto, y permite evaluar en
 *                tantos puntos como se quiera sin repetir la derivación
 *
 *  El origen por defecto se elige AL COMPILAR:
 *      make PUNTO=teclado            make PUNTO=fichero PUNTO_FICHERO=mi_punto.txt
 *      make PUNTO=interactivo        make PUNTO=aleatorio       (por defecto: auto)
 *  y se puede cambiar AL EJECUTAR con  -O origen  y  -F fichero.
 *
 *  (Cocina: el PEDIDO de hoy, es decir, las cantidades reales de cada ingrediente.
 *  Puede llegar por teléfono (teclado), por escrito (fichero), sorteado (aleatorio), el
 *  que traía la receta (auto) o ir pidiéndolos uno tras otro con las fichas ya escritas
 *  (interactivo).)
 * ===================================================================================== */
#ifndef PUNTO_H
#define PUNTO_H

#include "comun.h"

#define ORIGEN_AUTO        0
#define ORIGEN_TECLADO     1
#define ORIGEN_FICHERO     2
#define ORIGEN_ALEATORIO   3
#define ORIGEN_INTERACTIVO 4

/* Valores fijados al compilar (los pone el Makefile) */
#ifndef PUNTO_ORIGEN
#define PUNTO_ORIGEN ORIGEN_AUTO
#endif
#ifndef PUNTO_FICHERO
#define PUNTO_FICHERO "punto.txt"
#endif

extern const char *nombre_del_origen[5];
int origen_desde_nombre(const char *nombre);              /* "teclado" -> ORIGEN_TECLADO ... */

/* Rellena x (en la numeración INTERNA del programa, por si se reordenó).
 * Devuelve 1 si ha podido, 0 si no (fichero inexistente, faltan valores, fin de entrada). */
int obtener_punto(int origen, const char *fichero, unsigned long long semilla, double *punto);

int  leer_punto_de_fichero(const char *ruta, double *punto);
int  leer_punto_de_teclado(double *punto);
void punto_aleatorio(unsigned long long semilla, double *punto);
void escribir_punto_en_fichero(const char *ruta, const double *punto);   /* en el orden original */

#endif
