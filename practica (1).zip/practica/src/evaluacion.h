/* =====================================================================================
 *  evaluacion.h — PASO 3: evaluación numérica en un punto, con varias estrategias
 *
 *  Todas las estrategias calculan lo mismo: jacobiano[e] = valor de la entrada e del Jacobiano
 *  (para E = 1, el gradiente: jacobiano de la columna i es ∂f/∂x_i). Se comparan entre sí.
 *
 *  Sobre los polinomios derivados del PASO 1 (siguen el método del enunciado):
 *    0 secuencial          referencia: evalúa cada derivada parcial, una tras otra
 *    1 por_variables       paralelo sobre las derivadas parciales (columnas)
 *    2 por_monomios        paralelo sobre todos los monomios derivados + suma por entrada
 *    3 anidado             variables (T1 hilos) × monomios de cada derivada (T2 hilos)
 *
 *  Optimización algorítmica (sin materializar el PASO 1, deriva "al vuelo"):
 *    4 directo_secuencial  referencia secuencial de esta familia
 *    5 directo_atomico     paralelo sobre los monomios originales, suma con atomic
 *    6 directo_privado     ídem, con una copia de resultados por hilo
 *
 *  Cada familia se compara con SU secuencial: así el speedup mide solo el paralelismo,
 *  y la comparación entre familias (secuencial vs directo_secuencial) mide la mejora algorítmica.
 *
 *  (Cocina: COCINAR con las cantidades de hoy (PASO 3). Cada estrategia es una forma de
 *  organizar a los cocineros: un solo cocinero, fichas completas por cocinero, líneas
 *  sueltas en una bandeja común, jefes con pinches, o cocinar directamente de la receta
 *  original apuntando con turno (atomic) o cada uno en su libreta (copias privadas).
 *  Los lotes cocinan 8 pedidos a la vez en una bandeja.)
 * ===================================================================================== */
#ifndef EVALUACION_H
#define EVALUACION_H

#include "comun.h"

#define NUM_ESTRATEGIAS 7
#define ESTRATEGIA_DIRECTA_SECUENCIAL 4   /* índice de la referencia secuencial de la familia directa */

typedef void (*tipo_funcion_jacobiano)(const double *punto, double *jacobiano);

extern const char    *nombre_estrategia[NUM_ESTRATEGIAS];
extern tipo_funcion_jacobiano  funcion_estrategia[NUM_ESTRATEGIAS];

/* Parámetros de la estrategia anidada */
extern int hilos_nivel_externo, hilos_nivel_interno;
extern entero64 umbral_anidado;     /* nº mín. de monomios para abrir un equipo interno */

void   preparar_evaluacion(int hilos);     /* buffers auxiliares (una vez)          */
void   liberar_evaluacion(void);
int    estrategia_disponible(int estrategia, int hilos);
double memoria_evaluacion(int hilos);

void   evaluar_funciones(const double *punto, double *valor_de_funcion);   /* f(x) de cada función  */
void   jacobiano_por_variables_con_hilos(const double *punto, double *jacobiano, int hilos); /* para lotes */
void   expandir_gradiente(const double *jacobiano, double *gradiente);  /* E = 1: jacobiano -> gradiente[N] */
void   imprimir_paso3(const double *punto, const double *jacobiano);

/* ---------- Bytes de memoria que mueve cada estrategia en UNA evaluación ----------
 *  Modelo de "bytes útiles": lo que el algoritmo necesita leer y escribir como mínimo.
 *  Es una cota inferior: un acceso aleatorio trae de la RAM una línea entera de 64 B. */
double bytes_movidos_estrategia(int estrategia, int hilos);

/* ---------- LOTES: leer cada monomio UNA vez para PUNTOS_POR_LOTE (= 8) puntos ----------
 *  Los puntos van intercalados: puntos_lote[i*PUNTOS_POR_LOTE + b] = variable i del punto b,
 *  y la salida igual: jacobianos_lote[e*PUNTOS_POR_LOTE + b]. Así los 8 valores que se usan juntos están seguidos en
 *  memoria (una línea de caché) y el bucle sobre b se vectoriza (SIMD).             */
#define NUM_ESTRATEGIAS_LOTE 2
extern const char *nombre_estrategia_lote[NUM_ESTRATEGIAS_LOTE];
typedef void (*tipo_funcion_lote)(const double *puntos_lote, double *jacobianos_lote);
extern tipo_funcion_lote funcion_estrategia_lote[NUM_ESTRATEGIAS_LOTE];
int    lote_disponible(int estrategia_lote, int hilos);
double bytes_movidos_lote(int estrategia_lote, int hilos);       /* bytes por lote de PUNTOS_POR_LOTE puntos */

#endif
