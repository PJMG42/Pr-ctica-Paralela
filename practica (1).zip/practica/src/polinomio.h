/* =====================================================================================
 *  polinomio.h — Representación DINÁMICA de una función (o un sistema de funciones)
 *                polinómica con N variables y M monomios.
 *
 *  Sin structs: todo son arrays globales en memoria dinámica (formato tipo CSR).
 *
 *  Ejemplo: sistema de E = 2 funciones con N = 3 variables (x, y, z)
 *
 *      f0 = 3xy + 4yz + 2x + 5
 *      f1 = x^2 z - y
 *
 *  inicio_de_funcion       = [ 0,                 4,            6 ]  E+1: monomios de cada función
 *  coeficiente_del_monomio = [ 3,    4,    2,  5,   1,       -1   ]  M  : coeficiente
 *  inicio_del_monomio      = [ 0,    2,    4,  5,   5,    7,  8   ]  M+1: casillas de cada monomio
 *  variable_del_factor     = [ 0,1,  1,2,  0,       0,2,   1      ]  NNZ: variable
 *  exponente_del_factor    = [ 1,1,  1,1,  1,       2,1,   1      ]  NNZ: exponente
 *
 *  (Cada "casilla" o FACTOR es una pareja (variable, exponente) dentro de un monomio.)
 *
 *  - El monomio t ocupa las casillas inicio_del_monomio[t] .. inicio_del_monomio[t+1]-1.
 *  - El monomio "5" es una constante: no tiene casillas (inicio_del_monomio[3] == inicio_del_monomio[4]).
 *  - La función f ocupa los monomios inicio_de_funcion[f] .. inicio_de_funcion[f+1]-1.
 *  - Para una sola función (el caso del gradiente) E = 1.
 *
 *  (Cocina: el LIBRO DE RECETAS. Función = receta de un plato; monomio = una línea de
 *  la receta; coeficiente = la cantidad fija de la línea; factor = un ingrediente de la
 *  línea con cuántas veces entra (variable, exponente); los arrays inicio_de_... son el
 *  índice de páginas: la receta k va de la página inicio[k] a inicio[k+1]-1. Un sistema
 *  de E funciones es un menú de E platos.)
 * ===================================================================================== */
#ifndef POLINOMIO_H
#define POLINOMIO_H

#include "comun.h"

extern entero64      num_funciones;                  /* nº de funciones (ecuaciones) */
extern entero64      num_variables;                  /* nº de variables */
extern entero64      num_monomios;                   /* nº total de monomios */
extern entero64      num_factores;                   /* nº total de casillas (variable, exponente) */
extern entero64      *inicio_de_funcion;             /* [E+1] */
extern int           *funcion_del_monomio;           /* [M]   función a la que pertenece el monomio */
extern double        *coeficiente_del_monomio;       /* [M] */
extern tipo_indice   *inicio_del_monomio;            /* [M+1] */
extern int           *variable_del_factor;           /* [NNZ] */
extern unsigned char *exponente_del_factor;          /* [NNZ] */

extern char          **nombres_de_variables;         /* [N] nombres de variables (NULL -> x0, x1...) */
extern int           nombres_de_una_letra;           /* 1 si todos los nombres tienen una letra */
extern double        *punto_del_fichero;             /* [N] punto leído del fichero (o NULL) */
extern int           *numero_original_de_variable;   /* [N] tras reordenar: nº nuevo -> nº original */

/* Construcción */
void generar_funcion_aleatoria(entero64 total_funciones, entero64 total_variables, entero64 monomios_por_funcion, int max_variables_por_monomio, int max_exponente,
                  unsigned long long semilla, entero64 ventana, int desordenar);
void cargar_ejemplo_enunciado(void);          /* f(x,y,z) = 3xy + 4yz + 2x + 5, punto (1,2,3) */
void cargar_sistema_enunciado(void);          /* el sistema de 3 ecuaciones del enunciado     */
void leer_funcion_de_fichero(const char *nombre_fichero); /* texto, numérico o binario (autodetecta)      */
void leer_funcion_de_texto(const char *texto);    /* analiza un texto en formato de texto         */
void escribir_funcion_en_fichero(const char *nombre_fichero, const double *punto);   /* .bin -> binario; si no, texto */
void liberar_funcion(void);

/* Utilidades */
entero64  buscar_monomio_del_factor(entero64 factor);        /* búsqueda binaria en inicio_del_monomio                  */
void nombre_de_variable(entero64 variable, char *texto, size_t tamano_texto);
void imprimir_termino(FILE *salida, double coeficiente, int num_factores_monomio, const int *variables,
                           const unsigned char *exponentes, int es_el_primero);
void imprimir_funcion(FILE *salida, entero64 funcion);

#endif
