/* =====================================================================================
 *  experimentos.h — Medición de tiempos, escalabilidad, paralelismo anidado y
 *                   comprobación de resultados
 *
 *  (Cocina: los CONCURSOS DE COCINA: el cronómetro, cuántas veces más rápido van N
 *  cocineros, cuántos kilos por segundo trae el pinche del almacén, y el catador que
 *  prueba con una pizca más y una pizca menos.)
 * ===================================================================================== */
#ifndef EXPERIMENTOS_H
#define EXPERIMENTOS_H

#include "evaluacion.h"

double medir_tiempo(tipo_funcion_jacobiano estrategia, int hilos, int repeticiones, const double *punto, double *jacobiano);
double error_relativo_maximo(const double *calculado, const double *referencia, entero64 cantidad);

/* Tabla con todas las estrategias. Devuelve el tiempo secuencial. */
double comparar_estrategias(int hilos, int repeticiones, const double *punto, const double *jacobiano_referencia, double *jacobiano_temporal);

/* Tiempos con 1, 2, 4, ..., max_hilos hilos */
void escalabilidad_fuerte(int max_hilos, int repeticiones, double tiempo_secuencial, const double *punto, double *jacobiano_temporal);

/* Estudio de paralelismo anidado:
 *   A) variables (T1) × monomios de cada derivada (T2)
 *   B) puntos (T1) × variables (T2), con un lote de 'puntos' puntos              */
void estudio_anidado(int hilos, int repeticiones, double tiempo_secuencial, const double *punto, double *jacobiano_temporal,
                     int puntos, unsigned long long semilla);

extern double ancho_banda_pico_gbs;
extern double mejor_tiempo_paralelo;               /* mejor tiempo paralelo de la tabla principal */
extern const char *mejor_estrategia_paralela;
double medir_ancho_banda_pico(int hilos);                     /* GB/s con STREAM triad       */
void estudio_lotes(int hilos, int repeticiones, int puntos, unsigned long long semilla);
void estudio_tamano_bloque(int hilos, int repeticiones, const double *punto, double *jacobiano_temporal);

/* Comprobación independiente con diferencias finitas centrales */
void comprobar_diferencias_finitas(double *punto, const double *jacobiano_referencia, int cuantas);

#endif
