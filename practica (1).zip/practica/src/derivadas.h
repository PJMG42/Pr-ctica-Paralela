/* =====================================================================================
 *  derivadas.h — PASO 1 (derivadas parciales simbólicas) y PASO 2 (gradiente / Jacobiano)
 *
 *  A partir de la función (o sistema) se construyen EXPLÍCITAMENTE los polinomios
 *  derivados, como en el ejemplo del enunciado:
 *
 *      f = 3xy + 4yz + 2x + 5
 *      ∂f/∂x = 3y + 2        ∂f/∂y = 3x + 4z        ∂f/∂z = 4y
 *
 *  Regla aplicada a cada casilla (monomio t, variable v, exponente e):
 *      ∂/∂v ( c · v^e · resto ) = (c·e) · v^(e-1) · resto
 *  Cada casilla produce UN monomio derivado. Las casillas de la misma variable v y de la
 *  misma función f forman el polinomio ∂f/∂v: una ENTRADA del Jacobiano.
 *
 *  Organización (por columnas = por variables, formato CSC):
 *
 *    inicio_entradas_de_variable    [N+1]    entradas de la variable i: desde [i] hasta [i+1]-1
 *    funcion_de_la_entrada          [NZJ]    función (fila) de cada entrada
 *    inicio_derivados_de_entrada    [NZJ+1]  monomios derivados de cada entrada
 *    coeficiente_del_derivado       [DM]     coeficiente de cada monomio derivado (c·e)
 *    inicio_del_derivado            [DM+1]   casillas de cada monomio derivado
 *    variable_del_factor_derivado   [DNNZ]   variables de los monomios derivados
 *    exponente_del_factor_derivado  [DNNZ]   exponentes de los monomios derivados
 *
 *  Abreviaturas de los tamaños: NZJ = nº de entradas no nulas del Jacobiano,
 *  DM = nº de monomios derivados, DNNZ = nº de casillas de los monomios derivados.
 *
 *  Para una sola función (E = 1), la entrada de la columna i ES ∂f/∂x_i, y una variable
 *  que no aparece en f no tiene entrada (su derivada es 0).
 *
 *  (Cocina: escribir las FICHAS (PASO 1) y colgarlas en el TABLÓN (PASO 2). La ficha
 *  del tomate dice cuánto cambia el plato por cada poquito de tomate extra. Cada
 *  aparición de un ingrediente en una línea produce exactamente una línea en su ficha.
 *  Una entrada es una casilla 'plato × ingrediente' de la tabla del menú (el
 *  Jacobiano).)
 * ===================================================================================== */
#ifndef DERIVADAS_H
#define DERIVADAS_H

#include "comun.h"

extern entero64      num_entradas_jacobiano;         /* nº de entradas no nulas del Jacobiano */
extern tipo_indice   *inicio_entradas_de_variable;   /* [N+1] */
extern int           *funcion_de_la_entrada;         /* [NZJ] */
extern tipo_indice   *inicio_derivados_de_entrada;   /* [NZJ+1] */
extern tipo_indice   *factor_de_origen;              /* [DM]  casilla original de cada mon. derivado */
extern tipo_indice   *monomio_del_factor;            /* [NNZ] monomio original de cada casilla */
extern tipo_indice   *entrada_del_factor;            /* [NNZ] entrada del Jacobiano de cada casilla */

extern int           derivadas_construidas;          /* 1 si se han construido los monomios derivados */
extern entero64      num_monomios_derivados;         /* nº de monomios derivados (= NNZ) */
extern entero64      num_factores_derivados;         /* nº de casillas de los monomios derivados */
extern double        *coeficiente_del_derivado;      /* [DM] */
extern tipo_indice   *inicio_del_derivado;           /* [DM+1] */
extern int           *variable_del_factor_derivado;  /* [DNNZ] */
extern unsigned char *exponente_del_factor_derivado; /* [DNNZ] */

/* PASO 1: construye el índice del Jacobiano y, si materializar = 1, los polinomios
 * derivados explícitos. Devuelve los segundos empleados en cada parte.              */
void derivar_simbolicamente(int materializar, double *tiempo_indice, double *tiempo_simbolico);

/* PASO 1 y PASO 2 impresos como en el enunciado (solo para funciones pequeñas) */
void imprimir_paso1(void);
void imprimir_paso2(void);

/* Transpuesta: casillas agrupadas por variable (inicio_por_variable[N+1], factores_agrupados[NNZ]), en paralelo.
 * Dentro de cada variable, en orden creciente de casilla. La usa también reordenar.c */
void agrupar_factores_por_variable(tipo_indice *inicio_por_variable, tipo_indice *factores_agrupados);

/* Busca la entrada (f, i); -1 si la derivada es 0 */
entero64  buscar_entrada_jacobiano(entero64 funcion, entero64 variable);

double memoria_derivadas(void);
void   liberar_derivadas(void);

#endif
