/* =====================================================================================
 *  generacion.c — GENERACIÓN ALEATORIA DE FUNCIONES Y SISTEMAS, EN PARALELO
 *  La usan el programa principal (sin -f) y el programa externo ./generador.
 *
 *  (Cocina: el INVENTOR DE RECETAS: crea recetas enormes al azar, con muchos cocineros
 *  a la vez y siempre iguales para la misma semilla (el mismo dado).)
 * ===================================================================================== */
#include "polinomio.h"

/* =====================================================================================
 *  4. GENERACIÓN ALEATORIA EN PARALELO (3 pasadas)
 *     E funciones, cada una con m_por_funcion monomios de 1..kmax variables distintas.
 *
 *     ventana = 0 : variables elegidas al azar entre todas (sin estructura)
 *     ventana = w : cada monomio usa variables CERCANAS entre sí: todas dentro de un
 *                   intervalo [b, b+w) con b al azar. Imita problemas reales con
 *                   estructura local (mallas, vecinos, bandas), que es donde reordenar
 *                   puede ayudar. Los monomios salen en orden aleatorio de b.
 *     desordenar  : aplica una permutación aleatoria a los números de variable. La
 *                   estructura sigue ahí, pero "escondida": simula una entrada real mal
 *                   numerada, que es el caso que la reordenación debe arreglar.
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  generar_funcion_aleatoria()
 *
 *  Crea una función (o sistema) aleatoria GRANDE directamente en los arrays globales,
 *  en paralelo, en 3 pasadas: (1) cada monomio decide cuántas variables tendrá; (2) una
 *  suma prefija calcula dónde empieza cada monomio (inicio_del_monomio); (3) cada
 *  monomio rellena su coeficiente, variables (distintas entre sí) y exponentes.
 *
 *  Cada monomio usa su propia semilla (semilla_del_elemento), por eso la pasada 3 puede
 *  repetir exactamente los números de la pasada 1 y el resultado no depende del número
 *  de hilos. La permutación para 'desordenar' (Fisher-Yates) es secuencial: es corta
 *  (N).
 *
 *  (Cocina: el inventor de recetas. Primero decide cuántos ingredientes tendrá cada
 *  línea, luego numera las páginas del libro y, por último, cada cocinero escribe a la
 *  vez sus líneas en el sitio que ya les toca.)
 * ------------------------------------------------------------------------------------- */
void generar_funcion_aleatoria(entero64 total_funciones, entero64 total_variables, entero64 monomios_por_funcion, int max_variables_por_monomio, int max_exponente,
                  unsigned long long semilla, entero64 ventana, int desordenar) {
    num_funciones = total_funciones; num_variables = total_variables; num_monomios = total_funciones * monomios_por_funcion;
    nombres_de_variables = NULL; nombres_de_una_letra = 0; punto_del_fichero = NULL; numero_original_de_variable = NULL;
    if (ventana > total_variables) ventana = total_variables;
    entero64 rango_de_variables = ventana > 0 ? ventana : total_variables;              /* de dónde se eligen las vars */
    if (max_variables_por_monomio > rango_de_variables) max_variables_por_monomio = (int)rango_de_variables;
    if (max_variables_por_monomio > MAX_VARIABLES_POR_MONOMIO) max_variables_por_monomio = MAX_VARIABLES_POR_MONOMIO;
    if (max_variables_por_monomio < 1) max_variables_por_monomio = 1;
    comprobar_cabe_en_indice(num_monomios, "monomios");

    entero64 total_monomios = num_monomios;
    inicio_de_funcion      = reservar(sizeof(entero64) * (total_funciones + 1), "inicio_de_funcion");
    funcion_del_monomio = reservar(sizeof(int) * total_monomios, "funcion_del_monomio");
    coeficiente_del_monomio           = reservar(sizeof(double) * total_monomios, "coeficiente_del_monomio");
    inicio_del_monomio          = reservar(sizeof(tipo_indice) * (total_monomios + 1), "inicio_del_monomio");
    for (entero64 funcion = 0; funcion <= total_funciones; funcion++) inicio_de_funcion[funcion] = funcion * monomios_por_funcion;

    /* Pasada 1: cuántas variables tendrá cada monomio */
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 monomio = 0; monomio < total_monomios; monomio++) {
        unsigned long long estado_aleatorio = semilla_del_elemento(semilla, monomio);
        inicio_del_monomio[monomio] = (tipo_indice)(1 + siguiente_aleatorio(&estado_aleatorio) % (unsigned long long)max_variables_por_monomio);
        funcion_del_monomio[monomio] = (int)(monomio / monomios_por_funcion);
    }

    /* Pasada 2: suma prefija -> dónde empieza cada monomio */
    num_factores = suma_prefija_indices(inicio_del_monomio, total_monomios, "casillas (start)");
    inicio_del_monomio[total_monomios] = (tipo_indice)num_factores;
    variable_del_factor  = reservar(sizeof(int) * (num_factores > 0 ? num_factores : 1), "variable_del_factor");
    exponente_del_factor = reservar(num_factores > 0 ? num_factores : 1, "exponente_del_factor");

    /* Permutación de variables (si se pide desordenar): Fisher-Yates, secuencial */
    int *permutacion = NULL;
    if (desordenar) {
        permutacion = reservar(sizeof(int) * total_variables, "permutacion");
        for (entero64 posicion = 0; posicion < total_variables; posicion++) permutacion[posicion] = (int)posicion;
        unsigned long long estado_aleatorio = semilla ^ 0x5EED5EEDULL;
        for (entero64 posicion = total_variables - 1; posicion > 0; posicion--) {
            entero64 otra_posicion = (entero64)(siguiente_aleatorio(&estado_aleatorio) % (unsigned long long)(posicion + 1));
            int temporal = permutacion[posicion]; permutacion[posicion] = permutacion[otra_posicion]; permutacion[otra_posicion] = temporal;
        }
    }

    /* Pasada 3: rellenar (cada monomio regenera su secuencia aleatoria) */
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 monomio = 0; monomio < total_monomios; monomio++) {
        unsigned long long estado_aleatorio = semilla_del_elemento(semilla, monomio);
        int num_factores_monomio = 1 + (int)(siguiente_aleatorio(&estado_aleatorio) % (unsigned long long)max_variables_por_monomio);
        coeficiente_del_monomio[monomio] = 2.0 * aleatorio_entre_0_y_1(&estado_aleatorio) - 1.0;                  /* coeficiente en [-1,1) */
        entero64 primera_variable_posible = (ventana > 0) ? (entero64)(siguiente_aleatorio(&estado_aleatorio) % (unsigned long long)(total_variables - ventana + 1)) : 0;
        entero64 primer_factor = inicio_del_monomio[monomio];
        for (int posicion_en_monomio = 0; posicion_en_monomio < num_factores_monomio; posicion_en_monomio++) {
            int variable, esta_repetida;
            do {
                variable = (int)(primera_variable_posible + (entero64)(siguiente_aleatorio(&estado_aleatorio) % (unsigned long long)rango_de_variables));
                esta_repetida = 0;
                for (int anterior = 0; anterior < posicion_en_monomio; anterior++) if (variable_del_factor[primer_factor + anterior] == variable) { esta_repetida = 1; break; }
            } while (esta_repetida);
            variable_del_factor[primer_factor + posicion_en_monomio]  = variable;
            exponente_del_factor[primer_factor + posicion_en_monomio] = (unsigned char)(1 + siguiente_aleatorio(&estado_aleatorio) % (unsigned long long)max_exponente);
        }
        if (permutacion)
            for (int posicion_en_monomio = 0; posicion_en_monomio < num_factores_monomio; posicion_en_monomio++) variable_del_factor[primer_factor + posicion_en_monomio] = permutacion[variable_del_factor[primer_factor + posicion_en_monomio]];
    }
    free(permutacion);
}

