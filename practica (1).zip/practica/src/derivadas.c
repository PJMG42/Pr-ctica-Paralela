/* =====================================================================================
 *  derivadas.c — PASO 1 y PASO 2: derivación simbólica, en paralelo
 *
 *  Etapas de derivar_simbolicamente():
 *    1. Transpuesta: agrupar las casillas por variable (ordenación por recuento paralela)
 *    2. Índice del Jacobiano: dentro de cada variable, agrupar por función -> entradas
 *    3. (opcional) Materializar los monomios derivados: (c·e) · v^(e-1) · resto
 *
 *  (Cocina: escribir las fichas entre muchos cocineros (ver derivadas.h).)
 * ===================================================================================== */
#include "derivadas.h"
#include "polinomio.h"

entero64      num_entradas_jacobiano = 0;
tipo_indice   *inicio_entradas_de_variable = NULL;
int           *funcion_de_la_entrada = NULL;
tipo_indice   *inicio_derivados_de_entrada = NULL;
tipo_indice   *factor_de_origen = NULL;
tipo_indice   *monomio_del_factor = NULL;
tipo_indice   *entrada_del_factor = NULL;
int           derivadas_construidas = 0;
entero64      num_monomios_derivados = 0, num_factores_derivados = 0;
double        *coeficiente_del_derivado = NULL;
tipo_indice   *inicio_del_derivado = NULL;
int           *variable_del_factor_derivado = NULL;
unsigned char *exponente_del_factor_derivado = NULL;

/* =====================================================================================
 *  1. TRANSPUESTA EN PARALELO: "variable -> casillas donde aparece"
 *
 *  Ordenación por recuento con histogramas por hilo (determinista, sin atomics):
 *    (1) cada hilo cuenta las variables de SU bloque de casillas en SU histograma
 *    (2) para cada variable: hueco de cada hilo dentro de la lista + suma prefija
 *    (3) cada hilo coloca SUS casillas en su hueco
 *  Como el hilo 0 tiene las casillas más bajas, luego el 1, etc., cada lista queda en
 *  orden creciente de casilla -> agrupada por función (las funciones son consecutivas).
 *  Si los histogramas (hilos × N) no caben, se usa una versión con atomics + qsort.
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  comparar_indices()
 *
 *  Comparación para qsort de dos tipo_indice (de menor a mayor).
 *
 *  (Cocina: ordenar números de página.)
 * ------------------------------------------------------------------------------------- */
static int comparar_indices(const void *primero, const void *segundo) {
    tipo_indice valor_primero = *(const tipo_indice *)primero, valor_segundo = *(const tipo_indice *)segundo;
    return (valor_primero > valor_segundo) - (valor_primero < valor_segundo);
}

/* -------------------------------------------------------------------------------------
 *  agrupar_con_histogramas()
 *
 *  Transpuesta en paralelo SIN atomics: (1) cada hilo cuenta en SU histograma cuántas
 *  veces sale cada variable en SU bloque de factores; (2) para cada variable se calcula
 *  el hueco de cada hilo dentro de su lista y, con una suma prefija, dónde empieza la
 *  lista de cada variable (inicio_por_variable); (3) cada hilo coloca sus factores en
 *  su hueco. Es determinista: cada lista queda en orden creciente de factor (y por
 *  tanto agrupada por función). Necesita hilos × N contadores.
 *
 *  (Cocina: hacer el índice por ingrediente ('¿en qué líneas sale el tomate?'). Cada
 *  cocinero cuenta en su libreta los ingredientes de su montón de recetas; luego se
 *  decide qué renglones de la lista del tomate le tocan a cada uno, y cada uno escribe
 *  los suyos sin pisar a nadie.)
 * ------------------------------------------------------------------------------------- */
static void agrupar_con_histogramas(entero64 total_variables, entero64 total_factores, const int *variable_de, tipo_indice *inicio_por_variable, tipo_indice *factores_agrupados) {
    int max_hilos = omp_get_max_threads();
    tipo_indice *contadores = reservar_cero((size_t)max_hilos * total_variables, sizeof(tipo_indice), "contadores");
    int hilos_usados = 1;

    /* OpenMP: se abre un equipo de hilos y TODOS ejecutan el bloque. (Cocina: ¡todos a cocinar!) */
    #pragma omp parallel
    {
        int total_hilos  = omp_get_num_threads();
        int mi_hilo = omp_get_thread_num();
        entero64 primer_factor = total_factores * mi_hilo / total_hilos, fin_factores = total_factores * (mi_hilo + 1) / total_hilos;
        tipo_indice *mis_contadores = contadores + (entero64)mi_hilo * total_variables;

        /* OpenMP: lo ejecuta UN solo hilo; los demás le esperan al final. (Cocina: esto lo hace
         * uno solo mientras los demás esperan.) */
        #pragma omp single
        hilos_usados = total_hilos;

        for (entero64 factor = primer_factor; factor < fin_factores; factor++) mis_contadores[variable_de[factor]]++;               /* (1) */
        /* OpenMP: barrera: nadie sigue hasta que lleguen todos los hilos. (Cocina: nadie emplata
         * hasta que todos hayan terminado.) */
        #pragma omp barrier

        /* OpenMP: los hilos del equipo se reparten este bucle; al acabar se esperan (barrera
         * implícita); reparto fijo a partes iguales. (Cocina: reparto de comandas entre los que ya
         * están cocinando; a cada uno el mismo número de comandas, decidido antes de empezar.) */
        #pragma omp for schedule(static)                           /* (2) */
        for (entero64 variable = 0; variable < total_variables; variable++) {
            tipo_indice acumulado = 0;
            for (int hilo = 0; hilo < total_hilos; hilo++) {
                tipo_indice cuenta = contadores[(entero64)hilo * total_variables + variable];
                contadores[(entero64)hilo * total_variables + variable] = acumulado;
                acumulado += cuenta;
            }
            inicio_por_variable[variable] = acumulado;
        }
    }
    inicio_por_variable[total_variables] = (tipo_indice)suma_prefija_indices(inicio_por_variable, total_variables, "transpuesta");

    (void)hilos_usados;                                /* sin OpenMP no se usa */
    /* OpenMP: se abre un equipo de hilos y TODOS ejecutan el bloque; con hilos_usados hilos.
     * (Cocina: ¡todos a cocinar!; solo trabajan hilos_usados cocineros.) */
    #pragma omp parallel num_threads(hilos_usados)                     /* (3) */
    {
        int total_hilos  = omp_get_num_threads();
        int mi_hilo = omp_get_thread_num();
        entero64 primer_factor = total_factores * mi_hilo / total_hilos, fin_factores = total_factores * (mi_hilo + 1) / total_hilos;
        tipo_indice *mis_contadores = contadores + (entero64)mi_hilo * total_variables;
        for (entero64 factor = primer_factor; factor < fin_factores; factor++) {
            int variable = variable_de[factor];
            factores_agrupados[inicio_por_variable[variable] + mis_contadores[variable]++] = (tipo_indice)factor;
        }
    }
    free(contadores);
}

/* -------------------------------------------------------------------------------------
 *  agrupar_con_atomicas()
 *
 *  Versión de reserva de la transpuesta, para cuando los histogramas por hilo no caben
 *  en memoria: cuenta con atomic, reserva el hueco con atomic capture y al final ordena
 *  cada lista con qsort para recuperar el orden.
 *
 *  (Cocina: una sola libreta compartida en la que todos apuntan haciendo turno; más
 *  lenta, pero ocupa menos.)
 * ------------------------------------------------------------------------------------- */
static void agrupar_con_atomicas(entero64 total_variables, entero64 total_factores, const int *variable_de, tipo_indice *inicio_por_variable, tipo_indice *factores_agrupados) {
    memset(inicio_por_variable, 0, sizeof(tipo_indice) * (total_variables + 1));
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 factor = 0; factor < total_factores; factor++) {
        /* OpenMP: suma protegida: un solo hilo cada vez sobre ese dato. (Cocina: turno en la olla
         * para no perder ninguna suma.) */
        #pragma omp atomic
        inicio_por_variable[variable_de[factor]]++;
    }
    inicio_por_variable[total_variables] = (tipo_indice)suma_prefija_indices(inicio_por_variable, total_variables, "transpuesta");
    tipo_indice *siguiente_hueco = reservar(sizeof(tipo_indice) * (total_variables > 0 ? total_variables : 1), "siguiente_hueco");
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 variable = 0; variable < total_variables; variable++) siguiente_hueco[variable] = inicio_por_variable[variable];
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 factor = 0; factor < total_factores; factor++) {
        tipo_indice hueco;
        /* OpenMP: lee y aumenta el contador en un solo paso protegido. (Cocina: coger número de
         * turno en la cola.) */
        #pragma omp atomic capture
        hueco = siguiente_hueco[variable_de[factor]]++;
        factores_agrupados[hueco] = (tipo_indice)factor;
    }
    /* OpenMP: bucle repartido entre los hilos; reparto dinámico de 256 en 256. (Cocina: los
     * cocineros se reparten estas comandas; quien acaba coge 256 comandas más del gancho.) */
    #pragma omp parallel for schedule(dynamic, 256)               /* restaurar el orden */
    for (entero64 variable = 0; variable < total_variables; variable++) {
        entero64 longitud = inicio_por_variable[variable + 1] - inicio_por_variable[variable];
        if (longitud > 1) qsort(factores_agrupados + inicio_por_variable[variable], (size_t)longitud, sizeof(tipo_indice), comparar_indices);
    }
    free(siguiente_hueco);
}

/* -------------------------------------------------------------------------------------
 *  agrupar_factores_por_variable()
 *
 *  Elige la versión de la transpuesta: con histogramas si caben (hilos × N contadores
 *  <= LIMITE_MEMORIA) y con atomics si no. Resultado: factores_agrupados[] tiene los
 *  factores de la variable v en las posiciones inicio_por_variable[v] ..
 *  inicio_por_variable[v+1]-1.
 *
 *  (Cocina: decidir si cada cocinero usa su propia libreta o comparten una.)
 * ------------------------------------------------------------------------------------- */
void agrupar_factores_por_variable(tipo_indice *inicio_por_variable, tipo_indice *factores_agrupados) {
    if ((double)omp_get_max_threads() * num_variables * sizeof(tipo_indice) <= LIMITE_MEMORIA)
        agrupar_con_histogramas(num_variables, num_factores, variable_del_factor, inicio_por_variable, factores_agrupados);
    else
        agrupar_con_atomicas(num_variables, num_factores, variable_del_factor, inicio_por_variable, factores_agrupados);
}

/* =====================================================================================
 *  2 + 3. PASO 1 COMPLETO
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  derivar_simbolicamente()
 *
 *  PASO 1 completo (y la estructura del PASO 2). Etapas: (1) transpuesta: factores
 *  agrupados por variable; (2) monomio de cada factor; (3) índice del Jacobiano: dentro
 *  de cada variable, una ENTRADA por cada función distinta (contar, suma prefija y
 *  rellenar); (4) si materializar = 1, construye EXPLÍCITAMENTE los monomios derivados
 *  con la regla ∂/∂v (c·v^e·resto) = (c·e)·v^(e-1)·resto: cada factor produce
 *  exactamente un monomio derivado (si e = 1 la variable desaparece). Todo en paralelo;
 *  los tamaños se conocen antes de escribir gracias a las sumas prefijas, así cada hilo
 *  escribe en su sitio.
 *
 *  (Cocina: escribir las fichas de todos los ingredientes. Primero el índice por
 *  ingrediente, luego qué platos usan cada ingrediente (las casillas del menú) y, por
 *  último, cada cocinero copia sus líneas derivadas en la ficha que les toca.)
 * ------------------------------------------------------------------------------------- */
void derivar_simbolicamente(int materializar, double *tiempo_indice, double *tiempo_simbolico) {
    entero64 total_variables = num_variables, total_monomios = num_monomios, total_factores = num_factores;
    double inicio_reloj = omp_get_wtime();

    /* --- 1. Transpuesta --- */
    tipo_indice *inicio_por_variable = reservar(sizeof(tipo_indice) * (total_variables + 1), "inicio_por_variable");
    factor_de_origen = reservar(sizeof(tipo_indice) * (total_factores > 0 ? total_factores : 1), "factor_de_origen");
    agrupar_factores_por_variable(inicio_por_variable, factor_de_origen);

    /* --- monomio de cada casilla (lo necesitan el paso 1 y las comprobaciones) --- */
    monomio_del_factor = reservar(sizeof(tipo_indice) * (total_factores > 0 ? total_factores : 1), "monomio_del_factor");
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 monomio = 0; monomio < total_monomios; monomio++)
        for (entero64 factor = inicio_del_monomio[monomio]; factor < inicio_del_monomio[monomio + 1]; factor++) monomio_del_factor[factor] = (tipo_indice)monomio;

    /* --- 2. Índice del Jacobiano: en cada columna, una entrada por función distinta --- */
    inicio_entradas_de_variable = reservar(sizeof(tipo_indice) * (total_variables + 1), "inicio_entradas_de_variable");
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 variable = 0; variable < total_variables; variable++) {
        entero64 cuenta = 0; int funcion_anterior = -1;
        for (entero64 derivado = inicio_por_variable[variable]; derivado < inicio_por_variable[variable + 1]; derivado++) {
            int funcion = funcion_del_monomio[monomio_del_factor[factor_de_origen[derivado]]];
            if (funcion != funcion_anterior) { cuenta++; funcion_anterior = funcion; }
        }
        inicio_entradas_de_variable[variable] = (tipo_indice)cuenta;
    }
    num_entradas_jacobiano = suma_prefija_indices(inicio_entradas_de_variable, total_variables, "entradas del Jacobiano");
    inicio_entradas_de_variable[total_variables] = (tipo_indice)num_entradas_jacobiano;

    funcion_de_la_entrada      = reservar(sizeof(int) * (num_entradas_jacobiano > 0 ? num_entradas_jacobiano : 1), "funcion_de_la_entrada");
    inicio_derivados_de_entrada = reservar(sizeof(tipo_indice) * (num_entradas_jacobiano + 1), "inicio_derivados_de_entrada");
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 variable = 0; variable < total_variables; variable++) {
        entero64 entrada = inicio_entradas_de_variable[variable]; int funcion_anterior = -1;
        for (entero64 derivado = inicio_por_variable[variable]; derivado < inicio_por_variable[variable + 1]; derivado++) {
            int funcion = funcion_del_monomio[monomio_del_factor[factor_de_origen[derivado]]];
            if (funcion != funcion_anterior) { funcion_de_la_entrada[entrada] = funcion; inicio_derivados_de_entrada[entrada] = (tipo_indice)derivado; entrada++; funcion_anterior = funcion; }
        }
    }
    inicio_derivados_de_entrada[num_entradas_jacobiano] = (tipo_indice)total_factores;
    free(inicio_por_variable);

    entrada_del_factor = reservar(sizeof(tipo_indice) * (total_factores > 0 ? total_factores : 1), "entrada_del_factor");
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 entrada = 0; entrada < num_entradas_jacobiano; entrada++)
        for (entero64 derivado = inicio_derivados_de_entrada[entrada]; derivado < inicio_derivados_de_entrada[entrada + 1]; derivado++) entrada_del_factor[factor_de_origen[derivado]] = (tipo_indice)entrada;

    *tiempo_indice = omp_get_wtime() - inicio_reloj;

    /* --- 3. Monomios derivados explícitos --- */
    derivadas_construidas = materializar;
    num_monomios_derivados = total_factores;
    *tiempo_simbolico = 0.0;
    if (!materializar) return;
    inicio_reloj = omp_get_wtime();

    /* 3a. Tamaño de cada monomio derivado: si e <= 1 la variable desaparece */
    inicio_del_derivado = reservar(sizeof(tipo_indice) * (num_monomios_derivados + 1), "inicio_del_derivado");
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 derivado = 0; derivado < num_monomios_derivados; derivado++) {
        entero64 factor = factor_de_origen[derivado], monomio = monomio_del_factor[factor];
        entero64 num_factores_monomio = inicio_del_monomio[monomio + 1] - inicio_del_monomio[monomio];
        inicio_del_derivado[derivado] = (tipo_indice)((exponente_del_factor[factor] <= 1) ? num_factores_monomio - 1 : num_factores_monomio);
    }
    num_factores_derivados = suma_prefija_indices(inicio_del_derivado, num_monomios_derivados, "casillas de los monomios derivados");
    inicio_del_derivado[num_monomios_derivados] = (tipo_indice)num_factores_derivados;

    /* 3b. Rellenar: (c·e) · v^(e-1) · resto */
    coeficiente_del_derivado = reservar(sizeof(double) * (num_monomios_derivados > 0 ? num_monomios_derivados : 1), "coeficiente_del_derivado");
    variable_del_factor_derivado  = reservar(sizeof(int) * (num_factores_derivados > 0 ? num_factores_derivados : 1), "variable_del_factor_derivado");
    exponente_del_factor_derivado = reservar(num_factores_derivados > 0 ? num_factores_derivados : 1, "exponente_del_factor_derivado");
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 derivado = 0; derivado < num_monomios_derivados; derivado++) {
        entero64 factor = factor_de_origen[derivado], monomio = monomio_del_factor[factor];
        int exponente = exponente_del_factor[factor];
        coeficiente_del_derivado[derivado] = coeficiente_del_monomio[monomio] * exponente;
        entero64 destino = inicio_del_derivado[derivado];
        for (entero64 otro_factor = inicio_del_monomio[monomio]; otro_factor < inicio_del_monomio[monomio + 1]; otro_factor++) {
            if (otro_factor == factor) {
                if (exponente > 1) { variable_del_factor_derivado[destino] = variable_del_factor[otro_factor]; exponente_del_factor_derivado[destino] = (unsigned char)(exponente - 1); destino++; }
            } else {
                variable_del_factor_derivado[destino] = variable_del_factor[otro_factor]; exponente_del_factor_derivado[destino] = exponente_del_factor[otro_factor]; destino++;
            }
        }
    }
    *tiempo_simbolico = omp_get_wtime() - inicio_reloj;
}

/* -------------------------------------------------------------------------------------
 *  buscar_entrada_jacobiano()
 *
 *  Busca la entrada (función, variable) del Jacobiano; devuelve -1 si esa derivada es 0
 *  (la variable no aparece en esa función).
 *
 *  (Cocina: buscar la casilla 'plato f, ingrediente v' en la tabla del menú.)
 * ------------------------------------------------------------------------------------- */
entero64 buscar_entrada_jacobiano(entero64 funcion, entero64 variable) {
    for (entero64 entrada = inicio_entradas_de_variable[variable]; entrada < inicio_entradas_de_variable[variable + 1]; entrada++)
        if (funcion_de_la_entrada[entrada] == funcion) return entrada;
    return -1;
}

/* -------------------------------------------------------------------------------------
 *  memoria_derivadas()
 *
 *  Calcula los bytes que ocupan las estructuras del PASO 1 (para el informe de
 *  memoria).
 *
 *  (Cocina: cuánto papel ocupan las fichas.)
 * ------------------------------------------------------------------------------------- */
double memoria_derivadas(void) {
    double bytes_indice = sizeof(tipo_indice);
    double bytes = (double)(num_variables + 1) * bytes_indice + (double)num_entradas_jacobiano * (4 + bytes_indice) + (double)num_factores * 3 * bytes_indice;
    if (derivadas_construidas) bytes += (double)num_monomios_derivados * (8 + bytes_indice) + (double)num_factores_derivados * 5;
    return bytes;
}

/* -------------------------------------------------------------------------------------
 *  liberar_derivadas()
 *
 *  Libera todo lo creado en el PASO 1.
 *
 *  (Cocina: tirar las fichas cuando ya no hacen falta.)
 * ------------------------------------------------------------------------------------- */
void liberar_derivadas(void) {
    free(inicio_entradas_de_variable); free(funcion_de_la_entrada); free(inicio_derivados_de_entrada); free(factor_de_origen);
    free(monomio_del_factor); free(entrada_del_factor);
    free(coeficiente_del_derivado); free(inicio_del_derivado); free(variable_del_factor_derivado); free(exponente_del_factor_derivado);
    inicio_entradas_de_variable = NULL; funcion_de_la_entrada = NULL; inicio_derivados_de_entrada = NULL; factor_de_origen = NULL;
    monomio_del_factor = NULL; entrada_del_factor = NULL;
    coeficiente_del_derivado = NULL; inicio_del_derivado = NULL; variable_del_factor_derivado = NULL; exponente_del_factor_derivado = NULL;
    num_entradas_jacobiano = num_monomios_derivados = num_factores_derivados = 0; derivadas_construidas = 0;
}

/* =====================================================================================
 *  4. IMPRESIÓN DE LOS PASOS 1 Y 2 (solo para funciones pequeñas)
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  nombre_de_funcion()
 *
 *  Nombre para mostrar de la función: 'f' si solo hay una, 'f1', 'f2'... si es un
 *  sistema.
 *
 *  (Cocina: el nombre del plato.)
 * ------------------------------------------------------------------------------------- */
static void nombre_de_funcion(entero64 funcion, char *texto, size_t tamano_texto) {
    if (num_funciones == 1) snprintf(texto, tamano_texto, "f");
    else          snprintf(texto, tamano_texto, "f%lld", funcion + 1);
}

/* -------------------------------------------------------------------------------------
 *  imprimir_derivada_monomio()
 *
 *  Imprime la derivada de UN monomio original respecto a una variable (o '0' si no la
 *  contiene). Se usa en el PASO 1 para enseñar el desarrollo término a término.
 *
 *  (Cocina: escribir cómo cambia UNA línea de la receta con un ingrediente.)
 * ------------------------------------------------------------------------------------- */
static void imprimir_derivada_monomio(entero64 monomio, entero64 variable, int es_el_primero) {
    int variables[MAX_VARIABLES_POR_MONOMIO]; unsigned char exponentes[MAX_VARIABLES_POR_MONOMIO]; int num_factores_derivado = 0, exponente = 0;
    for (entero64 factor = inicio_del_monomio[monomio]; factor < inicio_del_monomio[monomio + 1]; factor++) {
        if (variable_del_factor[factor] == variable) { exponente = exponente_del_factor[factor]; if (exponente > 1) { variables[num_factores_derivado] = (int)variable; exponentes[num_factores_derivado++] = (unsigned char)(exponente - 1); } }
        else               { variables[num_factores_derivado] = variable_del_factor[factor]; exponentes[num_factores_derivado++] = exponente_del_factor[factor]; }
    }
    if (exponente == 0) { fputs(es_el_primero ? "0" : " + 0", stdout); return; }
    imprimir_termino(stdout, coeficiente_del_monomio[monomio] * exponente, num_factores_derivado, variables, exponentes, es_el_primero);
}

/* -------------------------------------------------------------------------------------
 *  imprimir_entrada_simplificada()
 *
 *  Imprime el polinomio de una entrada (una derivada parcial) SIMPLIFICADO: ordena las
 *  variables de cada término y junta términos semejantes (2 + 2 -> 4). Solo para
 *  mostrar.
 *
 *  (Cocina: pasar la ficha a limpio juntando lo repetido.)
 * ------------------------------------------------------------------------------------- */
static void imprimir_entrada_simplificada(entero64 entrada) {
    if (entrada < 0) { fputs("0", stdout); return; }
    entero64 num_terminos = inicio_derivados_de_entrada[entrada + 1] - inicio_derivados_de_entrada[entrada];
    double *coeficientes = reservar(sizeof(double) * num_terminos, "coeficientes");
    int *num_factores_termino = reservar(sizeof(int) * num_terminos, "num_factores_termino");
    int *variables_termino = reservar(sizeof(int) * num_terminos * MAX_VARIABLES_POR_MONOMIO, "variables_termino");
    unsigned char *exponentes_termino = reservar(num_terminos * MAX_VARIABLES_POR_MONOMIO, "exponentes_termino");
    for (entero64 termino = 0; termino < num_terminos; termino++) {                          /* forma canónica: vars ordenadas */
        entero64 derivado = inicio_derivados_de_entrada[entrada] + termino;
        coeficientes[termino] = coeficiente_del_derivado[derivado];
        num_factores_termino[termino] = (int)(inicio_del_derivado[derivado + 1] - inicio_del_derivado[derivado]);
        for (int posicion = 0; posicion < num_factores_termino[termino]; posicion++) { variables_termino[termino * MAX_VARIABLES_POR_MONOMIO + posicion] = variable_del_factor_derivado[inicio_del_derivado[derivado] + posicion]; exponentes_termino[termino * MAX_VARIABLES_POR_MONOMIO + posicion] = exponente_del_factor_derivado[inicio_del_derivado[derivado] + posicion]; }
        for (int posicion = 1; posicion < num_factores_termino[termino]; posicion++)
            for (int hueco = posicion; hueco > 0 && variables_termino[termino * MAX_VARIABLES_POR_MONOMIO + hueco - 1] > variables_termino[termino * MAX_VARIABLES_POR_MONOMIO + hueco]; hueco--) {
                int variable_temporal = variables_termino[termino * MAX_VARIABLES_POR_MONOMIO + hueco]; variables_termino[termino * MAX_VARIABLES_POR_MONOMIO + hueco] = variables_termino[termino * MAX_VARIABLES_POR_MONOMIO + hueco - 1]; variables_termino[termino * MAX_VARIABLES_POR_MONOMIO + hueco - 1] = variable_temporal;
                unsigned char exponente_temporal = exponentes_termino[termino * MAX_VARIABLES_POR_MONOMIO + hueco]; exponentes_termino[termino * MAX_VARIABLES_POR_MONOMIO + hueco] = exponentes_termino[termino * MAX_VARIABLES_POR_MONOMIO + hueco - 1]; exponentes_termino[termino * MAX_VARIABLES_POR_MONOMIO + hueco - 1] = exponente_temporal;
            }
    }
    for (entero64 termino = 0; termino < num_terminos; termino++) {                          /* juntar semejantes */
        if (coeficientes[termino] == 0.0) continue;
        for (entero64 otro_termino = termino + 1; otro_termino < num_terminos; otro_termino++) {
            if (num_factores_termino[otro_termino] != num_factores_termino[termino]) continue;
            int son_iguales = 1;
            for (int posicion = 0; posicion < num_factores_termino[termino] && son_iguales; posicion++)
                if (variables_termino[termino * MAX_VARIABLES_POR_MONOMIO + posicion] != variables_termino[otro_termino * MAX_VARIABLES_POR_MONOMIO + posicion] || exponentes_termino[termino * MAX_VARIABLES_POR_MONOMIO + posicion] != exponentes_termino[otro_termino * MAX_VARIABLES_POR_MONOMIO + posicion]) son_iguales = 0;
            if (son_iguales) { coeficientes[termino] += coeficientes[otro_termino]; coeficientes[otro_termino] = 0.0; }
        }
    }
    int es_el_primero = 1;
    for (entero64 termino = 0; termino < num_terminos; termino++) {
        if (coeficientes[termino] == 0.0) continue;
        imprimir_termino(stdout, coeficientes[termino], num_factores_termino[termino], variables_termino + termino * MAX_VARIABLES_POR_MONOMIO, exponentes_termino + termino * MAX_VARIABLES_POR_MONOMIO, es_el_primero);
        es_el_primero = 0;
    }
    if (es_el_primero) fputs("0", stdout);
    free(coeficientes); free(num_factores_termino); free(variables_termino); free(exponentes_termino);
}

/* -------------------------------------------------------------------------------------
 *  imprimir_paso1()
 *
 *  Imprime el PASO 1 como en el enunciado: para cada función y variable, ∂f/∂x =
 *  ∂/∂x(...) = derivada término a término = resultado simplificado.
 *
 *  (Cocina: enseñar cómo se ha escrito cada ficha.)
 * ------------------------------------------------------------------------------------- */
void imprimir_paso1(void) {
    char nombre_funcion[32], nombre_variable[64];
    printf("\nPASO 1. Derivadas parciales\n");
    for (entero64 funcion = 0; funcion < num_funciones; funcion++) {
        nombre_de_funcion(funcion, nombre_funcion, sizeof nombre_funcion);
        if (num_funciones > 1) { printf("\n  %s = ", nombre_funcion); imprimir_funcion(stdout, funcion); printf("\n"); }
        for (entero64 variable = 0; variable < num_variables; variable++) {
            nombre_de_variable(variable, nombre_variable, sizeof nombre_variable);
            printf("\n  Respecto a %s:\n  ∂%s/∂%s = ∂/∂%s(", nombre_variable, nombre_funcion, nombre_variable, nombre_variable);
            imprimir_funcion(stdout, funcion);
            printf(") = ");
            for (entero64 monomio = inicio_de_funcion[funcion]; monomio < inicio_de_funcion[funcion + 1]; monomio++)
                imprimir_derivada_monomio(monomio, variable, monomio == inicio_de_funcion[funcion]);
            printf(" = ");
            imprimir_entrada_simplificada(buscar_entrada_jacobiano(funcion, variable));
            printf("\n");
        }
    }
}

/* -------------------------------------------------------------------------------------
 *  imprimir_paso2()
 *
 *  Imprime el PASO 2: el gradiente ∇f(...) = (...) o, para un sistema, el Jacobiano
 *  fila por fila.
 *
 *  (Cocina: el tablón con todas las fichas colgadas.)
 * ------------------------------------------------------------------------------------- */
void imprimir_paso2(void) {
    char nombre_variable[64], nombre_funcion[32];
    printf("\nPASO 2. Formulación del %s\n\n", num_funciones == 1 ? "gradiente" : "Jacobiano");
    printf("  %s(", num_funciones == 1 ? "∇f" : "J");
    for (entero64 variable = 0; variable < num_variables; variable++) { nombre_de_variable(variable, nombre_variable, sizeof nombre_variable); printf("%s%s", variable ? ", " : "", nombre_variable); }
    printf(") = ");
    if (num_funciones == 1) {
        printf("(");
        for (entero64 variable = 0; variable < num_variables; variable++) {
            if (variable) printf(", ");
            imprimir_entrada_simplificada(buscar_entrada_jacobiano(0, variable));
        }
        printf(")\n");
    } else {
        printf("\n");
        for (entero64 funcion = 0; funcion < num_funciones; funcion++) {
            nombre_de_funcion(funcion, nombre_funcion, sizeof nombre_funcion);
            printf("    %-4s [ ", nombre_funcion);
            for (entero64 variable = 0; variable < num_variables; variable++) {
                if (variable) printf(" ,  ");
                imprimir_entrada_simplificada(buscar_entrada_jacobiano(funcion, variable));
            }
            printf(" ]\n");
        }
    }
}
