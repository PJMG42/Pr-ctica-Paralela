/* =====================================================================================
 *  comun.c — Utilidades compartidas
 *
 *  (Cocina: los utensilios comunes (ver comun.h).)
 * ===================================================================================== */
#include "comun.h"

/* -------------------------------------------------------------------------------------
 *  reservar()
 *
 *  Pide 'bytes' de memoria con malloc. Si no hay memoria, avisa diciendo para qué era
 *  (para_que) y cuántos MB, y termina el programa. Así ninguna otra función tiene que
 *  comprobar si malloc devolvió NULL.
 *
 *  (Cocina: pedir al almacén un estante vacío de cierto tamaño; si no queda sitio, se
 *  avisa y se cierra la cocina.)
 * ------------------------------------------------------------------------------------- */
void *reservar(size_t bytes, const char *para_que) {
    void *memoria = malloc(bytes ? bytes : 1);
    if (memoria == NULL) {
        fprintf(stderr, "Error: sin memoria para '%s' (%.1f MB)\n", para_que, bytes / 1048576.0);
        exit(1);
    }
    return memoria;
}

/* -------------------------------------------------------------------------------------
 *  reservar_cero()
 *
 *  Como reservar, pero con calloc: la memoria llega llena de ceros (útil para
 *  contadores).
 *
 *  (Cocina: pedir un estante ya limpio, con todos los cuencos vacíos.)
 * ------------------------------------------------------------------------------------- */
void *reservar_cero(size_t cuantos_elementos, size_t tamano_elemento, const char *para_que) {
    void *memoria = calloc(cuantos_elementos ? cuantos_elementos : 1, tamano_elemento ? tamano_elemento : 1);
    if (memoria == NULL) {
        fprintf(stderr, "Error: sin memoria para '%s' (%.1f MB)\n", para_que,
                (double)cuantos_elementos * tamano_elemento / 1048576.0);
        exit(1);
    }
    return memoria;
}

/* -------------------------------------------------------------------------------------
 *  redimensionar()
 *
 *  Agranda (o encoge) un bloque de memoria con realloc, conservando lo que tenía. Se
 *  usa cuando leemos un fichero y no sabemos de antemano cuántos monomios habrá: se
 *  duplica la capacidad cada vez que se llena.
 *
 *  (Cocina: cambiar a una estantería más grande y pasar a ella todo lo que ya había.)
 * ------------------------------------------------------------------------------------- */
void *redimensionar(void *memoria_vieja, size_t bytes, const char *para_que) {
    void *memoria_nueva = realloc(memoria_vieja, bytes ? bytes : 1);
    if (memoria_nueva == NULL) {
        fprintf(stderr, "Error: sin memoria al ampliar '%s' (%.1f MB)\n", para_que, bytes / 1048576.0);
        exit(1);
    }
    return memoria_nueva;
}

/* -------------------------------------------------------------------------------------
 *  comprobar_cabe_en_indice()
 *
 *  Comprueba que un número de posiciones cabe en tipo_indice (32 bits por defecto). Si
 *  no cabe, explica cómo recompilar con índices de 64 bits.
 *
 *  (Cocina: comprobar que el número de página cabe en la etiqueta corta; si el libro es
 *  demasiado gordo, hay que usar etiquetas largas (make INDICES=64).)
 * ------------------------------------------------------------------------------------- */
void comprobar_cabe_en_indice(entero64 valor, const char *para_que) {
    if (valor > MAXIMO_INDICE) {
        fprintf(stderr, "Error: '%s' necesita %lld posiciones y los índices son de %d bits.\n"
                        "       Recompila con:  make clean && make INDICES=64\n",
                para_que, valor, BITS_INDICE);
        exit(1);
    }
}

/* -------------------------------------------------------------------------------------
 *  generar_valores_aleatorios()
 *
 *  Rellena 'valores' con números al azar en [0.5, 1), en paralelo. Cada posición
 *  calcula su propia semilla a partir de (semilla, posición), así que el resultado es
 *  el mismo con 1 hilo que con 16.
 *
 *  (Cocina: sortear las cantidades de cada ingrediente; cada ingrediente tiene su
 *  propio dado numerado, así da igual qué cocinero lo tire: sale lo mismo.)
 * ------------------------------------------------------------------------------------- */
void generar_valores_aleatorios(entero64 cantidad, unsigned long long semilla, double *valores) {
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)
    for (entero64 posicion = 0; posicion < cantidad; posicion++) {
        unsigned long long estado_aleatorio = semilla_del_elemento(semilla ^ 0xABCDEF1234567ULL, posicion);
        valores[posicion] = 0.5 + 0.5 * aleatorio_entre_0_y_1(&estado_aleatorio);
    }
}

/* -------------------------------------------------------------------------------------
 *  imprimir_linea()
 *
 *  Imprime una línea separadora en la salida.
 *
 *  (Cocina: la raya que separa los apartados de la comanda.)
 * ------------------------------------------------------------------------------------- */
void imprimir_linea(void) {
    printf("-------------------------------------------------------------------------------\n");
}

/* -------------------------------------------------------------------------------------
 *  imprimir_bytes()
 *
 *  Imprime una cantidad de memoria en MB o GB, alineada.
 *
 *  (Cocina: decir cuánto sitio del almacén ocupa cada cosa.)
 * ------------------------------------------------------------------------------------- */
void imprimir_bytes(const char *nombre, double bytes) {
    if (bytes >= 1073741824.0) printf("    %-34s %8.2f GB\n", nombre, bytes / 1073741824.0);
    else                       printf("    %-34s %8.1f MB\n", nombre, bytes / 1048576.0);
}

/* -------------------------------------------------------------------------------------
 *  suma_prefija_paralela()
 *
 *  Suma prefija EXCLUSIVA en paralelo: [3,1,2,4] -> [0,3,4,6] y devuelve 10. Sirve para
 *  saber DÓNDE EMPIEZA cada trozo cuando conocemos el TAMAÑO de cada trozo.
 *
 *  Cómo (3 fases): (1) cada hilo hace la suma prefija de SU bloque y apunta el total
 *  del bloque; (2) un solo hilo (single) acumula los totales de los bloques, que son
 *  pocos; (3) cada hilo suma a su bloque el desplazamiento que le corresponde. Entre
 *  (1) y (2) hay una barrera (barrier) para que nadie avance antes de tiempo.
 *
 *  (Cocina: sabemos cuántas páginas ocupa cada receta y queremos el índice del libro
 *  (en qué página empieza cada una). Cada cocinero numera su montón empezando en 0, uno
 *  solo calcula dónde empieza cada montón y luego todos corrigen su numeración a la
 *  vez.)
 * ------------------------------------------------------------------------------------- */
entero64 suma_prefija_paralela(entero64 *valores, entero64 longitud) {
    int max_hilos = omp_get_max_threads();
    entero64 *total_por_bloque = reservar_cero(max_hilos + 1, sizeof(entero64), "total_por_bloque");
    entero64 total = 0;

    /* OpenMP: se abre un equipo de hilos y TODOS ejecutan el bloque. (Cocina: ¡todos a cocinar!) */
    #pragma omp parallel
    {
        int total_hilos  = omp_get_num_threads();
        int mi_hilo = omp_get_thread_num();
        entero64 inicio = longitud * mi_hilo / total_hilos, final = longitud * (mi_hilo + 1) / total_hilos;

        entero64 suma = 0;
        for (entero64 posicion = inicio; posicion < final; posicion++) { entero64 valor = valores[posicion]; valores[posicion] = suma; suma += valor; }
        total_por_bloque[mi_hilo + 1] = suma;

        /* OpenMP: barrera: nadie sigue hasta que lleguen todos los hilos. (Cocina: nadie emplata
         * hasta que todos hayan terminado.) */
        #pragma omp barrier
        /* OpenMP: lo ejecuta UN solo hilo; los demás le esperan al final. (Cocina: esto lo hace
         * uno solo mientras los demás esperan.) */
        #pragma omp single
        {
            for (int bloque = 1; bloque <= total_hilos; bloque++) total_por_bloque[bloque] += total_por_bloque[bloque - 1];
            total = total_por_bloque[total_hilos];
        }
        entero64 desplazamiento = total_por_bloque[mi_hilo];
        for (entero64 posicion = inicio; posicion < final; posicion++) valores[posicion] += desplazamiento;
    }
    free(total_por_bloque);
    return total;
}

/* -------------------------------------------------------------------------------------
 *  suma_prefija_indices()
 *
 *  Igual que suma_prefija_paralela, pero sobre tipo_indice. Los totales se llevan en 64
 *  bits y se comprueba que el total cabe ANTES de escribir nada: si no cabe, no se
 *  corrompe nada y se avisa.
 *
 *  (Cocina: la misma numeración de páginas, comprobando antes que los números no se
 *  salen de la etiqueta.)
 * ------------------------------------------------------------------------------------- */
entero64 suma_prefija_indices(tipo_indice *valores, entero64 longitud, const char *para_que) {
    int max_hilos = omp_get_max_threads();
    entero64 *total_por_bloque = reservar_cero(max_hilos + 1, sizeof(entero64), "total_por_bloque");
    entero64 total = 0;

    /* OpenMP: se abre un equipo de hilos y TODOS ejecutan el bloque. (Cocina: ¡todos a cocinar!) */
    #pragma omp parallel
    {
        int total_hilos  = omp_get_num_threads();
        int mi_hilo = omp_get_thread_num();
        entero64 inicio = longitud * mi_hilo / total_hilos, final = longitud * (mi_hilo + 1) / total_hilos;

        entero64 suma = 0;                                          /* (1) solo sumar */
        for (entero64 posicion = inicio; posicion < final; posicion++) suma += valores[posicion];
        total_por_bloque[mi_hilo + 1] = suma;

        /* OpenMP: barrera: nadie sigue hasta que lleguen todos los hilos. (Cocina: nadie emplata
         * hasta que todos hayan terminado.) */
        #pragma omp barrier
        /* OpenMP: lo ejecuta UN solo hilo; los demás le esperan al final. (Cocina: esto lo hace
         * uno solo mientras los demás esperan.) */
        #pragma omp single                                  /* (2) */
        {
            for (int bloque = 1; bloque <= total_hilos; bloque++) total_por_bloque[bloque] += total_por_bloque[bloque - 1];
            total = total_por_bloque[total_hilos];
        }
        if (total <= MAXIMO_INDICE) {                             /* (3) escribir */
            entero64 acumulado = total_por_bloque[mi_hilo];
            for (entero64 posicion = inicio; posicion < final; posicion++) { entero64 valor = valores[posicion]; valores[posicion] = (tipo_indice)acumulado; acumulado += valor; }
        }
    }
    free(total_por_bloque);
    comprobar_cabe_en_indice(total, para_que);
    return total;
}
