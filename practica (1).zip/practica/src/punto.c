/* =====================================================================================
 *  punto.c — Lectura del punto: fichero, teclado o aleatorio
 *
 *  Los valores del usuario (fichero o teclado) vienen en el ORDEN ORIGINAL de las
 *  variables. Si el programa ha reordenado las variables (-R), se pasan a la
 *  numeración interna: punto[j] = punto_original[numero_original_de_variable[j]].
 *
 *  (Cocina: la recepción de pedidos (ver punto.h).)
 * ===================================================================================== */
#include "punto.h"
#include "polinomio.h"
#include <ctype.h>

const char *nombre_del_origen[5] = { "auto", "teclado", "fichero", "aleatorio", "interactivo" };

/* -------------------------------------------------------------------------------------
 *  origen_desde_nombre()
 *
 *  Convierte el nombre de un origen ('teclado', 'fichero'...) en su número ORIGEN_*, o
 *  -1 si no existe. La usa la opción -O.
 *
 *  (Cocina: entender si el pedido llega por teléfono, por escrito o lo sorteamos.)
 * ------------------------------------------------------------------------------------- */
int origen_desde_nombre(const char *nombre) {
    for (int origen = 0; origen < 5; origen++) if (strcmp(nombre, nombre_del_origen[origen]) == 0) return origen;
    return -1;
}

/* -------------------------------------------------------------------------------------
 *  pasar_a_orden_interno()
 *
 *  El usuario da los valores en el orden ORIGINAL de las variables. Si el programa ha
 *  reordenado (-R), aquí se colocan en la numeración interna: punto[j] =
 *  punto_original[numero_original_de_variable[j]].
 *
 *  (Cocina: el cliente dice 'tomate, cebolla, ajo', pero en el almacén los hemos
 *  cambiado de estante; aquí se pone cada cantidad en el estante correcto.)
 * ------------------------------------------------------------------------------------- */
static void pasar_a_orden_interno(const double *punto_original, double *punto) {
    if (numero_original_de_variable == NULL) { memcpy(punto, punto_original, sizeof(double) * num_variables); return; }
    for (entero64 variable = 0; variable < num_variables; variable++) punto[variable] = punto_original[numero_original_de_variable[variable]];
}

/* -------------------------------------------------------------------------------------
 *  extraer_numeros()
 *
 *  Saca números de un texto. Separadores: espacios, comas, punto y coma y saltos de
 *  línea. '#' comenta hasta el final de la línea y se ignora la etiqueta 'punto:'. OJO:
 *  la coma es SEPARADOR, los decimales van con punto (1.5, no 1,5). Devuelve cuántos ha
 *  leído, o -1 si encuentra algo que no es un número.
 *
 *  (Cocina: leer las cantidades de la nota del pedido.)
 * ------------------------------------------------------------------------------------- */
static entero64 extraer_numeros(char *texto, double *destino, entero64 maximo) {
    entero64 leidos = 0;
    char *cursor = texto;
    while (*cursor && leidos < maximo) {
        if (*cursor == '#') { while (*cursor && *cursor != '\n') cursor++; continue; }
        if (isspace((unsigned char)*cursor) || *cursor == ',' || *cursor == ';') { cursor++; continue; }
        if (strncmp(cursor, "punto:", 6) == 0) { cursor += 6; continue; }
        char *fin_numero;
        double valor = strtod(cursor, &fin_numero);
        if (fin_numero == cursor) {                                   /* algo que no es un número */
            fprintf(stderr, "  Valor no numérico cerca de \"%.15s\"\n", cursor);
            return -1;
        }
        destino[leidos++] = valor;
        cursor = fin_numero;
    }
    return leidos;
}

/* -------------------------------------------------------------------------------------
 *  leer_punto_de_fichero()
 *
 *  Lee el punto de un fichero de datos (todo el fichero de golpe y luego
 *  extraer_numeros). Exige al menos un valor por variable. Devuelve 1 si ha podido, 0
 *  si no.
 *
 *  (Cocina: el pedido llega escrito en una nota.)
 * ------------------------------------------------------------------------------------- */
int leer_punto_de_fichero(const char *ruta, double *punto) {
    FILE *fichero = fopen(ruta, "r");
    if (fichero == NULL) { fprintf(stderr, "  No puedo abrir el fichero del punto '%s'\n", ruta); return 0; }
    fseek(fichero, 0, SEEK_END);
    long tamano = ftell(fichero);
    rewind(fichero);
    char *texto = reservar(tamano + 1, "texto");
    size_t bytes_leidos = fread(texto, 1, tamano, fichero);
    texto[bytes_leidos] = '\0';
    fclose(fichero);

    double *punto_original = reservar(sizeof(double) * num_variables, "punto_original");
    entero64 valores_leidos = extraer_numeros(texto, punto_original, num_variables);
    free(texto);
    if (valores_leidos < num_variables) {
        if (valores_leidos >= 0) fprintf(stderr, "  El fichero '%s' tiene %lld valores y hacen falta %lld\n", ruta, valores_leidos, num_variables);
        free(punto_original);
        return 0;
    }
    pasar_a_orden_interno(punto_original, punto);
    free(punto_original);
    return 1;
}

/* -------------------------------------------------------------------------------------
 *  leer_punto_de_teclado()
 *
 *  Pide el punto por el terminal. Con 20 variables o menos, las pide una a una ('x =
 *  '), aunque se pueden escribir varios valores seguidos en la misma línea. Con más de
 *  20, se escriben todos seguidos (pueden ocupar varias líneas) o UNO solo que se usa
 *  para todas.
 *
 *  (Cocina: el cliente dicta las cantidades por teléfono.)
 * ------------------------------------------------------------------------------------- */
int leer_punto_de_teclado(double *punto) {
    char linea[4096];
    if (num_variables <= 20) {                                      /* pocas variables: una a una */
        char nombre[64];
        printf("  Introduce el punto (uno a uno, o varios valores seguidos en la misma línea):\n");
        entero64 variable = 0;
        while (variable < num_variables) {
            nombre_de_variable(variable, nombre, sizeof nombre);
            printf("    %s = ", nombre);
            fflush(stdout);
            if (fgets(linea, sizeof linea, stdin) == NULL) return 0;
            double valores[20];
            entero64 leidos = extraer_numeros(linea, valores, num_variables - variable);
            if (leidos <= 0) { printf("    (no es un número, repite)\n"); continue; }
            for (entero64 posicion = 0; posicion < leidos; posicion++) punto[variable + posicion] = valores[posicion];     /* pocas vars: orden interno = mostrado */
            variable += leidos;
        }
        return 1;
    }
    /* muchas variables: todos los valores seguidos, o uno solo para todas */
    printf("  Introduce los %lld valores separados por espacios (pueden ocupar varias líneas),\n"
           "  o UN solo valor para usarlo en todas las variables:\n  > ", num_variables);
    fflush(stdout);
    double *punto_original = reservar(sizeof(double) * num_variables, "punto_original");
    entero64 total_leidos = 0;
    while (total_leidos < num_variables) {
        if (fgets(linea, sizeof linea, stdin) == NULL) { free(punto_original); return 0; }
        entero64 leidos = extraer_numeros(linea, punto_original + total_leidos, num_variables - total_leidos);
        if (leidos < 0) { printf("  > "); fflush(stdout); continue; }
        if (total_leidos == 0 && leidos == 1) {                           /* un único valor: para todas */
            for (entero64 variable = 1; variable < num_variables; variable++) punto_original[variable] = punto_original[0];
            total_leidos = num_variables;
            break;
        }
        total_leidos += leidos;
        if (total_leidos < num_variables) { printf("  (llevas %lld de %lld) > ", total_leidos, num_variables); fflush(stdout); }
    }
    pasar_a_orden_interno(punto_original, punto);
    free(punto_original);
    return 1;
}

/* -------------------------------------------------------------------------------------
 *  punto_aleatorio()
 *
 *  Genera un punto aleatorio en [0.5, 1). Se genera en la numeración ORIGINAL y luego
 *  se pasa a la interna: así es el mismo punto con o sin reordenar.
 *
 *  (Cocina: sortear las cantidades del pedido.)
 * ------------------------------------------------------------------------------------- */
void punto_aleatorio(unsigned long long semilla, double *punto) {
    double *punto_original = reservar(sizeof(double) * num_variables, "punto_original");
    generar_valores_aleatorios(num_variables, semilla, punto_original);
    pasar_a_orden_interno(punto_original, punto);
    free(punto_original);
}

/* -------------------------------------------------------------------------------------
 *  obtener_punto()
 *
 *  Obtiene el punto según su origen: teclado, fichero, aleatorio o auto (el que traía
 *  el fichero de la función o, si no traía, uno aleatorio).
 *
 *  (Cocina: la recepción decide de dónde sacar el pedido de hoy.)
 * ------------------------------------------------------------------------------------- */
int obtener_punto(int origen, const char *fichero, unsigned long long semilla, double *punto) {
    switch (origen) {
        case ORIGEN_TECLADO:   return leer_punto_de_teclado(punto);
        case ORIGEN_FICHERO:   return leer_punto_de_fichero(fichero, punto);
        case ORIGEN_ALEATORIO: punto_aleatorio(semilla, punto); return 1;
        default:                                          /* auto */
            if (punto_del_fichero) memcpy(punto, punto_del_fichero, sizeof(double) * num_variables);   /* ya en orden interno */
            else         punto_aleatorio(semilla, punto);
            return 1;
    }
}

/* -------------------------------------------------------------------------------------
 *  escribir_punto_en_fichero()
 *
 *  Guarda un punto en un fichero de datos, en el orden ORIGINAL de las variables, 8
 *  valores por línea. Se puede volver a leer con -F.
 *
 *  (Cocina: apuntar el pedido para poder repetirlo otro día.)
 * ------------------------------------------------------------------------------------- */
void escribir_punto_en_fichero(const char *ruta, const double *punto) {
    FILE *fichero = fopen(ruta, "w");
    if (fichero == NULL) { fprintf(stderr, "No puedo crear '%s'\n", ruta); return; }
    fprintf(fichero, "# punto con %lld valores, en el orden de las variables\n", num_variables);
    double *punto_original = reservar(sizeof(double) * num_variables, "punto_original");
    if (numero_original_de_variable) for (entero64 variable = 0; variable < num_variables; variable++) punto_original[numero_original_de_variable[variable]] = punto[variable];
    else                memcpy(punto_original, punto, sizeof(double) * num_variables);
    for (entero64 variable = 0; variable < num_variables; variable++) fprintf(fichero, "%.17g%c", punto_original[variable], (variable % 8 == 7 || variable + 1 == num_variables) ? '\n' : ' ');
    free(punto_original);
    fclose(fichero);
}
