/* =====================================================================================
 *  experimentos.c — Medición, escalabilidad, paralelismo anidado y comprobaciones
 *
 *  (Cocina: los concursos y el cronómetro (ver experimentos.h).)
 * ===================================================================================== */
#include "experimentos.h"
#include "polinomio.h"
#include "derivadas.h"

double ancho_banda_pico_gbs = 0.0;     /* ancho de banda pico medido con el triad (0 = no medido) */
double mejor_tiempo_paralelo = -1.0;     /* mejor tiempo paralelo de la tabla principal              */
const char *mejor_estrategia_paralela = "";

/* -------------------------------------------------------------------------------------
 *  imprimir_ancho_banda()
 *
 *  Imprime los GB/s conseguidos y, si se ha medido el pico (-B), qué porcentaje es.
 *
 *  (Cocina: kilos por segundo que ha traído el pinche, y qué parte de su máximo es.)
 * ------------------------------------------------------------------------------------- */
static void imprimir_ancho_banda(double bytes, double tiempo) {
    double gigabytes_por_segundo = bytes / tiempo / 1e9;
    if (ancho_banda_pico_gbs > 0) printf(" %7.1f %5.0f%%", gigabytes_por_segundo, 100.0 * gigabytes_por_segundo / ancho_banda_pico_gbs);
    else              printf(" %7.1f %6s", gigabytes_por_segundo, "-");
}

/* -------------------------------------------------------------------------------------
 *  medir_tiempo()
 *
 *  Ejecuta una estrategia con 'hilos' hilos: una vez de calentamiento (no se mide:
 *  carga datos en caché, crea los hilos) y luego 'repeticiones' veces cronometradas con
 *  omp_get_wtime. Devuelve el MEJOR tiempo: el menos afectado por interrupciones.
 *
 *  (Cocina: encender los fogones antes de cronometrar y quedarse con la mejor vuelta.)
 * ------------------------------------------------------------------------------------- */
double medir_tiempo(tipo_funcion_jacobiano estrategia, int hilos, int repeticiones, const double *punto, double *jacobiano) {
    omp_set_num_threads(hilos);
    estrategia(punto, jacobiano);
    double mejor_tiempo = 1e300;
    for (int repeticion = 0; repeticion < repeticiones; repeticion++) {
        double inicio_reloj = omp_get_wtime();
        estrategia(punto, jacobiano);
        double duracion = omp_get_wtime() - inicio_reloj;
        if (duracion < mejor_tiempo) mejor_tiempo = duracion;
    }
    return mejor_tiempo;
}

/* -------------------------------------------------------------------------------------
 *  error_relativo_maximo()
 *
 *  Mayor diferencia relativa |calculado - referencia| / (1 + |referencia|) entre dos
 *  vectores, en paralelo con reduction(max:...).
 *
 *  (Cocina: comparar dos tablones y decir cuál es la mayor diferencia.)
 * ------------------------------------------------------------------------------------- */
double error_relativo_maximo(const double *calculado, const double *referencia, entero64 cantidad) {
    double error_maximo = 0.0;
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales; cada hilo guarda su
     * máximo de error_maximo y al final se queda el mayor. (Cocina: los cocineros se reparten
     * estas comandas; a cada uno el mismo número de comandas, decidido antes de empezar; cada uno
     * apunta su peor caso y se queda el peor de todos.) */
    #pragma omp parallel for reduction(max:error_maximo) schedule(static)
    for (entero64 posicion = 0; posicion < cantidad; posicion++) {
        double error = fabs(calculado[posicion] - referencia[posicion]) / (1.0 + fabs(referencia[posicion]));
        if (error > error_maximo) error_maximo = error;
    }
    return error_maximo;
}

/* =====================================================================================
 *  Tabla principal
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  comparar_estrategias()
 *
 *  Tabla principal del PASO 3: mide todas las estrategias, calcula el speedup respecto
 *  al secuencial de SU familia, Mderiv/s, GB/s, error frente a la referencia y si
 *  coincide bit a bit. Guarda el mejor tiempo paralelo para el desglose. Devuelve el
 *  tiempo secuencial.
 *
 *  (Cocina: el concurso: cada forma de organizar la cocina prepara el mismo pedido y se
 *  apuntan tiempos y sabor.)
 * ------------------------------------------------------------------------------------- */
double comparar_estrategias(int hilos, int repeticiones, const double *punto, const double *jacobiano_referencia, double *jacobiano_temporal) {
    imprimir_linea();
    printf("PASO 3 en paralelo: %d hilos (mejor de %d repeticiones)\n", hilos, repeticiones);
    printf("  anidado = %d hilos (variables) × %d hilos (monomios), umbral %lld monomios\n\n",
           hilos_nivel_externo, hilos_nivel_interno, umbral_anidado);
    printf("  %-19s %10s %9s %9s %7s %6s %13s %5s\n",
           "Estrategia", "Tiempo(s)", "Speedup*", "Mderiv/s", "GB/s", "%pico", "Error vs ref", "Bit");

    double tiempo_secuencial = -1.0, tiempo_directo_secuencial = -1.0;
    for (int estrategia = 0; estrategia < NUM_ESTRATEGIAS; estrategia++) {
        int es_secuencial = (estrategia == 0 || estrategia == ESTRATEGIA_DIRECTA_SECUENCIAL);
        int hilos_usados = es_secuencial ? 1 : hilos;
        if (estrategia == ESTRATEGIA_DIRECTA_SECUENCIAL) printf("\n");
        if (!estrategia_disponible(estrategia, hilos_usados)) {
            printf("  %-19s   (no disponible: %s)\n", nombre_estrategia[estrategia],
                   estrategia <= 3 ? "PASO 1 sin materializar (-D)" : "memoria");
            continue;
        }
        double tiempo = medir_tiempo(funcion_estrategia[estrategia], hilos_usados, repeticiones, punto, jacobiano_temporal);
        if (estrategia == 0) tiempo_secuencial = tiempo;
        if (estrategia == ESTRATEGIA_DIRECTA_SECUENCIAL) tiempo_directo_secuencial = tiempo;
        if (!es_secuencial && (mejor_tiempo_paralelo < 0 || tiempo < mejor_tiempo_paralelo)) { mejor_tiempo_paralelo = tiempo; mejor_estrategia_paralela = nombre_estrategia[estrategia]; }
        double tiempo_referencia = (estrategia < ESTRATEGIA_DIRECTA_SECUENCIAL) ? tiempo_secuencial : tiempo_directo_secuencial;
        char texto_speedup[32];
        if (tiempo_referencia > 0) snprintf(texto_speedup, sizeof texto_speedup, "%.2fx", tiempo_referencia / tiempo); else snprintf(texto_speedup, sizeof texto_speedup, "-");
        printf("  %-19s %10.4f %9s %9.1f", nombre_estrategia[estrategia], tiempo, texto_speedup, num_factores / tiempo / 1e6);
        imprimir_ancho_banda(bytes_movidos_estrategia(estrategia, hilos_usados), tiempo);
        printf(" %13.1e %5s\n", error_relativo_maximo(jacobiano_temporal, jacobiano_referencia, num_entradas_jacobiano),
               memcmp(jacobiano_temporal, jacobiano_referencia, sizeof(double) * num_entradas_jacobiano) == 0 ? "sí" : "no");
    }
    printf("\n  * Speedup respecto al secuencial de SU familia (mide solo el paralelismo).\n");
    if (tiempo_secuencial > 0 && tiempo_directo_secuencial > 0)
        printf("    Mejora algorítmica directo_secuencial frente a secuencial: %.2fx\n", tiempo_secuencial / tiempo_directo_secuencial);
    printf("  Mderiv/s = millones de derivadas de monomio evaluadas por segundo\n");
    printf("  GB/s = bytes útiles movidos / tiempo (cota inferior: un acceso aleatorio trae\n"
           "         64 B de la RAM aunque se usen 8).  %%pico = respecto al triad medido (-B)\n");
    omp_set_num_threads(hilos);
    return tiempo_secuencial > 0 ? tiempo_secuencial : tiempo_directo_secuencial;
}

/* =====================================================================================
 *  Escalabilidad
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  escalabilidad_fuerte()
 *
 *  Escalabilidad FUERTE: el mismo problema con 1, 2, 4, ..., T hilos (más el máximo).
 *  Imprime el speedup de cada estrategia y el ideal.
 *
 *  (Cocina: el mismo banquete con 1, 2, 4... cocineros: ¿cuánto antes acabamos?)
 * ------------------------------------------------------------------------------------- */
void escalabilidad_fuerte(int max_hilos, int repeticiones, double tiempo_secuencial, const double *punto, double *jacobiano_temporal) {
    /* tiempo_secuencial: secuencial simbólico. Las estrategias directas se comparan con directo_secuencial. */
    int lista_hilos[64], num_pruebas = 0;
    for (int hilos_prueba = 1; hilos_prueba <= max_hilos && num_pruebas < 63; hilos_prueba *= 2) lista_hilos[num_pruebas++] = hilos_prueba;
    if (lista_hilos[num_pruebas - 1] != max_hilos) lista_hilos[num_pruebas++] = max_hilos;

    imprimir_linea();
    printf("ESCALABILIDAD (speedup = t_secuencial de su familia / t)\n\n  %-19s", "hilos");
    for (int prueba = 0; prueba < num_pruebas; prueba++) printf(" %8d", lista_hilos[prueba]);
    printf("\n");

    double tiempo_directo_secuencial = medir_tiempo(funcion_estrategia[ESTRATEGIA_DIRECTA_SECUENCIAL], 1, repeticiones, punto, jacobiano_temporal);
    int estrategias[] = {1, 2, 5, 6};
    for (int indice = 0; indice < 4; indice++) {
        int estrategia = estrategias[indice];
        if (!estrategia_disponible(estrategia, 1)) continue;
        double tiempo_referencia = (estrategia < ESTRATEGIA_DIRECTA_SECUENCIAL) ? tiempo_secuencial : tiempo_directo_secuencial;
        printf("  %-19s", nombre_estrategia[estrategia]);
        for (int prueba = 0; prueba < num_pruebas; prueba++) {
            if (!estrategia_disponible(estrategia, lista_hilos[prueba])) { printf(" %8s", "mem"); continue; }
            double tiempo = medir_tiempo(funcion_estrategia[estrategia], lista_hilos[prueba], repeticiones, punto, jacobiano_temporal);
            printf(" %7.2fx", tiempo_referencia / tiempo);
            fflush(stdout);
        }
        printf("\n");
    }
    printf("  %-19s", "ideal");
    for (int prueba = 0; prueba < num_pruebas; prueba++) printf(" %7.2fx", (double)lista_hilos[prueba]);
    printf("\n  (eficiencia = speedup / hilos)\n");
    omp_set_num_threads(max_hilos);
}

/* =====================================================================================
 *  Paralelismo anidado
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  estudio_anidado()
 *
 *  Paralelismo anidado con todas las parejas T1 × T2 cuyo producto es el número de
 *  hilos. A) variables (T1) × monomios de cada derivada (T2), con la estrategia
 *  anidada. B) puntos (T1) × variables (T2): un lote de puntos, cada uno evaluado con
 *  por_variables y T2 hilos.
 *
 *  (Cocina: probar todas las combinaciones de jefes de partida y pinches.)
 * ------------------------------------------------------------------------------------- */
void estudio_anidado(int hilos, int repeticiones, double tiempo_secuencial, const double *punto, double *jacobiano_temporal,
                     int puntos, unsigned long long semilla) {
    int hilos_externos[64], hilos_internos[64], num_combinaciones = 0;                       /* pares T1 × T2 = hilos */
    for (int externos = hilos; externos >= 1 && num_combinaciones < 64; externos--)
        if (hilos % externos == 0) { hilos_externos[num_combinaciones] = externos; hilos_internos[num_combinaciones] = hilos / externos; num_combinaciones++; }

    int externo_guardado = hilos_nivel_externo, interno_guardado = hilos_nivel_interno;
    imprimir_linea();
    printf("PARALELISMO ANIDADO (%d hilos en total; omp_set_max_active_levels(2))\n", hilos);

    /* ---- A) variables × monomios ---- */
    if (estrategia_disponible(3, hilos)) {
        printf("\n  A) Variables (T1) × monomios de cada derivada parcial (T2)\n");
        printf("     Solo se abre equipo interno si la derivada tiene >= %lld monomios.\n", umbral_anidado);
        entero64 derivadas_grandes = 0;
        for (entero64 entrada = 0; entrada < num_entradas_jacobiano; entrada++) if (inicio_derivados_de_entrada[entrada + 1] - inicio_derivados_de_entrada[entrada] >= umbral_anidado) derivadas_grandes++;
        printf("     Derivadas que superan el umbral: %lld de %lld (media: %.1f monomios por derivada)\n\n",
               derivadas_grandes, num_entradas_jacobiano, num_entradas_jacobiano ? (double)num_monomios_derivados / num_entradas_jacobiano : 0.0);
        printf("     %6s × %-6s %11s %9s\n", "T1", "T2", "Tiempo (s)", "Speedup");
        for (int combinacion = 0; combinacion < num_combinaciones; combinacion++) {
            hilos_nivel_externo = hilos_externos[combinacion]; hilos_nivel_interno = hilos_internos[combinacion];
            double tiempo = medir_tiempo(funcion_estrategia[3], hilos, repeticiones, punto, jacobiano_temporal);
            printf("     %6d × %-6d %11.4f %8.2fx\n", hilos_externos[combinacion], hilos_internos[combinacion], tiempo, tiempo_secuencial / tiempo);
            fflush(stdout);
        }
        hilos_nivel_externo = externo_guardado; hilos_nivel_interno = interno_guardado;
    }

    /* ---- B) puntos × variables ---- */
    if (!derivadas_construidas) { printf("\n  B) omitido: necesita el PASO 1 materializado\n"); return; }
    double bytes = (double)puntos * (num_variables + 2.0 * num_entradas_jacobiano) * sizeof(double);
    if (bytes > LIMITE_MEMORIA) {
        printf("\n  B) omitido: %d puntos necesitarían %.2f GB (reduce -P o el tamaño)\n",
               puntos, bytes / 1073741824.0);
        return;
    }
    printf("\n  B) Lote de %d puntos: puntos (T1) × variables (T2)\n", puntos);
    printf("     Cada punto se evalúa con 'por_variables' usando T2 hilos.\n\n");
    double *puntos_lote  = reservar(sizeof(double) * puntos * num_variables, "puntos_lote");
    double *jacobianos  = reservar(sizeof(double) * puntos * num_entradas_jacobiano, "jacobianos");
    double *jacobianos_referencia = reservar(sizeof(double) * puntos * num_entradas_jacobiano, "jacobianos_referencia");
    for (int numero_punto = 0; numero_punto < puntos; numero_punto++) generar_valores_aleatorios(num_variables, semilla + 1000 + numero_punto, puntos_lote + (entero64)numero_punto * num_variables);

    omp_set_num_threads(1);                           /* referencia secuencial */
    double inicio_reloj = omp_get_wtime();
    for (int numero_punto = 0; numero_punto < puntos; numero_punto++) funcion_estrategia[0](puntos_lote + (entero64)numero_punto * num_variables, jacobianos_referencia + (entero64)numero_punto * num_entradas_jacobiano);
    double tiempo_lote_secuencial = omp_get_wtime() - inicio_reloj;

    printf("     %6s × %-6s %11s %9s %14s\n", "T1", "T2", "Tiempo (s)", "Speedup", "Error vs sec.");
    printf("     %15s %11.4f %8.2fx %14s\n", "secuencial", tiempo_lote_secuencial, 1.0, "-");
    for (int combinacion = 0; combinacion < num_combinaciones; combinacion++) {
        int hilos_externo = hilos_externos[combinacion], hilos_interno = hilos_internos[combinacion];
        double mejor_tiempo = 1e300;
        for (int repeticion = 0; repeticion <= repeticiones; repeticion++) {             /* r = 0: calentamiento */
            inicio_reloj = omp_get_wtime();
            /* OpenMP: bucle repartido entre los hilos; reparto dinámico de 1 en 1; con
             * hilos_externo hilos. (Cocina: los cocineros se reparten estas comandas; quien acaba
             * coge 1 comanda más del gancho; solo trabajan hilos_externo cocineros.) */
            #pragma omp parallel for schedule(dynamic, 1) num_threads(hilos_externo)
            for (int numero_punto = 0; numero_punto < puntos; numero_punto++)
                jacobiano_por_variables_con_hilos(puntos_lote + (entero64)numero_punto * num_variables, jacobianos + (entero64)numero_punto * num_entradas_jacobiano, hilos_interno);
            double duracion = omp_get_wtime() - inicio_reloj;
            if (repeticion > 0 && duracion < mejor_tiempo) mejor_tiempo = duracion;
        }
        printf("     %6d × %-6d %11.4f %8.2fx %14.1e\n", hilos_externo, hilos_interno, mejor_tiempo, tiempo_lote_secuencial / mejor_tiempo,
               error_relativo_maximo(jacobianos, jacobianos_referencia, (entero64)puntos * num_entradas_jacobiano));
        fflush(stdout);
    }
    if (puntos < hilos)
        printf("\n     Ojo: con %d puntos y T1 > %d, sobran hilos externos sin trabajo.\n", puntos, puntos);
    free(puntos_lote); free(jacobianos); free(jacobianos_referencia);
    omp_set_num_threads(hilos);
}

/* =====================================================================================
 *  Comprobación independiente: diferencias finitas centrales
 *     ∂f/∂x_i ≈ ( f(x + h·e_i) − f(x − h·e_i) ) / 2h
 *  Solo se suman los monomios de f que contienen x_i (los demás no cambian al mover
 *  x_i): menos términos -> mucho menos error de redondeo.
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  evaluar_entrada_original()
 *
 *  Suma SOLO los monomios originales que contienen la variable de esa entrada (los
 *  demás no cambian al mover esa variable). Menos términos -> mucho menos error de
 *  redondeo en las diferencias finitas.
 *
 *  (Cocina: probar solo las líneas de la receta que llevan tomate.)
 * ------------------------------------------------------------------------------------- */
static double evaluar_entrada_original(entero64 entrada, const double *punto) {
    double suma = 0.0;
    for (entero64 derivado = inicio_derivados_de_entrada[entrada]; derivado < inicio_derivados_de_entrada[entrada + 1]; derivado++) {
        entero64 monomio = monomio_del_factor[factor_de_origen[derivado]];
        double valor = coeficiente_del_monomio[monomio];
        for (entero64 factor = inicio_del_monomio[monomio]; factor < inicio_del_monomio[monomio + 1]; factor++) valor *= potencia_entera(punto[variable_del_factor[factor]], exponente_del_factor[factor]);
        suma += valor;
    }
    return suma;
}

/* -------------------------------------------------------------------------------------
 *  variable_de_entrada()
 *
 *  A qué variable pertenece una entrada: búsqueda binaria en
 *  inicio_entradas_de_variable.
 *
 *  (Cocina: dada una casilla del menú, ¿de qué ingrediente es?)
 * ------------------------------------------------------------------------------------- */
static entero64 variable_de_entrada(entero64 entrada) {
    entero64 bajo = 0, alto = num_variables - 1;
    while (bajo < alto) {
        entero64 medio = (bajo + alto + 1) / 2;
        if (inicio_entradas_de_variable[medio] <= entrada) bajo = medio; else alto = medio - 1;
    }
    return bajo;
}

/* -------------------------------------------------------------------------------------
 *  comprobar_diferencias_finitas()
 *
 *  Comprobación INDEPENDIENTE de unas cuantas derivadas: (f(x+h) - f(x-h)) / 2h, con h
 *  proporcional al valor de la variable. Si el error relativo es pequeño, el cálculo
 *  analítico es correcto.
 *
 *  (Cocina: el catador prueba el plato con una pizca más y una pizca menos de un
 *  ingrediente y comprueba que la ficha acierta.)
 * ------------------------------------------------------------------------------------- */
void comprobar_diferencias_finitas(double *punto, const double *jacobiano_referencia, int cuantas) {
    if (num_entradas_jacobiano == 0) return;
    if (cuantas > num_entradas_jacobiano) cuantas = (int)num_entradas_jacobiano;
    char nombre_variable[64];
    printf("\nComprobación independiente (diferencias finitas centrales):\n");
    double peor_error = 0.0;
    for (int muestra = 0; muestra < cuantas; muestra++) {
        entero64 entrada = (cuantas > 1) ? (num_entradas_jacobiano - 1) * muestra / (cuantas - 1) : 0;
        entero64 variable = variable_de_entrada(entrada);
        double valor_original = punto[variable];
        double paso = 1e-5 * (1.0 + fabs(valor_original));
        punto[variable] = valor_original + paso; double f_mas = evaluar_entrada_original(entrada, punto);
        punto[variable] = valor_original - paso; double f_menos = evaluar_entrada_original(entrada, punto);
        punto[variable] = valor_original;
        double derivada_numerica = (f_mas - f_menos) / (2.0 * paso);
        double error = fabs(derivada_numerica - jacobiano_referencia[entrada]) / (1.0 + fabs(jacobiano_referencia[entrada]));
        if (error > peor_error) peor_error = error;
        nombre_de_variable(variable, nombre_variable, sizeof nombre_variable);
        char nombre_funcion[32];
        if (num_funciones == 1) snprintf(nombre_funcion, sizeof nombre_funcion, "f");
        else          snprintf(nombre_funcion, sizeof nombre_funcion, "f%d", funcion_de_la_entrada[entrada] + 1);
        printf("    ∂%s/∂%-10s analítico = %+.10e   numérico = %+.10e   err = %.1e\n",
               nombre_funcion, nombre_variable, jacobiano_referencia[entrada], derivada_numerica, error);
    }
    printf("    Peor error relativo: %.1e  %s\n", peor_error,
           peor_error < 1e-5 ? "-> OK" : "-> REVISAR (¿exponentes altos o valores de x grandes?)");
}

/* =====================================================================================
 *  Ancho de banda pico: STREAM "triad"  a[i] = b[i] + s·c[i]
 *  Es la referencia estándar de "lo máximo que la RAM puede entregar" en esta máquina.
 *  Se cuentan 24 bytes por iteración (leer b y c, escribir a), como en STREAM.
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  medir_ancho_banda_pico()
 *
 *  Mide lo máximo que entrega la RAM con el 'STREAM triad' (a[i] = b[i] + 3·c[i]) sobre
 *  arrays de 256 MB: 24 bytes por iteración. Primer toque en paralelo y el mejor de 5
 *  repeticiones.
 *
 *  (Cocina: prueba de carretilla: cuántos kilos por segundo puede traer el pinche del
 *  almacén como máximo.)
 * ------------------------------------------------------------------------------------- */
double medir_ancho_banda_pico(int hilos) {
    entero64 cantidad = 1LL << 25;                           /* 32 Mi doubles por array: 768 MB en total */
    double *resultado = reservar(sizeof(double) * cantidad, "resultado");
    double *sumando = reservar(sizeof(double) * cantidad, "sumando");
    double *multiplicando = reservar(sizeof(double) * cantidad, "multiplicando");
    omp_set_num_threads(hilos);
    /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
     * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido antes
     * de empezar.) */
    #pragma omp parallel for schedule(static)    /* 1er toque desde el hilo que lo usará */
    for (entero64 posicion = 0; posicion < cantidad; posicion++) { resultado[posicion] = 0.0; sumando[posicion] = 1.0; multiplicando[posicion] = 2.0; }
    double mejor_tiempo = 1e300;
    for (int repeticion = 0; repeticion < 6; repeticion++) {
        double inicio_reloj = omp_get_wtime();
        /* OpenMP: bucle repartido entre los hilos; reparto fijo a partes iguales. (Cocina: los
         * cocineros se reparten estas comandas; a cada uno el mismo número de comandas, decidido
         * antes de empezar.) */
        #pragma omp parallel for schedule(static)
        for (entero64 posicion = 0; posicion < cantidad; posicion++) resultado[posicion] = sumando[posicion] + 3.0 * multiplicando[posicion];
        double duracion = omp_get_wtime() - inicio_reloj;
        if (repeticion > 0 && duracion < mejor_tiempo) mejor_tiempo = duracion;
    }
    double gigabytes_por_segundo = 24.0 * cantidad / mejor_tiempo / 1e9;
    if (resultado[cantidad / 2] != 7.0) printf("  (aviso: triad dio un resultado inesperado)\n");
    free(resultado); free(sumando); free(multiplicando);
    return gigabytes_por_segundo;
}

/* =====================================================================================
 *  LOTES: leer cada monomio una vez para 8 puntos
 *  Se compara evaluar P puntos UNO A UNO (con la mejor estrategia de cada familia)
 *  frente a evaluarlos en lotes de 8 (la estructura se lee P/8 veces en vez de P).
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  estudio_lotes()
 *
 *  Compara evaluar P puntos UNO A UNO frente a hacerlo en lotes de 8. Prepara los
 *  puntos también intercalados, mide ambas formas, reordena el resultado del lote y lo
 *  compara con el secuencial de su familia.
 *
 *  (Cocina: cocinar 64 pedidos uno a uno o en bandejas de 8, y ver cuánto se ahorra.)
 * ------------------------------------------------------------------------------------- */
void estudio_lotes(int hilos, int repeticiones, int puntos, unsigned long long semilla) {
    int total_puntos = ((puntos + PUNTOS_POR_LOTE - 1) / PUNTOS_POR_LOTE) * PUNTOS_POR_LOTE;         /* múltiplo de PUNTOS_POR_LOTE */
    int num_lotes = total_puntos / PUNTOS_POR_LOTE;
    double bytes = (double)total_puntos * (num_variables + 3.0 * num_entradas_jacobiano) * sizeof(double);
    imprimir_linea();
    printf("LOTES: leer cada monomio una vez para %d puntos (SIMD), %d puntos, %d hilos\n",
           PUNTOS_POR_LOTE, total_puntos, hilos);
    if (bytes > LIMITE_MEMORIA) {
        printf("  Omitido: %d puntos necesitarían %.2f GB (reduce -P o el tamaño)\n", total_puntos, bytes / 1073741824.0);
        return;
    }
    double *puntos_seguidos  = reservar(sizeof(double) * total_puntos * num_variables, "puntos_seguidos");        /* punto a punto   */
    double *puntos_lote = reservar(sizeof(double) * total_puntos * num_variables, "puntos_lote");       /* intercalado     */
    double *jacobianos  = reservar(sizeof(double) * total_puntos * num_entradas_jacobiano, "jacobianos");
    double *jacobianos_lote = reservar(sizeof(double) * total_puntos * num_entradas_jacobiano, "jacobianos_lote");
    double *jacobianos_reordenados = reservar(sizeof(double) * total_puntos * num_entradas_jacobiano, "jacobianos_reordenados");
    for (int numero_punto = 0; numero_punto < total_puntos; numero_punto++) generar_valores_aleatorios(num_variables, semilla + 2000 + numero_punto, puntos_seguidos + (entero64)numero_punto * num_variables);
    for (int lote = 0; lote < num_lotes; lote++)                     /* intercalar: puntos_lote[lote][variable][punto_lote] */
        for (entero64 variable = 0; variable < num_variables; variable++)
            for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++)
                puntos_lote[((entero64)lote * num_variables + variable) * PUNTOS_POR_LOTE + punto_lote] = puntos_seguidos[((entero64)lote * PUNTOS_POR_LOTE + punto_lote) * num_variables + variable];

    printf("\n  %-34s %10s %10s %9s %7s %6s %10s\n", "Método", "Total(s)", "s/punto", "Speedup",
           "GB/s", "%pico", "Error");

    /* --- punto a punto --- */
    int estrategias_base[2] = {1, 6};                        /* por_variables, directo_privado */
    double tiempo_punto_a_punto[2] = {-1, -1};
    for (int indice = 0; indice < 2; indice++) {
        int estrategia = estrategias_base[indice];
        if (!estrategia_disponible(estrategia, hilos)) continue;
        omp_set_num_threads(hilos);
        funcion_estrategia[estrategia](puntos_seguidos, jacobianos);                       /* calentamiento */
        double mejor_tiempo = 1e300;
        for (int repeticion = 0; repeticion < repeticiones; repeticion++) {
            double inicio_reloj = omp_get_wtime();
            for (int numero_punto = 0; numero_punto < total_puntos; numero_punto++) funcion_estrategia[estrategia](puntos_seguidos + (entero64)numero_punto * num_variables, jacobianos + (entero64)numero_punto * num_entradas_jacobiano);
            double duracion = omp_get_wtime() - inicio_reloj;
            if (duracion < mejor_tiempo) mejor_tiempo = duracion;
        }
        tiempo_punto_a_punto[indice] = mejor_tiempo;
        char nombre[64]; snprintf(nombre, sizeof nombre, "punto a punto: %s", nombre_estrategia[estrategia]);
        printf("  %-34s %10.4f %10.5f %8.2fx", nombre, mejor_tiempo, mejor_tiempo / total_puntos, 1.0);
        imprimir_ancho_banda(bytes_movidos_estrategia(estrategia, hilos) * total_puntos, mejor_tiempo);
        printf(" %10s\n", "-");
    }

    /* --- en lotes --- */
    for (int estrategia_lote = 0; estrategia_lote < NUM_ESTRATEGIAS_LOTE; estrategia_lote++) {
        if (!lote_disponible(estrategia_lote, hilos)) { printf("  %-34s   (no disponible: memoria o -D)\n", nombre_estrategia_lote[estrategia_lote]); continue; }
        omp_set_num_threads(hilos);
        funcion_estrategia_lote[estrategia_lote](puntos_lote, jacobianos_lote);                     /* calentamiento */
        double mejor_tiempo = 1e300;
        for (int repeticion = 0; repeticion < repeticiones; repeticion++) {
            double inicio_reloj = omp_get_wtime();
            for (int lote = 0; lote < num_lotes; lote++)
                funcion_estrategia_lote[estrategia_lote](puntos_lote + (entero64)lote * num_variables * PUNTOS_POR_LOTE, jacobianos_lote + (entero64)lote * num_entradas_jacobiano * PUNTOS_POR_LOTE);
            double duracion = omp_get_wtime() - inicio_reloj;
            if (duracion < mejor_tiempo) mejor_tiempo = duracion;
        }
        for (int lote = 0; lote < num_lotes; lote++)          /* volver a orden de punto para comparar */
            for (entero64 entrada = 0; entrada < num_entradas_jacobiano; entrada++)
                for (int punto_lote = 0; punto_lote < PUNTOS_POR_LOTE; punto_lote++)
                    jacobianos_reordenados[((entero64)lote * PUNTOS_POR_LOTE + punto_lote) * num_entradas_jacobiano + entrada] = jacobianos_lote[((entero64)lote * num_entradas_jacobiano + entrada) * PUNTOS_POR_LOTE + punto_lote];
        /* referencia: punto a punto secuencial de la misma familia */
        int estrategia_referencia = (estrategia_lote == 0) ? 0 : ESTRATEGIA_DIRECTA_SECUENCIAL;
        omp_set_num_threads(1);
        for (int numero_punto = 0; numero_punto < total_puntos; numero_punto++) funcion_estrategia[estrategia_referencia](puntos_seguidos + (entero64)numero_punto * num_variables, jacobianos + (entero64)numero_punto * num_entradas_jacobiano);
        double tiempo_referencia = tiempo_punto_a_punto[estrategia_lote == 0 ? 0 : 1];
        char texto_speedup[32];
        if (tiempo_referencia > 0) snprintf(texto_speedup, sizeof texto_speedup, "%.2fx", tiempo_referencia / mejor_tiempo); else snprintf(texto_speedup, sizeof texto_speedup, "-");
        char nombre[64]; snprintf(nombre, sizeof nombre, "lotes de %d: %s", PUNTOS_POR_LOTE, nombre_estrategia_lote[estrategia_lote]);
        printf("  %-34s %10.4f %10.5f %9s", nombre, mejor_tiempo, mejor_tiempo / total_puntos, texto_speedup);
        imprimir_ancho_banda(bytes_movidos_lote(estrategia_lote, hilos) * num_lotes, mejor_tiempo);
        printf(" %10.1e\n", error_relativo_maximo(jacobianos_reordenados, jacobianos, (entero64)total_puntos * num_entradas_jacobiano));
    }
    printf("\n  Speedup del lote = respecto a evaluar punto a punto con su misma familia\n"
           "  y el mismo nº de hilos. Error = frente al secuencial de su familia.\n");
    free(puntos_seguidos); free(puntos_lote); free(jacobianos); free(jacobianos_lote); free(jacobianos_reordenados);
    omp_set_num_threads(hilos);
}

/* =====================================================================================
 *  TAMAÑO DE BLOQUE (chunk) del reparto de iteraciones
 *  static: bloques fijos decididos antes de empezar (sin coste de reparto).
 *  dynamic,c: cada hilo pide c iteraciones cuando acaba (equilibra, pero cada petición
 *             es una operación atómica compartida: chunks pequeños -> mucho coste).
 *  guided,c: empieza con bloques grandes y los va reduciendo hasta c.
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  estudio_tamano_bloque()
 *
 *  Mide tres estrategias con distintos repartos (static, dynamic,c y guided,c para
 *  varios c) usando omp_set_schedule, y marca con * el mejor de cada columna. Al final
 *  deja el reparto como estaba.
 *
 *  (Cocina: probar de cuántas en cuántas conviene coger las comandas del gancho.)
 * ------------------------------------------------------------------------------------- */
void estudio_tamano_bloque(int hilos, int repeticiones, const double *punto, double *jacobiano_temporal) {
    const char *nombres[] = { "static", "dynamic,1", "dynamic,64", "dynamic,1024", "dynamic,16384",
                              "guided,1", "guided,64", "guided,1024", "guided,16384" };
    omp_sched_t tipos_reparto[]   = { omp_sched_static, omp_sched_dynamic, omp_sched_dynamic, omp_sched_dynamic,
                              omp_sched_dynamic, omp_sched_guided, omp_sched_guided, omp_sched_guided,
                              omp_sched_guided };
    int tamanos_bloque[]          = { 0, 1, 64, 1024, 16384, 1, 64, 1024, 16384 };
    int estrategias[] = {1, 5, 6};
    omp_sched_t tipo_anterior; int bloque_anterior;
    omp_get_schedule(&tipo_anterior, &bloque_anterior);

    imprimir_linea();
    printf("TAMAÑO DE BLOQUE DEL REPARTO (%d hilos; tiempo en s, el mejor de cada columna con *)\n\n", hilos);
    printf("  %-15s", "reparto");
    for (int indice = 0; indice < 3; indice++) printf(" %16s", nombre_estrategia[estrategias[indice]]);
    printf("\n");
    double tiempos[9][3], mejor_tiempo[3] = {1e300, 1e300, 1e300};
    for (int reparto = 0; reparto < 9; reparto++) {
        omp_set_schedule(tipos_reparto[reparto], tamanos_bloque[reparto]);
        for (int indice = 0; indice < 3; indice++) {
            tiempos[reparto][indice] = estrategia_disponible(estrategias[indice], hilos) ? medir_tiempo(funcion_estrategia[estrategias[indice]], hilos, repeticiones, punto, jacobiano_temporal) : -1;
            if (tiempos[reparto][indice] > 0 && tiempos[reparto][indice] < mejor_tiempo[indice]) mejor_tiempo[indice] = tiempos[reparto][indice];
        }
    }
    for (int reparto = 0; reparto < 9; reparto++) {
        printf("  %-15s", nombres[reparto]);
        for (int indice = 0; indice < 3; indice++) {
            if (tiempos[reparto][indice] < 0) printf(" %16s", "-");
            else printf(" %15.4f%c", tiempos[reparto][indice], tiempos[reparto][indice] == mejor_tiempo[indice] ? '*' : ' ');
        }
        printf("\n");
    }
    printf("\n  (por_variables reparte VARIABLES; las directas reparten MONOMIOS)\n");
    omp_set_schedule(tipo_anterior, bloque_anterior);
    omp_set_num_threads(hilos);
}
