/* =====================================================================================
 *  omp_compat.h — Portabilidad: compilar el MISMO código con o sin OpenMP
 *
 *  Con -fopenmp se usa la biblioteca real de OpenMP.
 *  Sin -fopenmp (versión secuencial, ./gradiente_sec) los #pragma omp se ignoran y
 *  estas funciones sustituyen a las de OpenMP: 1 hilo, y el reloj con clock_gettime.
 *  Así la versión secuencial y la paralela comparten el código y deben dar el mismo
 *  resultado, que es lo que comprueba "make test".
 *
 *  (Cocina: si no hay jefe de cocina (compilado sin OpenMP), estas funciones hacen de
 *  jefe de mentira para un único cocinero: siempre hay 1 cocinero, es el número 0, y el
 *  cronómetro sigue funcionando. Así el mismo libro de instrucciones sirve con y sin
 *  jefe.)
 * ===================================================================================== */
#ifndef OMP_COMPAT_H
#define OMP_COMPAT_H

#ifdef _OPENMP
#include <omp.h>
#else

#include <time.h>
#include <unistd.h>

typedef enum { omp_sched_static = 1, omp_sched_dynamic = 2, omp_sched_guided = 3,
               omp_sched_auto = 4 } omp_sched_t;
typedef enum { omp_proc_bind_false = 0, omp_proc_bind_true = 1, omp_proc_bind_primary = 2,
               omp_proc_bind_close = 3, omp_proc_bind_spread = 4 } omp_proc_bind_t;

static inline double omp_get_wtime(void) {
    struct timespec reloj;
    clock_gettime(CLOCK_MONOTONIC, &reloj);
    return reloj.tv_sec + reloj.tv_nsec * 1e-9;
}
static inline int  omp_get_num_threads(void)      { return 1; }
static inline int  omp_get_thread_num(void)       { return 0; }
static inline int  omp_get_max_threads(void)      { return 1; }
static inline int  omp_get_num_procs(void)        { return 1; }
static inline void omp_set_num_threads(int cantidad)     { (void)cantidad; }
static inline void omp_set_max_active_levels(int cantidad) { (void)cantidad; }
static inline void omp_set_schedule(omp_sched_t tipo, int tamano_bloque) { (void)tipo; (void)tamano_bloque; }
static inline void omp_get_schedule(omp_sched_t *tipo, int *tamano_bloque) { *tipo = omp_sched_static; *tamano_bloque = 0; }
static inline omp_proc_bind_t omp_get_proc_bind(void) { return omp_proc_bind_false; }
static inline int  omp_get_num_places(void)       { return 0; }

#endif
#endif
