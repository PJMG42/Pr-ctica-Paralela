/* =====================================================================================
 *  polinomio.c — Datos de la función (arrays globales) y utilidades de impresión
 *
 *  La construcción está repartida en otros ficheros:
 *    lectura.c     entrada/salida: ficheros (texto, numérico, binario) y ejemplos
 *    generacion.c  generación aleatoria en paralelo (problemas grandes)
 *
 *  (Cocina: el libro de recetas: dónde están guardadas y cómo se leen en voz alta.)
 * ===================================================================================== */
#include "polinomio.h"

/* ---------- Definición de los arrays globales ---------- */
entero64      num_funciones = 0, num_variables = 0, num_monomios = 0, num_factores = 0;
entero64      *inicio_de_funcion = NULL;
int           *funcion_del_monomio = NULL;
double        *coeficiente_del_monomio = NULL;
tipo_indice   *inicio_del_monomio = NULL;
int           *variable_del_factor = NULL;
unsigned char *exponente_del_factor = NULL;
char          **nombres_de_variables = NULL;
int           nombres_de_una_letra = 0;
double        *punto_del_fichero = NULL;
int           *numero_original_de_variable = NULL;

/* =====================================================================================
 *  IMPRESIÓN
 * ===================================================================================== */
/* -------------------------------------------------------------------------------------
 *  nombre_de_variable()
 *
 *  Escribe en 'texto' el nombre de la variable para mostrarlo: su nombre (x, y,
 *  masa...) o x0, x1... Si se ha reordenado, muestra el número ORIGINAL, para que los
 *  resultados se puedan comparar con una ejecución sin reordenar.
 *
 *  (Cocina: la etiqueta del ingrediente tal y como la conoce el cliente, aunque en el
 *  almacén lo hayamos cambiado de estante.)
 * ------------------------------------------------------------------------------------- */
void nombre_de_variable(entero64 variable, char *texto, size_t tamano_texto) {
    if (nombres_de_variables)           snprintf(texto, tamano_texto, "%s", nombres_de_variables[variable]);
    else if (numero_original_de_variable) snprintf(texto, tamano_texto, "x%d", numero_original_de_variable[variable]);
    else                     snprintf(texto, tamano_texto, "x%lld", variable);
}

/* -------------------------------------------------------------------------------------
 *  imprimir_termino()
 *
 *  Imprime un monomio con su signo: '3xy', ' + 4yz', ' - 2x^2', '5'... Si todas las
 *  variables son de una letra las escribe pegadas (como en el enunciado); si no,
 *  separadas con '*'. No escribe el coeficiente si es 1.
 *
 *  (Cocina: escribir una línea de la receta en limpio.)
 * ------------------------------------------------------------------------------------- */
void imprimir_termino(FILE *salida, double coeficiente, int num_factores_monomio, const int *variables,
                           const unsigned char *exponentes, int es_el_primero) {
    double valor_absoluto = fabs(coeficiente);
    if (es_el_primero) { if (coeficiente < 0) fputc('-', salida); }
    else         fputs(coeficiente < 0 ? " - " : " + ", salida);
    if (num_factores_monomio == 0) { fprintf(salida, "%g", valor_absoluto); return; }
    int escribir_coeficiente = (valor_absoluto != 1.0);
    if (escribir_coeficiente) fprintf(salida, "%g", valor_absoluto);
    char nombre[64];
    for (int posicion = 0; posicion < num_factores_monomio; posicion++) {
        if (!nombres_de_una_letra && (posicion > 0 || escribir_coeficiente)) fputc('*', salida);
        nombre_de_variable(variables[posicion], nombre, sizeof nombre);
        fputs(nombre, salida);
        if (exponentes[posicion] > 1) fprintf(salida, "^%d", exponentes[posicion]);
    }
}

/* -------------------------------------------------------------------------------------
 *  imprimir_funcion()
 *
 *  Imprime la función número 'funcion' completa, monomio a monomio.
 *
 *  (Cocina: leer en voz alta la receta entera de un plato.)
 * ------------------------------------------------------------------------------------- */
void imprimir_funcion(FILE *salida, entero64 funcion) {
    if (inicio_de_funcion[funcion] == inicio_de_funcion[funcion + 1]) { fputs("0", salida); return; }
    for (entero64 monomio = inicio_de_funcion[funcion]; monomio < inicio_de_funcion[funcion + 1]; monomio++) {
        entero64 primer_factor = inicio_del_monomio[monomio];
        imprimir_termino(salida, coeficiente_del_monomio[monomio], (int)(inicio_del_monomio[monomio + 1] - primer_factor),
                              variable_del_factor + primer_factor, exponente_del_factor + primer_factor, monomio == inicio_de_funcion[funcion]);
    }
}

/* -------------------------------------------------------------------------------------
 *  buscar_monomio_del_factor()
 *
 *  Dado un factor (una posición de variable_del_factor), averigua a qué monomio
 *  pertenece con BÚSQUEDA BINARIA en inicio_del_monomio (que está ordenado): O(log M).
 *
 *  (Cocina: dada una página suelta, buscar en el índice a qué receta pertenece,
 *  abriendo el libro por la mitad, luego por la mitad de la mitad...)
 * ------------------------------------------------------------------------------------- */
entero64 buscar_monomio_del_factor(entero64 factor) {
    entero64 bajo = 0, alto = num_monomios - 1;
    while (bajo < alto) {
        entero64 medio = (bajo + alto + 1) / 2;
        if (inicio_del_monomio[medio] <= factor) bajo = medio; else alto = medio - 1;
    }
    return bajo;
}

/* -------------------------------------------------------------------------------------
 *  liberar_funcion()
 *
 *  Libera todos los arrays de la función y deja los contadores a 0.
 *
 *  (Cocina: guardar el libro de recetas y dejar la mesa limpia para el siguiente
 *  plato.)
 * ------------------------------------------------------------------------------------- */
void liberar_funcion(void) {
    free(inicio_de_funcion); free(funcion_del_monomio); free(coeficiente_del_monomio); free(inicio_del_monomio);
    free(variable_del_factor); free(exponente_del_factor); free(punto_del_fichero); free(numero_original_de_variable);
    if (nombres_de_variables) { for (entero64 variable = 0; variable < num_variables; variable++) free(nombres_de_variables[variable]); free(nombres_de_variables); }
    inicio_de_funcion = NULL; funcion_del_monomio = NULL; coeficiente_del_monomio = NULL; inicio_del_monomio = NULL;
    variable_del_factor = NULL; exponente_del_factor = NULL; punto_del_fichero = NULL; nombres_de_variables = NULL; numero_original_de_variable = NULL;
    num_funciones = num_variables = num_monomios = num_factores = 0;
}
