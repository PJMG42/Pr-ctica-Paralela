# Práctica final — Cálculo paralelo de gradientes (OpenMP)

Cálculo del gradiente de funciones polinómicas multivariables y del Jacobiano de sistemas
de ecuaciones, siguiendo el método del enunciado (PASO 1 → PASO 2 → PASO 3) y
paralelizado con OpenMP.

**Para empezar a leer:**
- `ENUNCIADO_EXPLICADO.txt`: qué pide la práctica y cómo se resuelve, explicado con el
  ejemplo de la cocina (receta = función, ingredientes = variables, cocineros = hilos...).
- `MANUAL_DE_USO.txt`: todo lo que se puede escribir en el terminal (compilar, elegir el
  punto, hilos, estudios, generador, Docker) y los errores típicos.
- En el código, cada función tiene un comentario con qué hace, cómo lo hace y, entre
  paréntesis, `(Cocina: ...)` la parte de la cocina a la que equivale.

## Compilar y probar

```bash
make                 # compila todo: ./gradiente (OpenMP), ./gradiente_sec (secuencial), ./generador
make test            # batería de pruebas: resultados conocidos + secuencial == paralelo
./gradiente -x       # ejemplo del enunciado: debe terminar en  ∇f(1, 2, 3) = (8, 15, 8)
./gradiente -X       # sistema de 3 ecuaciones del enunciado (Jacobiano)
./gradiente -h       # todas las opciones
make INDICES=64      # versión con índices de 64 bits -> ./gradiente64
make debug           # versión con AddressSanitizer (detecta errores de memoria)
make clean           # borra todo lo compilado
```

## Estructura del proyecto

| Fichero | Contenido |
|---|---|
| `src/comun.*` | Memoria, sumas prefijas paralelas, números aleatorios paralelizables |
| `src/omp_compat.h` | Portabilidad: el mismo código compila con OpenMP o sin él (versión secuencial) |
| `src/polinomio.*` | Datos de la función/sistema (arrays CSR) e impresión |
| `src/lectura.c` | **Lectura y escritura de datos**: ficheros de texto, numérico y binario; ejemplos |
| `src/generacion.c` | Generación aleatoria de funciones y sistemas, en paralelo |
| `src/generador.c` | **Programa externo** que genera ficheros de prueba (`./generador`) |
| `src/derivadas.*` | **PASO 1** (derivadas simbólicas) y **PASO 2** (gradiente / Jacobiano) — CPU |
| `src/evaluacion.*` | **PASO 3** (evaluación en un punto), 7 estrategias + lotes SIMD — CPU |
| `src/reordenar.*` | Reordenación de variables y monomios (BFS tipo Cuthill–McKee) — CPU |
| `src/experimentos.*` | Tiempos, escalabilidad, anidamiento, lotes, tamaño de bloque, ancho de banda |
| `src/punto.*` | **Lectura del punto**: fichero, teclado, aleatorio (origen elegido al compilar o al ejecutar) |
| `src/pruebas.*` | **Batería de pruebas** (`./gradiente -T`, `make test`) |
| `src/main.c` | Opciones, flujo del programa y desglose de tiempos |
| `ejemplos/` | Funciones de ejemplo en fichero y un punto de ejemplo (`punto_enunciado.txt`) |
| `experimentos.sh`, `afinidad.sh` | Experimentos para la memoria (ejecutar en el servidor) |
| `Dockerfile` | Contenedor |

## Diccionario de nombres

Todos los nombres están en castellano y completos. Las palabras que más se repiten:

| Palabra | Qué es |
|---|---|
| **monomio** | un término de la función: `3xy` |
| **factor** (o casilla) | una pareja (variable, exponente) dentro de un monomio: en `3x²y` hay dos, `x²` e `y` |
| **entrada** | una casilla no nula del Jacobiano: la derivada ∂fᵢ/∂xⱼ (con una función, una componente del gradiente) |
| **derivado** | un monomio de una derivada parcial ya calculada (PASO 1) |
| **inicio_de_X** | array de "dónde empieza cada X" (estilo CSR): X número `k` ocupa de `inicio[k]` a `inicio[k+1]-1` |
| **num_X** | cuántos X hay en total (variables globales) |
| **total_X** | lo mismo, copiado en una variable local |
| **punto** | los valores de las variables donde se evalúa |
| **lote** | grupo de 8 puntos que se evalúan a la vez (SIMD) |

Las globales principales de la función: `num_funciones`, `num_variables`, `num_monomios`,
`num_factores`, `inicio_de_funcion`, `funcion_del_monomio`, `coeficiente_del_monomio`,
`inicio_del_monomio`, `variable_del_factor`, `exponente_del_factor`.

## Cómo se proporcionan los datos

1. **Programa externo** que genera un fichero, y después se lee con `-f`:
   ```bash
   ./generador -n 1000000 -m 10000000 -o problema.bin   # binario: rápido (13× más que texto)
   ./generador -n 50 -m 200 -E 3 -o sistema.txt          # texto: legible y editable
   ./gradiente -f problema.bin
   ```
2. **Dentro de la aplicación**, con números aleatorios (sin `-f`): `./gradiente -n ... -m ... -E ...`
3. **Fichero escrito a mano** en formato de texto (siguiente sección) o los ejemplos `-x` / `-X`.

## Punto donde se evalúa y valida el gradiente

Las derivadas (PASO 1 y 2) se calculan **antes** de pedir el punto. El punto puede venir de:

| Origen | Qué hace |
|---|---|
| `auto` | El punto del fichero de la función; si no trae, uno aleatorio |
| `teclado` | Se escriben los valores en el terminal (con muchas variables: todos seguidos, o uno solo para todas) |
| `fichero` | Fichero de datos con N números separados por espacios, comas o saltos de línea (`#` = comentario) |
| `aleatorio` | Valores aleatorios en [0.5, 1) |
| `interactivo` | Tras derivar, el programa pide un **comando**: `teclado`, `fichero RUTA`, `aleatorio`, `original`, `guardar RUTA`, `salir`. Se puede evaluar en muchos puntos con una sola derivación |

**Al compilar** se fija el origen por defecto; **al ejecutar** se puede cambiar:

```bash
make clean && make PUNTO=interactivo                      # por defecto: modo interactivo
make clean && make PUNTO=fichero PUNTO_FICHERO=punto.txt  # por defecto: ese fichero
./gradiente -f problema.bin -O teclado                    # cambiarlo al ejecutar
./gradiente -f problema.bin -F mi_punto.txt               # leer el punto de un fichero
./gradiente -f problema.bin -I                            # modo interactivo
./generador -n 1000 -m 5000 -N -o f.txt -p punto.txt      # genera la función y un punto aparte
```

Los tiempos se miden con `omp_get_wtime()` (en la versión sin OpenMP, con un reloj
equivalente basado en `clock_gettime`, ver `src/omp_compat.h`).

Al final de cada ejecución se imprime el **desglose de tiempos**: antes de la entrada de
datos, entrada de datos (lectura o generación), PASO 1+2, PASO 3 secuencial y paralelo,
comprobación y total.

## Pruebas

`make test` comprueba:
- 8 ecuaciones con resultado calculado a mano (ejemplo y sistema del enunciado, constantes,
  exponentes altos, coeficientes negativos, variables que no aparecen, nombres largos...)
  con **todas las estrategias y de 1 a T hilos**;
- problemas aleatorios: cada estrategia paralela = secuencial (la familia simbólica,
  idéntica bit a bit), lotes = punto a punto, reordenado = sin reordenar;
- la versión **sin OpenMP** y la **OpenMP** dan el mismo gradiente bit a bit.

## Formato de los ficheros de entrada

```text
# comentario
variables: x y z                 # o "variables: 1000" -> x0, x1, ..., x999
f: 3xy + 4yz + 2x + 5            # una línea por función (cualquier etiqueta con ':')
g: 3x^2 + yz + z + 5 = 2         # con '=' se pasa todo a la izquierda (lhs - rhs)
punto: 1 2 3                     # opcional (si falta, punto aleatorio)
```

- Exponentes con `^`: `3*x^2*y`. Si **todas** las variables tienen nombre de una letra,
  se pueden escribir pegadas como en el enunciado: `3xy`, `yz3` (= y·z³), `z2` (= z²).
- Con nombres de varias letras, los factores se separan con `*` o espacios: `0.5*masa*vel^2`.
- Una función = gradiente. Varias funciones = sistema → Jacobiano.
- También se acepta el formato numérico de la versión anterior (`ejemplos/formato_numerico.txt`).

## Estrategias del PASO 3

Familia **simbólica** (usa los polinomios derivados del PASO 1, como pide el método):

| Estrategia | Qué se reparte entre hilos |
|---|---|
| `secuencial` | Nada: referencia |
| `por_variables` | Las derivadas parciales (una por variable) |
| `por_monomios` | Todos los monomios derivados, y luego se suman por derivada |
| `anidado` | Variables (T1 hilos) × monomios de cada derivada (T2 hilos) |

Familia **directa** (optimización algorítmica: deriva "al vuelo" sin guardar el PASO 1):

| Estrategia | Qué se reparte entre hilos |
|---|---|
| `directo_secuencial` | Nada: referencia de esta familia |
| `directo_atomico` | Monomios originales; suma con `atomic` |
| `directo_privado` | Monomios originales; una copia de resultados por hilo |

Cada familia se compara con su propio secuencial, así el speedup mide solo el paralelismo.

## Optimizaciones y estudios

| Opción | Qué hace |
|---|---|
| (por defecto) | **Índices de 32 bits**: ~25 % menos memoria que con 64 (`make INDICES=64` para comparar) |
| `-l` | **Lotes**: evalúa 8 puntos por cada lectura de la estructura (SIMD). Compara con punto a punto |
| `-R` | **Reordenación** BFS de variables y monomios. Probar con `-L 64` (estructura local) y `-Z` (desordenada) |
| `-C` | **Tamaño de bloque**: `static`, `dynamic,c`, `guided,c` con c = 1, 64, 1024, 16384 |
| `-b` | **Escalabilidad fuerte**: mismo problema con 1, 2, 4, ..., T hilos |
| `-W` | **Escalabilidad débil**: `-n` y `-m` son POR HILO; el problema crece con los hilos |
| `-B` | **Ancho de banda pico** (STREAM triad): añade la columna `%pico` a las tablas |
| `-A` | **Paralelismo anidado**: variables × monomios y puntos × variables |
| `afinidad.sh` | **Afinidad**: `OMP_PROC_BIND` = false / close / spread, `OMP_PLACES` = cores / threads |

```bash
./gradiente -n 1000000 -m 5000000 -b -B          # escalabilidad fuerte + ancho de banda
./gradiente -n 62500 -m 1250000 -W               # escalabilidad débil (por hilo)
./gradiente -n 1000000 -m 5000000 -l -P 64 -B    # lotes de 8 puntos
./gradiente -n 4000000 -m 8000000 -L 64 -Z -R    # reordenación sobre estructura desordenada
./gradiente -n 1000000 -m 5000000 -C             # tamaño de bloque
./gradiente -n 100 -m 5000000 -A -P 16           # paralelismo anidado
./afinidad.sh                                     # afinidad de hilos
./experimentos.sh                                 # todo, guardado en resultados/
```

Sobre la columna **GB/s**: son los bytes que el algoritmo necesita mover como mínimo,
divididos por el tiempo. Es una cota inferior (un acceso aleatorio trae 64 B de la RAM
aunque se usen 8). Comparada con el pico del triad dice si el límite es el ancho de
banda (cerca del 100 %) o la latencia y el cálculo (lejos).

Memoria aproximada con el PASO 1 materializado: unos **300 bytes por monomio**
(con 4,5 variables por monomio de media). Con `-D` no se materializa y baja a unos 110.
Comprueba `free -h` antes de lanzar problemas grandes.

## Contenedor

```bash
docker build -t gradiente .
docker run --rm gradiente            # ejemplo del enunciado
docker run --rm gradiente -n 1000000 -m 5000000 -b -A
```
