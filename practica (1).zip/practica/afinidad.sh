#!/bin/bash
# =====================================================================================
#  afinidad.sh — Estudio de afinidad de hilos (dónde se coloca cada hilo)
#
#  La afinidad NO se programa en el código: se elige con variables de entorno que
#  OpenMP lee al arrancar:
#     OMP_PLACES     qué es un "lugar":  cores (un núcleo físico) | threads (un hilo HW)
#     OMP_PROC_BIND  cómo se reparten:   false  -> el sistema operativo mueve los hilos
#                                        close  -> hilos juntos, en lugares contiguos
#                                        spread -> hilos repartidos lo más lejos posible
#
#  Cuándo importa: en servidores con varios procesadores (NUMA) o con hyperthreading,
#  y sobre todo con MENOS hilos que núcleos (close los amontona en un procesador y
#  comparte caché; spread usa más controladores de memoria).
#  En WSL el efecto es pequeño: Windows decide en última instancia dónde va cada hilo.
#
#  Uso:  ./afinidad.sh                (problema por defecto)
#        ./afinidad.sh -n 1000000 -m 5000000
# =====================================================================================
BIN="./gradiente -O auto"     # -O auto: no pedir el punto aunque se compilara con PUNTO=teclado
make -s gradiente
ARGS=${@:--n 1000000 -m 4000000}
T=$(nproc)
MITAD=$(( T > 1 ? T / 2 : 1 ))
mkdir -p resultados
OUT=resultados/07_afinidad.txt
: > "$OUT"

echo "Afinidad de hilos   (argumentos: $ARGS)" | tee -a "$OUT"
for H in $MITAD $T; do
  for CONF in "false:" "close:cores" "spread:cores" "close:threads" "spread:threads"; do
    BIND=${CONF%%:*}; PLACES=${CONF##*:}
    if [ -n "$PLACES" ]; then
      RES=$(OMP_PROC_BIND=$BIND OMP_PLACES=$PLACES $BIN $ARGS -t $H -q -r 3)
    else
      RES=$(OMP_PROC_BIND=$BIND $BIN $ARGS -t $H -q -r 3)
    fi
    LINEA=$(printf "hilos=%-3s bind=%-6s places=%-8s" "$H" "$BIND" "${PLACES:--}")
    for E in por_variables directo_atomico directo_privado; do
      TIEMPO=$(echo "$RES" | awk -v e="$E" '$1==e {print $2}')
      LINEA="$LINEA  $E=${TIEMPO}s"
    done
    echo "$LINEA" | tee -a "$OUT"
  done
done
echo "Guardado en $OUT"
