#!/bin/bash
# =====================================================================================
#  experimentos.sh — Batería de experimentos para la memoria (ejecutar EN EL SERVIDOR)
#
#  Uso:   ./experimentos.sh            (tarda varios minutos)
#         ./experimentos.sh rapido     (tamaños pequeños, para comprobar que todo va)
#
#  Guarda cada salida en resultados/  -> de ahí salen las tablas y gráficas de la memoria.
#  Antes de lanzarlo: comprueba la memoria libre (free -h) y que nadie más esté usando
#  el servidor (top), o los tiempos no serán fiables.
# =====================================================================================
set -e
BIN="./gradiente -O auto"     # -O auto: no pedir el punto aunque se compilara con PUNTO=teclado
OUT=resultados
mkdir -p "$OUT"
make -s

HILOS=$(nproc)
export OMP_WAIT_POLICY=active        # hilos "despiertos": menos coste al sincronizar

if [ "$1" = "rapido" ]; then
    TAMANOS="200000 1000000"; NVARS=100000; MBIG=1000000; REPS=1
else
    TAMANOS="1000000 5000000 20000000"; NVARS=1000000; MBIG=5000000; REPS=3
fi

echo "Servidor: $(hostname)   núcleos: $HILOS" | tee "$OUT/00_entorno.txt"
lscpu >> "$OUT/00_entorno.txt" 2>/dev/null || true
free -h >> "$OUT/00_entorno.txt" 2>/dev/null || true
gcc --version | head -1 >> "$OUT/00_entorno.txt"

echo "1) Corrección: ejemplos del enunciado"
$BIN -x -r 1 > "$OUT/01_ejemplo_enunciado.txt"
$BIN -X -r 1 > "$OUT/01_sistema_enunciado.txt"

echo "2) Escalabilidad FUERTE (mismo problema, más hilos) para varios tamaños, con ancho de banda"
for M in $TAMANOS; do
    $BIN -n $NVARS -m $M -r $REPS -q -b -B > "$OUT/02_escalado_fuerte_m$M.txt"
done

echo "3) Escalabilidad DÉBIL (el problema crece con los hilos)"
$BIN -n $((NVARS / 16)) -m $((MBIG / 4)) -r $REPS -W > "$OUT/03_escalado_debil.txt"

echo "4) Efecto del nº de variables (pocas variables = derivadas largas y más conflictos)"
for N in 100 10000 $NVARS; do
    $BIN -n $N -m $MBIG -r $REPS -q > "$OUT/04_variables_n$N.txt"
done

echo "5) Tamaño de bloque del reparto (static / dynamic,c / guided,c)"
$BIN -n $NVARS -m $MBIG -r $REPS -q -C > "$OUT/05_tamano_bloque.txt"

echo "6) Paralelismo anidado"
$BIN -n 100    -m $MBIG -r $REPS -q -A -P $HILOS > "$OUT/06_anidado_pocas_variables.txt"
$BIN -n $NVARS -m $MBIG -r $REPS -q -A -P $HILOS > "$OUT/06_anidado_muchas_variables.txt"

echo "7) Lotes: leer cada monomio una vez para 8 puntos (SIMD)"
$BIN -n $NVARS -m $MBIG -r $REPS -q -l -P 64 -B > "$OUT/07_lotes.txt"

echo "8) Índices de 32 bits frente a 64 bits"
make -s INDICES=64
$BIN       -n $NVARS -m $MBIG -r $REPS -q > "$OUT/08_indices32.txt"
./gradiente64 -O auto -n $NVARS -m $MBIG -r $REPS -q > "$OUT/08_indices64.txt"

echo "9) Reordenación: sin estructura / estructura local / desordenada, con y sin -R"
for CASO in "" "-L 64" "-L 64 -Z"; do
    NOMBRE=$(echo "aleatoria$CASO" | tr -d ' ')
    $BIN -n $((NVARS * 4)) -m $MBIG -r $REPS -q $CASO    > "$OUT/09_reordenar_${NOMBRE}.txt"
    $BIN -n $((NVARS * 4)) -m $MBIG -r $REPS -q $CASO -R > "$OUT/09_reordenar_${NOMBRE}_R.txt"
done

echo "10) Sistemas de ecuaciones (Jacobiano)"
$BIN -E 100  -n 100000 -m 50000 -r $REPS -q -b > "$OUT/10_sistema_E100.txt"
$BIN -E 1000 -n 10000  -m 5000  -r $REPS -q -b > "$OUT/10_sistema_E1000.txt"

echo "11) Afinidad de hilos"
./afinidad.sh -n $NVARS -m $MBIG > /dev/null

echo "Hecho. Resultados en $OUT/"
