/* =====================================================================================
 *  gradiente_mini.c  -  Version MINI del proyecto, en UN SOLO fichero
 *
 *  Calcula f(x) y el gradiente de un polinomio guardado igual que en el proyecto:
 *  arrays en memoria dinamica (malloc), sin structs, con inicio_del_monomio.
 *
 *  Ejemplo:  f(x, y, z) = 3xy + 4yz + 2x + 5      en el punto (1, 2, 3)
 *            Resultado esperado: f = 37   y   gradiente = (8, 15, 8)
 *
 *  (Cocina: la receta tiene 4 lineas; x = tomate, y = cebolla, z = ajo.)
 *
 *  Code::Blocks: File > New > Empty file, pegar, guardar como gradiente_mini.c
 *  y pulsar F9 (Build and run).
 * ===================================================================================== */
#include <stdio.h>
#include <stdlib.h>

/* -------------------------------------------------------------------------------------
 *  1. LA FUNCION, tal y como nos la dan (el "cuaderno del cliente")
 *     Para cada monomio: su coeficiente y cuantos factores (variable, exponente) tiene.
 *     Para probar otra funcion, cambia solo este bloque.
 * ------------------------------------------------------------------------------------- */
#define NUM_VARIABLES 3
#define NUM_MONOMIOS  4
const char  *nombre_variable[NUM_VARIABLES]  = { "x", "y", "z" };
const double coeficiente_dado[NUM_MONOMIOS]  = {  3,   4,   2,   5  };   /* 3xy 4yz 2x 5 */
const int    factores_dados[NUM_MONOMIOS]    = {  2,   2,   1,   0  };   /* el 5: ninguno */
const int    variables_dadas[]  = { 0,1,   1,2,   0 };                   /* x y | y z | x */
const int    exponentes_dados[] = { 1,1,   1,1,   1 };

/* Para tu ejercicio  f = 2x^2y + 7  cambia el bloque por este:
 *   #define NUM_VARIABLES 2
 *   #define NUM_MONOMIOS  2
 *   nombre_variable  = { "x", "y" }
 *   coeficiente_dado = { 2, 7 }      factores_dados   = { 2, 0 }
 *   variables_dadas  = { 0, 1 }      exponentes_dados = { 2, 1 }                       */

/* base^exponente con un bucle sencillo (el proyecto usa una version mas rapida) */
double potencia_entera(double base, int exponente) {
    double resultado = 1.0;
    for (int i = 0; i < exponente; i++) resultado *= base;
    return resultado;
}

int main(void) {
    /* Que todo lo que se imprime salga YA en la consola. En Windows / Code::Blocks la
     * salida a veces se guarda en un buffer y no aparece hasta que el programa termina:
     * el programa se quedaria esperando el punto con la pantalla en blanco.            */
    setvbuf(stdout, NULL, _IONBF, 0);

    int num_variables = NUM_VARIABLES, num_monomios = NUM_MONOMIOS;

    /* ---------------------------------------------------------------------------------
     *  2. MEMORIA DINAMICA para los monomios
     *     inicio_del_monomio tiene M+1 casillas: la ultima es la marca de fin.
     *     (Cocina: pedir estantes al almacen para el libro de recetas.)
     * --------------------------------------------------------------------------------- */
    double *coeficiente_del_monomio = malloc(sizeof(double) * num_monomios);
    int    *inicio_del_monomio      = malloc(sizeof(int) * (num_monomios + 1));
    if (coeficiente_del_monomio == NULL || inicio_del_monomio == NULL) {
        printf("Sin memoria\n");
        return 1;
    }

    /* ---------------------------------------------------------------------------------
     *  3. CONSTRUIR inicio_del_monomio con una SUMA PREFIJA
     *     Empezar en 0 e ir sumando cuantos factores tiene cada monomio.
     *     (Cocina: saber en que pagina empieza cada receta.)
     * --------------------------------------------------------------------------------- */
    int num_factores = 0;
    for (int monomio = 0; monomio < num_monomios; monomio++) {
        coeficiente_del_monomio[monomio] = coeficiente_dado[monomio];
        inicio_del_monomio[monomio] = num_factores;        /* empieza donde acabo el anterior */
        num_factores += factores_dados[monomio];           /* y ocupa sus factores            */
    }
    inicio_del_monomio[num_monomios] = num_factores;       /* marca de fin                    */

    /* Ahora ya sabemos cuantos factores hay en total: reservar sus arrays */
    int *variable_del_factor  = malloc(sizeof(int) * (num_factores > 0 ? num_factores : 1));
    int *exponente_del_factor = malloc(sizeof(int) * (num_factores > 0 ? num_factores : 1));
    if (variable_del_factor == NULL || exponente_del_factor == NULL) {
        printf("Sin memoria\n");
        return 1;
    }
    for (int factor = 0; factor < num_factores; factor++) {
        variable_del_factor[factor]  = variables_dadas[factor];
        exponente_del_factor[factor] = exponentes_dados[factor];
    }

    /* ---------------------------------------------------------------------------------
     *  4. ENSENAR LOS ARRAYS y como se recorre cada monomio
     * --------------------------------------------------------------------------------- */
    printf("coeficiente_del_monomio = [");
    for (int m = 0; m < num_monomios; m++) printf(" %g", coeficiente_del_monomio[m]);
    printf(" ]\ninicio_del_monomio      = [");
    for (int m = 0; m <= num_monomios; m++) printf(" %d", inicio_del_monomio[m]);  /* <= : M+1 */
    printf(" ]\nvariable_del_factor     = [");
    for (int q = 0; q < num_factores; q++) printf(" %d", variable_del_factor[q]);
    printf(" ]\nexponente_del_factor    = [");
    for (int q = 0; q < num_factores; q++) printf(" %d", exponente_del_factor[q]);
    printf(" ]\n\n");

    for (int monomio = 0; monomio < num_monomios; monomio++) {
        int desde = inicio_del_monomio[monomio];
        int hasta = inicio_del_monomio[monomio + 1];       /* el +1 DENTRO del corchete */
        printf("monomio %d: factores de la posicion %d a la %d (sin incluirla) -> %d factores:  %g",
               monomio, desde, hasta, hasta - desde, coeficiente_del_monomio[monomio]);
        for (int factor = desde; factor < hasta; factor++)
            printf("*%s^%d", nombre_variable[variable_del_factor[factor]], exponente_del_factor[factor]);
        printf("%s\n", hasta == desde ? "   (constante)" : "");
    }

    /* ---------------------------------------------------------------------------------
     *  5. LEER EL PUNTO por teclado (decimales con punto: 1.5)
     *     (Cocina: el cliente dicta las cantidades de hoy.)
     * --------------------------------------------------------------------------------- */
    double *punto = malloc(sizeof(double) * num_variables);
    if (punto == NULL) { printf("Sin memoria\n"); return 1; }
    printf("\nIntroduce el punto:\n");
    for (int variable = 0; variable < num_variables; variable++) {
        printf("  %s = ", nombre_variable[variable]);
        fflush(stdout);                                   /* mostrar la pregunta antes de esperar */
        if (scanf("%lf", &punto[variable]) != 1) { printf("Valor no valido\n"); return 1; }
    }

    /* ---------------------------------------------------------------------------------
     *  6. f(punto): para cada monomio, coeficiente * producto de sus factores
     *     Una constante da 0 vueltas al bucle de dentro y se queda en su coeficiente.
     *     (Cocina: cuanto vale el plato con las cantidades de hoy.)
     * --------------------------------------------------------------------------------- */
    double valor_de_funcion = 0.0;
    for (int monomio = 0; monomio < num_monomios; monomio++) {
        double valor = coeficiente_del_monomio[monomio];
        for (int factor = inicio_del_monomio[monomio]; factor < inicio_del_monomio[monomio + 1]; factor++)
            valor *= potencia_entera(punto[variable_del_factor[factor]], exponente_del_factor[factor]);
        valor_de_funcion += valor;
    }

    /* ---------------------------------------------------------------------------------
     *  7. GRADIENTE: para cada monomio y cada uno de sus factores, sumar su derivada
     *        d/dv (c * v^e * resto) = c * e * v^(e-1) * resto
     *     calloc lo deja todo a 0: las variables que no aparecen se quedan en 0.
     *     (Cocina: cada linea de la receta aporta a la ficha de cada uno de sus
     *      ingredientes.)
     * --------------------------------------------------------------------------------- */
    double *gradiente = calloc(num_variables, sizeof(double));
    if (gradiente == NULL) { printf("Sin memoria\n"); return 1; }

    for (int monomio = 0; monomio < num_monomios; monomio++) {
        int desde = inicio_del_monomio[monomio], hasta = inicio_del_monomio[monomio + 1];
        for (int derivo = desde; derivo < hasta; derivo++) {          /* factor que derivo */
            int    e = exponente_del_factor[derivo];
            double derivada = coeficiente_del_monomio[monomio] * e
                            * potencia_entera(punto[variable_del_factor[derivo]], e - 1);
            for (int otro = desde; otro < hasta; otro++)                /* el "resto"        */
                if (otro != derivo)
                    derivada *= potencia_entera(punto[variable_del_factor[otro]], exponente_del_factor[otro]);
            gradiente[variable_del_factor[derivo]] += derivada;
        }
    }

    /* ---------------------------------------------------------------------------------
     *  8. RESULTADO
     * --------------------------------------------------------------------------------- */
    printf("\nf = %g\ngradiente = (", valor_de_funcion);
    for (int variable = 0; variable < num_variables; variable++)
        printf("%s%g", variable ? ", " : "", gradiente[variable]);
    printf(")\n");

    printf("\nPulsa Intro para salir...");
    getchar(); getchar();                                 /* que la ventana no se cierre sola */

    /* ---------------------------------------------------------------------------------
     *  9. LIBERAR toda la memoria dinamica (un free por cada malloc/calloc)
     *     (Cocina: recoger la cocina.)
     * --------------------------------------------------------------------------------- */
    free(coeficiente_del_monomio);
    free(inicio_del_monomio);
    free(variable_del_factor);
    free(exponente_del_factor);
    free(punto);
    free(gradiente);
    return 0;
}
